---
title: "1 Thessalonians 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: Exhortations to purity and holiness. (1–8). To brotherly love, peaceable behaviour, and diligence. (9–12). Not to sorrow unduly for the death of godly relations and friends, considering the glorious resurrection of their bodies at Christ's second coming. (13–18)."
weight: 4
---

# 1 Thessalonians 4 

## Chapter Outline

- Exhortations to purity and holiness. (1–8)
- To brotherly love, peaceable behaviour, and diligence. (9–12)
- Not to sorrow unduly for the death of godly relations and friends, considering the glorious resurrection of their bodies at Christ's second coming. (13–18)

## Verses 1–8

To abide in the faith of the gospel is not enough, we must abound in the work of faith. The rule according to which all ought to walk and act, is the commandments given by the Lord Jesus Christ. Sanctification, in the renewal of their souls under the influences of the Holy Spirit, and attention to appointed duties, constituted the will of God respecting them. In aspiring after this renewal of the soul unto holiness, strict restraint must be put upon the appetites and senses of the body, and on the thoughts and inclinations of the will, which lead to wrong uses of them. The Lord calls none into his family to live unholy lives, but that they may be taught and enabled to walk before him in holiness. Some make light of the precepts of holiness, because they hear them from men; but they are God's commands, and to break them is to despise God.

## Verses 9–12

We should notice in others what is good, to their praise, that we may engage them to abound therein more and more. All who are savingly taught of God, are taught to love one another. The teaching of the Spirit exceeds the teachings of men; and men's teaching is vain and useless, unless God teach. Those remarkable for this or any other grace, need to increase therein, as well as to persevere to the end. It is very desirable to have a calm and quiet temper, and to be of a peaceable and quiet behaviour. Satan is busy to trouble us; and we have in our hearts what disposes us to be unquiet; therefore let us study to be quiet. Those who are busy-bodies, meddling in other men's matters, have little quiet in their own minds, and cause great disturbances among their neighbours. They seldom mind the other exhortation, to be diligent in their own calling, to work with their own hands. Christianity does not take us from the work and duty of our particular callings, but teaches us to be diligent therein. People often by slothfulness reduce themselves to great straits, and are liable to many wants; while such as are diligent in their own business, earn their own bread, and have great pleasure in so doing.

## Verses 13–18

Here is comfort for the relations and friends of those who die in the Lord. Grief for the death of friends is lawful; we may weep for our own loss, though it may be their gain. Christianity does not forbid, and grace does not do away, our natural affections. Yet we must not be excessive in our sorrows; this is too much like those who have no hope of a better life. Death is an unknown thing, and we know little about the state after death; yet the doctrines of the resurrection and the second coming of Christ, are a remedy against the fear of death, and undue sorrow for the death of our Christian friends; and of these doctrines we have full assurance. It will be some happiness that all the saints shall meet, and remain together for ever; but the principal happiness of heaven is to be with the Lord, to see him, live with him, and enjoy him for ever. We should support one another in times sorrow; not deaden one another's spirits, or weaken one another's hands. And this may be done by the many lessons to be learned from the resurrection of the dead, and the second coming of Christ. What! comfort a man by telling him he is going to appear before the judgment-seat of God! Who can feel comfort from those words? That man alone with whose spirit the Spirit of God bears witness that his sins are blotted out, and the thoughts of whose heart are purified by the Holy Spirit, so that he can love God, and worthily magnify his name. We are not in a safe state unless it is thus with us, or we are desiring to be so.

