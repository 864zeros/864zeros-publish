---
title: "1 Thessalonians 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: The apostle exhorts to be always ready for the coming of Christ to judgment, which will be with suddenness and surprise. (1–11). He directs to several particular duties. (12–22). And concludes with prayer, greetings, and a blessing. (23–28)."
weight: 5
---

# 1 Thessalonians 5 

## Chapter Outline

- The apostle exhorts to be always ready for the coming of Christ to judgment, which will be with suddenness and surprise. (1–11)
- He directs to several particular duties. (12–22)
- And concludes with prayer, greetings, and a blessing. (23–28)

## Verses 1–5

It is needless or useless to ask about the particular time of Christ's coming. Christ did not reveal this to the apostles. There are times and seasons for us to work in, and these are our duty and interest to know and observe; but as to the time when we must give up our account, we know it not, nor is it needful that we should. The coming of Christ will be a great surprise to men. Our Lord himself said so. As the hour of death is the same to each person that the judgment will be to mankind in general, so the same remarks answer for both. Christ's coming will be terrible to the ungodly. Their destruction will overtake them while they dream of happiness, and please themselves with vain amusements. There will be no means to escape the terror or the punishment of that day. This day will be a happy day to the righteous. They are not in darkness; they are the children of the light. It is the happy condition of all true Christians. But how many are speaking peace and safety to themselves, over whose heads utter destruction is hovering! Let us endeavour to awaken ourselves and each other, and guard against our spiritual enemies.

## Verses 6–11

Most of mankind do not consider the things of another world at all, because they are asleep; or they do not consider them aright, because they sleep and dream. Our moderation as to all earthly things should be known to all men. Shall Christians, who have the light of the blessed gospel shining in their faces, be careless about their souls, and unmindful of another world? We need the spiritual armour, or the three Christian graces, faith, love, and hope. Faith; if we believe that the eye of God is always upon us, that there is another world to prepare for, we shall see reason to watch and be sober. True and fervent love to God, and the things of God, will keep us watchful and sober. If we have hope of salvation, let us take heed of any thing that would shake our trust in the Lord. We have ground on which to build unshaken hope, when we consider, that salvation is by our Lord Jesus Christ, who died for us, to atone for our sins and to ransom our souls. We should join in prayer and praise one with another. We should set a good example one before another, and this is the best means to answer the end of society. Thus we shall learn how to live to Him, with whom we hope to live for ever.

## Verses 12–15

The ministers of the gospel are described by the work of their office, which is to serve and honour the Lord. It is their duty not only to give good counsel, but also to warn the flock of dangers, and reprove for whatever may be amiss. The people should honour and love their ministers, because their business is the welfare of men's souls. And the people should be at peace among themselves, doing all they can to guard against any differences. But love of peace must not make us wink at sin. The fearful and sorrowful spirits, should be encouraged, and a kind word may do much good. We must bear and forbear. We must be long-suffering, and keep down anger, and this to all men. Whatever man do to us, we must do good to others.

## Verses 16–22

We are to rejoice in creature-comforts, as if we rejoiced not, and must not expect to live many years, and rejoice in them all; but if we do rejoice in God, we may do that evermore. A truly religious life is a life of constant joy. And we should rejoice more, if we prayed more. Prayer will help forward all lawful business, and every good work. If we pray without ceasing, we shall not want matter for thanksgiving in every thing. We shall see cause to give thanks for sparing and preventing, for common and uncommon, past and present, temporal and spiritual mercies. Not only for prosperous and pleasing, but also for afflicting providences, for chastisements and corrections; for God designs all for our good, though we at present see not how they tend to it. Quench not the Spirit. Christians are said to be baptized with the Holy Ghost and with fire. He worketh as fire, by enlightening, enlivening, and purifying the souls of men. As fire is put out by taking away fuel, and as it is quenched by pouring water, or putting a great deal of earth upon it; so we must be careful not to quench the Holy Spirit, by indulging carnal lusts and affections, minding only earthly things. Believers often hinder their growth in grace, by not giving themselves up to the spiritual affections raised in their hearts by the Holy Spirit. By prophesyings, here understand the preaching of the word, the interpreting and applying the Scriptures. We must not despise preaching, though it is plain, and we are told no more than what we knew before. We must search the Scriptures. And proving all things must be to hold fast that which is good. We should abstain from sin, and whatever looks like sin, leads to it, and borders upon it. He who is not shy of the appearances of sin, who shuns not the occasions of it, and who avoids not the temptations and approaches to it, will not long keep from doing sin.

## Verses 23–28

The apostle prays that they might be sanctified more perfectly, for the best are sanctified but in part while in this world; therefore we should pray for, and press toward, complete holiness. And as we must fall, if God did not carry on his good work in the soul, we should pray to God to perfect his work, till we are presented faultless before the throne of his glory. We should pray for one another; and brethren should thus express brotherly love. This epistle was to be read to all the brethren. Not only are the common people allowed to read the Scriptures, but it is their duty, and what they should be persuaded to do. The word of God should not be kept in an unknown tongue, but transplanted, that as all men are concerned to know the Scriptures, so they all may be able to read them. The Scriptures should be read in all public congregations, for the benefit of the unlearned especially. We need no more to make us happy, than to know the grace of our Lord Jesus Christ. He is an ever-flowing and an over-flowing fountain of grace to supply all our wants.

