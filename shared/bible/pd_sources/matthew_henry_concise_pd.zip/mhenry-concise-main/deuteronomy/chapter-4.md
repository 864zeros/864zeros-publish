---
title: "Deuteronomy 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: Earnest exhortations to obedience, and dissuasives from idolatry. (1–23). Warnings against disobedience, and promises of mercy. (24–40). Cities of refuge appointed. (41–49)."
weight: 4
---

# Deuteronomy 4 

## Chapter Outline

- Earnest exhortations to obedience, and dissuasives from idolatry. (1–23)
- Warnings against disobedience, and promises of mercy. (24–40)
- Cities of refuge appointed. (41–49)

## Verses 1–23

The power and love of God to Israel are here made the ground and reason of a number of cautions and serious warnings; and although there is much reference to their national covenant, yet all may be applied to those who live under the gospel. What are laws made for but to be observed and obeyed? Our obedience as individuals cannot merit salvation; but it is the only evidence that we are partakers of the gift of God, which is eternal life through Jesus Christ, Considering how many temptations we are compassed with, and what corrupt desires we have in our bosoms, we have great need to keep our hearts with all diligence. Those cannot walk aright, who walk carelessly. Moses charges particularly to take heed of the sin of idolatry. He shows how weak the temptation would be to those who thought aright; for these pretended gods, the sun, moon, and stars, were only blessings which the Lord their God had imparted to all nations. It is absurd to worship them; shall we serve those that were made to serve us? Take heed lest ye forget the covenant of the Lord your God. We must take heed lest at any time we forget our religion. Care, caution, and watchfulness, are helps against a bad memory.

## Verses 24–40

Moses urged the greatness, glory, and goodness of God. Did we consider what a God he is with whom we have to do, we should surely make conscience of our duty to him, and not dare to sin against him. Shall we forsake a merciful God, who will never forsake us, if we are faithful unto him? Whither can we go? Let us be held to our duty by the bonds of love, and prevailed with by the mercies of God to cleave to him. Moses urged God's authority over them, and their obligations to him. In keeping God's commandments they would act wisely for themselves. The fear of the Lord, that is wisdom. Those who enjoy the benefit of Divine light and laws, ought to support their character for wisdom and honour, that God may be glorified thereby. Those who call upon God, shall certainly find him within call, ready to give an answer of peace to every prayer of faith. All these statutes and judgments of the Divine law are just and righteous, above the statutes and judgments of any of the nations. What they saw at mount Sinai, gave an earnest of the day of judgment, in which the Lord Jesus shall be revealed in flaming fire. They must also remember what they heard at mount Sinai. God manifests himself in the works of the creation, without speech or language, yet their voice is heard, Ps 19:1, 3; but to Israel he made himself known by speech and language, condescending to their weakness. The rise of this nation was quite different from the origin of all other nations. See the reasons of free grace; we are not beloved for our own sakes, but for Christ's sake. Moses urged the certain benefit and advantage of obedience. This argument he had begun with, verse 1, That ye may live, and go in and possess the land; and this he concludes with, verse 40, That it may go well with thee, and with thy children after thee. He reminds them that their prosperity would depend upon their piety. Apostacy from God would undoubtedly be the ruin of their nation. He foresees their revolt from God to idols. Those, and those only, shall find God to their comfort, who seek him with all their heart. Afflictions engage and quicken us to seek God; and, by the grace of God working with them, many are thus brought back to their right mind. When these things are come upon thee, turn to the Lord thy God, for thou seest what comes of turning from him. Let all the arguments be laid together, and then say, if religion has not reason on its side. None cast off the government of their God, but those who first abandon the understanding of a man.

## Verses 41–49

Here is the introduction to another discourse, or sermon, Moses preached to Israel, which we have in the following chapters. He sets the law before them, as the rule they were to work by, the way they were to walk in. He sets it before them, as the glass in which they were to see their natural face, that, looking into this perfect law of liberty, they might continue therein. These are the laws, given when Israel was newly come out of Egypt; and they were now repeated. Moses gave these laws in charge, while they encamped over against Beth-peor, an idol place of the Moabites. Their present triumphs were a powerful argument for obedience. And we should understand our own situation as sinners, and the nature of that gracious covenant to which we are invited. Therein greater things are shown to us than ever Israel saw from mount Sinai; greater mercies are given to us than they experienced in the wilderness, or in Canaan. One speaks to us, who is of infinitely greater dignity than Moses; who bare our sins upon the cross; and pleads with us by His dying love.

