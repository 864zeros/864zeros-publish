---
title: "Deuteronomy 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: God's mercies to Israel after their rebellion. (1–11). An exhortation to obedience. (12–22)."
weight: 10
---

# Deuteronomy 10 

## Chapter Outline

- God's mercies to Israel after their rebellion. (1–11)
- An exhortation to obedience. (12–22)

## Verses 1–11

Moses reminded the Israelites of God's great mercy to them, notwithstanding their provocations. There were four things in and by which the Lord showed himself reconciled to Israel. God gave them his law. Thus God has intrusted us with Bibles, sabbaths, and sacraments, as tokens of his presence and favour. God led them forward toward Canaan. He appointed a standing ministry among them for holy things. And now, under the gospel, when the pouring forth of the Spirit is more plentiful and powerful, the succession is kept up by the Spirit's work on men's hearts, qualifying and making some willing for that work in every age. God accepted Moses as an advocate or intercessor for them, and therefore appointed him to be their prince and leader. Moses was a type of Christ, who ever lives, pleading for us, and has all power in heaven and in earth.

## Verses 12–22

We are here taught our duty to God in our principles and our practices. We must fear the Lord our God. We must love him, and delight in communion with him. We must walk in the ways in which he has appointed us to walk. We must serve him with all our heart and soul. What we do in his service we must do cheerfully, and with good will. We must keep his commandments. There is true honour and pleasure in obedience. We must give honour to God; and to him we must cleave, as one we love and delight in, trust in, and from whom we have great expectations. We are here taught our duty to our neighbour. God's common gifts to mankind oblige us to honour all men. And those who have themselves been in distress, and have found mercy with God, should be ready to show kindness to those who are in the like distress. We are here taught our duty to ourselves. Circumcise your hearts. Cast away all corrupt affections and inclinations, which hinder you from fearing and loving God. By nature we do not love God. This is original sin, the source whence our wickedness proceeds; and the carnal mind is enmity against God, for it is not subject to the law of God, neither indeed can be; so then they that are in the flesh cannot please God, Ro 8:5–9. Let us, without delay or reserve, come and cleave to our reconciled God in Jesus Christ, that we may love, serve, and obey him acceptably, and be daily changed into his image, from glory to glory, by the Spirit of the Lord. Consider the greatness and glory of God; and his goodness and grace; these persuade us to our duty. Blessed Spirit! Oh for thy purifying, persevering, and renewing influences, that being called out of the state of strangers, such as our fathers were, we may be found among the number of the children of God, and that our lot may be among the saints.

