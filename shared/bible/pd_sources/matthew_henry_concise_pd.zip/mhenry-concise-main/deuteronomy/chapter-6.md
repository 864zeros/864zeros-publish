---
title: "Deuteronomy 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: A persuasive to obedience. (1–3). An exhortation to obedience. (4, 5). Obedience taught. (6–16). General precepts, Instructions to be given to their children. (17–25)."
weight: 6
---

# Deuteronomy 6 

## Chapter Outline

- A persuasive to obedience. (1–3)
- An exhortation to obedience. (4, 5)
- Obedience taught. (6–16)
- General precepts, Instructions to be given to their children. (17–25)

## Verses 1–3

In this and the like passages, the “commandments” seem to denote the moral law, the “statues” the ceremonial law, and the “judgments” the law by which the judges decided. Moses taught the people all that, and that only, which God commanded him to teach. Thus Christ's ministers are to teach his churches all he has commanded, neither more nor less, Mt 28:20. The fear of God in the heart will be the most powerful principle of obedience. It is highly desirable that not we only, but our children, and our children's children, may fear the Lord. Religion and righteousness advance and secure the prosperity of any people.

## Verses 4, 5

Here is a brief summary of religion, containing the first principles of faith and obedience. Jehovah our God is the only living and true God; he only is God, and he is but One God. Let us not desire to have any other. The three-fold mention of the Divine names, and the plural number of the word translated God, seem plainly to intimate a Trinity of persons, even in this express declaration of the unity of the Godhead. Happy those who have this one Lord for their God. It is better to have one fountain than a thousand cisterns; one all-sufficient God than a thousand insufficient friends. This is the first and great commandment of God's law, that we love him; and that we do all parts of our duty to him from a principle of love; My son, give me thine heart. We are to love God with all our heart, and soul, and might. That is, 1. With a sincere love; not in word and tongue only, but inwardly in truth. 2. With a strong love. He that is our All, must have our all, and none but he. 3. With a superlative love; we must love God above any creature whatever, and love nothing but what we love for him. 4. With an intelligent love. To love him with all the heart, and with all the understanding, we must see good cause to love him. 5. With an entire love; he is ONE, our hearts must be united in his love. Oh that this love of God may be shed abroad in our hearts!

## Verses 6–16

Here are means for maintaining and keeping up religion in our hearts and houses. 1. Meditation. God's words must be laid up in our hearts, that our thoughts may be daily employed about them. 2. The religious education of children. Often repeat these things to them. Be careful and exact in teaching thy children. Teach these truths to all who are any way under thy care. 3. Pious discourse. Thou shalt talk of these things with due reverence and seriousness, for the benefit not only of thy children, but of thy servants, thy friends and companions. Take all occasions to discourse with those about thee, not of matters of doubtful disputation, but of the plain truths and laws of God, and the things that belong to our peace. 4. Frequent reading of the word. God appointed them to write sentences of the law upon their walls, and in scrolls of parchment to be worn about their wrists. This seems to have been binding in the letter of it to the Jews, as it is to us in the intent of it; which is, that we should by all means make the word of God familiar to us; that we may have it ready to use upon all occasions, to restrain us from sin, and direct us in duty. We must never be ashamed to own our religion, nor to own ourselves under its check and government. Here is a caution not to forget God in a day of prosperity and plenty. When they came easily by the gift, they would be apt to grow secure, and unmindful of the Giver. Therefore be careful, when thou liest safe and soft, lest thou forget the Lord. When the world smiles, we are apt to make court to it, and expect our happiness in it, and so we forget Him who is our only portion and rest. There is need of great care and caution at such a time. Then beware; being warned of your danger, stand upon your guard. Thou shalt not tempt the Lord thy God; neither by despairing of his power and goodness, while we keep in the way of our duty; nor by presuming upon it, when we turn aside out of that way.

## Verses 17–25

Moses gives charge to keep God's commandments. Negligence will ruin us; but we cannot be saved without diligence. It is our interest, as well as our duty, to be religious. It will be our life. Godliness has the promise of the continuance and comfort of the life that now is, as far as it is for God's glory. It will be our righteousness. It is only through the Mediator we can be righteous before God. The knowledge of the spirituality and excellency of the holy law of God, is suited to show sinful man his need of a Saviour, and to prepare his heart to welcome a free salvation. The gospel honours the law, not only in the perfect obedience of the Son of God, the Lord Jesus Christ; but in that it is a plan for bringing back apostate rebels and enemies, by repentance, faith, forgiveness, and renewing grace, to love God above all things, even in this world; and in the world above, to love him perfectly, even as angels love him.

