---
title: "Deuteronomy 32 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "32"
description: "In this chapter: The song of Moses. (1, 2). The character of God, The character of Israel. (3–6). The great things God had done for Israel. (7–14). The wickedness of Israel. (19–25). The judgments which would come upon them for their sins. (15–18). Deserved vengeance withheld. (26–38). God's deliverance for his people. (39–43). The exhortation with which the song was delivered. (44–47). Moses to go up mount Nebo to die. (48–52)."
weight: 32
---

# Deuteronomy 32 

## Chapter Outline

- The song of Moses. (1, 2)
- The character of God, The character of Israel. (3–6)
- The great things God had done for Israel. (7–14)
- The wickedness of Israel. (19–25)
- The judgments which would come upon them for their sins. (15–18)
- Deserved vengeance withheld. (26–38)
- God's deliverance for his people. (39–43)
- The exhortation with which the song was delivered. (44–47)
- Moses to go up mount Nebo to die. (48–52)

## Verses 1, 2

Moses begins with a solemn appeal to heaven and earth, concerning the truth and importance of what he was about to say. His doctrine is the gospel, the speech of God, the doctrine of Christ; the doctrine of grace and mercy through him, and of life and salvation by him.

## Verses 3–6

“He is a Rock.” This is the first time God is called so in Scripture. The expression denotes that the Divine power, faithfulness, and love, as revealed in Christ and the gospel, form a foundation which cannot be changed or moved, on which we may build our hopes of happiness. And under his protection we may find refuge from all our enemies, and in all our troubles; as the rocks in those countries sheltered from the burning rays of the sun, and from tempests, or were fortresses from the enemy. “His work is perfect:” that of redemption and salvation, in which there is a display of all the Divine perfection, complete in all its parts. All God's dealings with his creatures are regulated by wisdom which cannot err, and perfect justice. He is indeed just and right; he takes care that none shall lose by him. A high charge is exhibited against Israel. Even God's children have their spots, while in this imperfect state; for if we say we have no sin, no spot, we deceive ourselves. But the sin of Israel was not habitual, notorious, unrepented sin; which is a certain mark of the children of Satan. They were fools to forsake their mercies for lying vanities. All wilful sinners, especially sinners in Israel, are unwise and ungrateful.

## Verses 7–14

Moses gives particular instances of God's kindness and concern for them. The eagle's care for her young is a beautiful emblem of Christ's love, who came between Divine justice and our guilty souls, and bare our sins in his own body on the tree. And by the preached gospel, and the influences of the Holy Spirit, He stirs up and prevails upon sinners to leave Satan's bondage. In verses 13, 14, are emblems of the conquest believers have over their spiritual enemies, sin, Satan, and the world, in and through Christ. Also of their safety and triumph in him; of their happy frames of soul, when they are above the world, and the things of it. This will be the blessed case of spiritual Israel in every sense in the latter day.

## Verses 15–18

Here are two instances of the wickedness of Israel, each was apostacy from God. These people were called Jeshurun, “an upright people,” so some; “a seeing people,” so others: but they soon lost the reputation both of their knowledge and of their righteousness. They indulged their appetites, as if they had nothing to do but to make provision for the flesh to fulfil the lusts of it. Those who make a god of themselves, and a god of their bellies, in pride and wantonness, and cannot bear to be told of it, thereby forsake God, and show they esteem him lightly. There is but one way of a sinner's acceptance and sanctification, however different modes of irreligion, or false religion, may show that favourable regard for other ways, which is often miscalled candid. How mad are idolaters, who forsake the Rock of salvation, to run themselves upon the rock of perdition!

## Verses 19–25

The revolt of Israel was described in the foregoing verses, and here follow the resolves of Divine justice as to them. We deceive ourselves, if we think that God will be mocked by a faithless people. Sin makes us hateful in the sight of the holy God. See what mischief sin does, and reckon those to be fools that mock at it.

## Verses 26–38

The idolatry and rebellions of Israel deserved, and the justice of God seemed to demand, that they should be rooted out. But He spared Israel, and continues them still to be living witnesses of the truth of the Bible, and to silence unbelievers. They are preserved for wise and holy purposes and the prophecies give us some idea what those purposes are. The Lord will never disgrace the throne of his glory. It is great wisdom, and will help much to the return of sinners to God, seriously to consider their latter end, or the future state. It is here meant particularly of what God foretold by Moses, about this people in the latter days; but it may be applied generally. Oh that men would consider the happiness they will lose, and the misery they will certainly plunge into, if they go on in their trespasses! What will be in the end thereof? Jer 5:31. For the Lord will in due time bring down the enemies of the church, in displeasure against their wickedness. When sinners deem themselves most secure, they suddenly fall into destruction. And God's time to appear for the deliverance of his people, is when things are at the worst with them. But those who trust to any rock but God, will find it fail them when they most need it. The rejection of the Messiah by the Jewish nation, is the continuance of their ancient idolatry, apostacy, and rebellion. They shall be brought to humble themselves before the Lord, to repent of their sins, and to trust in their long-rejected Mediator for salvation. Then he will deliver them, and make their prosperity great.

## Verses 39–43

This conclusion of the song speaks, 1. Glory to God. No escape can be made from his power. 2. It speaks terror to his enemies. Terror indeed to those who hate him. The wrath of God is here revealed from heaven against them. 3. It speaks comfort to his own people. The song concludes with words of joy. Whatever judgments are brought upon sinners, it shall go well with the people of God.

## Verses 44–47

Here is the solemn delivery of this song to Israel, with a charge to mind all the good words Moses had said unto them. It is not a trifle, but a matter of life and death: mind it, and you are made for ever; neglect it, and you are for ever undone. Oh that men were fully persuaded that religion is their life, even the life of their souls!

## Verses 48–52

Now Moses had done his work, why should he desire to live a day longer? God reminds him of the sin of which he had been guilty, for which he was kept from entering Canaan. It is good for the best of men to die repenting the infirmities of which they are conscious. But those may die with comfort and ease, whenever God calls for them, notwithstanding the sins they remember against themselves, who have a believing prospect, and a well-grounded hope of eternal life beyond death.

