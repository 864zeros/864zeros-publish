---
title: "Deuteronomy 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The Edomites to be spared. (1–7). The Moabites and Ammonites to be spared. (8–23). The Amorites to be destroyed. (24–37)."
weight: 2
---

# Deuteronomy 2 

## Chapter Outline

- The Edomites to be spared. (1–7)
- The Moabites and Ammonites to be spared. (8–23)
- The Amorites to be destroyed. (24–37)

## Verses 1–7

Only a short account of the long stay of Israel in the wilderness is given. God not only chastised them for their murmuring and unbelief, but prepared them for Canaan; by humbling them for sin, teaching them to mortify their lusts, to follow God, and to comfort themselves in him. Though Israel may be long kept waiting for deliverance and enlargement, it will come at last. Before God brought Israel to destroy their enemies in Canaan, he taught them to forgive their enemies in Edom. They must not, under pretence of God's covenant and conduct, think to seize all they could lay hands on. Dominion is not founded in grace. God's Israel shall be well placed, but must not expect to be placed alone in the midst of the earth. Religion must never be made a cloak for injustice. Scorn to be beholden to Edomites, when thou hast an all-sufficient God to depend upon. Use what thou hast, use it cheerfully. Thou hast experienced the care of the Divine providence, never use any crooked methods for thy supply. All this is equally to be applied to the experience of the believer.

## Verses 8–23

We have the origin of the Moabites, Edomites, and Ammonites. Moses also gives an instance older than any of these; the Caphtorims drove the Avims out of their country. These revolutions show what uncertain things wordly possessions are. It was so of old, and ever will be so. Families decline, and from them estates are transferred to families that increase; so little continuance is there in these things. This is recorded to encourage the children of Israel. If the providence of God has done this for Moabites and Ammonites, much more would his promise do it for Israel, his peculiar people. Cautions are given not to meddle with Moabites and Ammonites. Even wicked men must not be wronged. God gives and preserves outward blessings to wicked men; these are not the best things, he has better in store for his own children.

## Verses 24–37

God tried his people, by forbidding them to meddle with the rich countries of Moab and Ammon. He gives them possession of the country of the Amorites. If we keep from what God forbids, we shall not lose by our obedience. The earth is the Lord's and the fulness thereof; and he gives it to whom he pleases; but when there is no express direction, none can plead his grant for such proceedings. Though God assured the Israelites that the land should be their own, yet they must contend with the enemy. What God gives we must endeavour to get. What a new world did Israel now come into! Much more joyful will the change be, which holy souls will experience, when they remove out of the wilderness of this world to the better country, that is, the heavenly, to the city that has foundations. Let us, by reflecting upon God's dealings with his people Israel, be led to meditate upon our years spent in vanity, through our transgressions. But happy are those whom Jesus has delivered from the wrath to come. To whom he hath given the earnest of his Spirit in their hearts. Their inheritance cannot be affected by revolutions of kingdoms, or changes in earthly possessions.

