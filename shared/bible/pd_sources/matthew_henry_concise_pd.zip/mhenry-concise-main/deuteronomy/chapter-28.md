---
title: "Deuteronomy 28 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "28"
description: "In this chapter: The blessings for obedience. (1–14). The curses for disobedience. (15–44). Their ruin, if disobedient. (45–68)."
weight: 28
---

# Deuteronomy 28 

## Chapter Outline

- The blessings for obedience. (1–14)
- The curses for disobedience. (15–44)
- Their ruin, if disobedient. (45–68)

## Verses 1–14

This chapter is a very large exposition of two words, the blessing and the curse. They are real things and have real effects. The blessings are here put before the curses. God is slow to anger, but swift to show mercy. It is his delight to bless. It is better that we should be drawn to what is good by a child-like hope of God's favour, than that we be frightened to it by a slavish fear of his wrath. The blessing is promised, upon condition that they diligently hearken to the voice of God. Let them keep up religion, the form and power of it, in their families and nation, then the providence of God would prosper all their outward concerns.

## Verses 15–44

If we do not keep God's commandments, we not only come short of the blessing promised, but we lay ourselves under the curse, which includes all misery, as the blessing all happiness. Observe the justice of this curse. It is not a curse causeless, or for some light cause. The extent and power of this curse. Wherever the sinner goes, the curse of God follows; wherever he is, it rests upon him. Whatever he has is under a curse. All his enjoyments are made bitter; he cannot take any true comfort in them, for the wrath of God mixes itself with them. Many judgments are here stated, which would be the fruits of the curse, and with which God would punish the people of the Jews, for their apostacy and disobedience. We may observe the fulfilling of these threatenings in their present state. To complete their misery, it is threatened that by these troubles they should be bereaved of all comfort and hope, and left to utter despair. Those who walk by sight, and not by faith, are in danger of losing reason itself, when every thing about them looks frightful.

## Verses 45–68

If God inflicts vengeance, what miseries his curse can bring upon mankind, even in this present world! Yet these are but the beginning of sorrows to those under the curse of God. What then will be the misery of that world where their worm dieth not, and their fire is not quenched! Observe what is here said of the wrath of God, which should come and remain upon the Israelites for their sins. It is amazing to think that a people so long the favourites of Heaven, should be so cast off; and yet that a people so scattered in all nations should be kept distinct, and not mixed with others. If they would not serve God with cheerfulness, they should be compelled to serve their enemies. We may justly expect from God, that if we do not fear his fearful name, we shall feel his fearful plagues; for one way or other God will be feared. The destruction threatened is described. They have, indeed, been plucked from off the land, verse 63. Not only by the Babylonish captivity, and when Jerusalem was destroyed by the Romans; but afterwards, when they were forbidden to set foot in Jerusalem. They should have no rest; no rest of body, verse 65, but be continually on the remove, either in hope of gain, or fear of persecution. No rest of the mind, which is much worse. They have been banished from city to city, from country to country; recalled, and banished again. These events, compared with the favour shown to Israel in ancient times, and with the prophecies about them, should not only excite astonishment, but turn unto us for a testimony, assuring us of the truth of Scripture. And when the other prophecies of their conversion to Christ shall come to pass, the whole will be a sign and a wonder to all the nations of the earth, and the forerunner of a general spread of true christianity. The fulfilling of these prophecies upon the Jewish nation, delivered more than three thousand years ago, shows that Moses spake by the Spirit of God; who not only foresees the ruin of sinners, but warns of it, that they may prevent it by a true and timely repentance, or else be left without excuse. And let us be thankful that Christ hath redeemed us from the curse of the law, by being made a curse for us, and bearing in his own person all that punishment which our sins merit, and which we must otherwise have endured for ever. To this Refuge and salvation let sinners flee; therein let believers rejoice, and serve their reconciled God with gladness of heart, for the abundance of his spiritual blessings.

