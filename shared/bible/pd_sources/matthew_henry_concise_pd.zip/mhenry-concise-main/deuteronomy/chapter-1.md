---
title: "Deuteronomy 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The words Moses spake to Israel in the plains of Moab, The promise of Canaan. (1–8). Judges provided for the people. (9–18). Of the sending the spies—God's anger for their unbelief and disobedience. (19–46)."
weight: 1
---

# Deuteronomy 1 

## Chapter Outline

- The words Moses spake to Israel in the plains of Moab, The promise of Canaan. (1–8)
- Judges provided for the people. (9–18)
- Of the sending the spies—God's anger for their unbelief and disobedience. (19–46)

## Verses 1–8

Moses spake to the people all the Lord had given him in commandment. Horeb was but eleven days distant from Kadesh-barnea. This was to remind them that their own bad conduct had occasioned their tedious wanderings; that they might the more readily understand the advantages of obedience. They must now go forward. Though God brings his people into trouble and affliction, he knows when they have been tried long enough. When God commands us to go forward in our Christian course, he sets the heavenly Canaan before us for our encouragement.

## Verses 9–18

Moses reminds the people of the happy constitution of their government, which might make them all safe and easy, if it was not their own fault. He owns the fulfilment of God's promise to Abraham, and prays for the further accomplishment of it. We are not straitened in the power and goodness of God; why should we be straitened in our own faith and hope? Good laws were given to the Israelites, and good men were to see to the execution of them, which showed God's goodness to them, and the care of Moses.

## Verses 19–46

Moses reminds the Israelites of their march from Horeb to Kadesh-barnea, through that great and terrible wilderness. He shows how near they were to a happy settlement in Canaan. It will aggravate the eternal ruin of hypocrites, that they were not far from the kingdom of God. As if it were not enough that they were sure of their God before them, they would send men before them. Never any looked into the Holy Land, but they must own it to be a good land. And was there any cause to distrust this God? An unbelieving heart was at the bottom of all this. All disobedience to God's laws, and distrust of his power and goodness, flow from disbelief of his word, as all true obedience springs from faith. It is profitable for us to divide our past lives into distinct periods; to give thanks to God for the mercies we have received in each, to confess and seek the forgiveness of all the sins we can remember; and thus to renew our acceptance of God's salvation, and our surrender of ourselves to his service. Our own plans seldom avail to good purpose; while courage in the exercise of faith, and in the path of duty, enables the believer to follow the Lord fully, to disregard all that opposes, to triumph over all opposition, and to take firm hold upon the promised blessings.

