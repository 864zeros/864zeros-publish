---
title: "Deuteronomy 33 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "33"
description: "In this chapter: The glorious majesty of God. (1–5). The blessings of the twelve tribes. (6–23). Strength to believers. (24, 25). The excellency of Israel. (26–29)."
weight: 33
---

# Deuteronomy 33 

## Chapter Outline

- The glorious majesty of God. (1–5)
- The blessings of the twelve tribes. (6–23)
- Strength to believers. (24, 25)
- The excellency of Israel. (26–29)

## Verses 1–5

To all his precepts, warnings, and prophecies, Moses added a solemn blessing. He begins with a description of the glorious appearances of God, in giving the law. His law works like fire. If received, it is melting, warming, purifying, and burns up the dross of corruption; if rejected, it hardens, sears, pains, and destroys. The Holy Spirit came down in cloven tongues, as of fire; for the gospel also is a fiery law. The law of God written in the heart, is a certain proof of the love of God shed abroad there: we must reckon His law one of the gifts of his grace.

## Verses 6–23

The order in which the tribes are here blessed, is not the same as is observed elsewhere. The blessing of Judah may refer to the whole tribe in general, or to David as a type of Christ. Moses largely blesses the tribe of Levi. Acceptance with God is what we should all aim at, and desire, in all our devotions, whether men accept us or not, 2Co 5:9. This prayer is a prophecy, that God will keep up a ministry in his church to the end of time. The tribe of Benjamin had their inheritance close to mount Zion. To be situated near the ordinances, is a precious gift from the Lord, a privilege not to be exchanged for any worldly advantage, or indulgence. We should thankfully receive the earthly blessings sent to us, through the successive seasons. But those good gifts which come down from the Father of lights, through the rising of the Sun of righteousness, and the pouring out of his Spirit like the rain which makes fruitful, are infinitely more precious, as the tokens of his special love. The precious things here prayed for, are figures of spiritual blessing in heavenly things by Christ, the gifts, graces, and comforts of the Spirit. When Moses prays for the good will of Him that dwelt in the bush, he refers to the covenant, on which all our hopes of God's favour must be founded. The providence of God appoints men's habitations, and wisely disposes men to different employments for the public good. Whatever our place and business are, it is our wisdom and duty to apply thereto; and it is happiness to be well pleased therewith. We should not only invite others to the service of God, but abound in it. The blessing of Naphtali. The favour of God is the only favour satisfying to the soul. Those are happy indeed, who have the favour of God; and those shall have it, who reckon that in having it they have enough, and desire no more.

## Verses 24, 25

All shall be sanctified to true believers; if their way be rough, their feet shall be shod with the preparation of the gospel of peace. As thy days, so shall thy strength be. The “day” is often in Scripture put for the events of the day; it is a promise that God would graciously and constantly support under trials and troubles, whatever they were. It is a promise sure to all the spiritual seed of Abraham. Have they work allotted? They shall have strength to do it. Have they burdens appointed? They shall have strength, and never be tempted above what they are able to bear.

## Verses 26–29

None had such a God as Israel. There is no people like the Israel of God. What is here said of the church of Israel is to be applied to the spiritual church. Never were people so well seated and sheltered. Those who make God their habitation, shall have all the comforts and benefits of a habitation in him, Ps 91:1. Never were people so well supported and borne up. How low soever the people of God are at any time brought, everlasting arms are underneath them, to keep the spirit from sinking, from fainting, and their faith from failing. Divine grace is sufficient for them, 2Co 12:9. Never were people so well commanded. Thus believers are more than conquerors over their spiritual enemies, through Christ that loved them. Never were people so well secured and protected. Israel shall dwell in safety alone. All who keep close to God, shall be kept safe by him. Never were people so well provided for. Every true Israelite looks with faith to the better country, the heavenly Canaan, which is filled with better things than corn and wine. Never were people so well helped. If in danger of any harm, or in want of any good, they had an eternal God to go to. Nothing could hurt those whom God helped, nor was it possible the people should perish who were saved by the Lord. Never were people so well armed. Those in whose hearts is the excellency of holiness, are defended by the whole armour of God, Eph 6. Never were people so well assured of victory over their enemies. Thus shall the God of peace tread Satan under the feet of all believers, and shall do it shortly, Ro 16:20. May God help us to seek and to set our affections on the things above; and to turn our souls from earthly perishing objects; that we may not have our lot with Israel's foes in the regions of darkness and despair, but with the Israel of God, in the realms of love and eternal happiness.

