---
title: "Deuteronomy 20 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "20"
description: "In this chapter: Exhortation and proclamation respecting those who went to war. (1–9). Peace to be offered, What cities were to be devoted. (10–20)."
weight: 20
---

# Deuteronomy 20 

## Chapter Outline

- Exhortation and proclamation respecting those who went to war. (1–9)
- Peace to be offered, What cities were to be devoted. (10–20)

## Verses 1–9

In the wars wherein Israel engaged according to the will of God, they might expect the Divine assistance. The Lord was to be their only confidence. In these respects they were types of the Christian's warfare. Those unwilling to fight, must be sent away. The unwillingness might arise from a man's outward condition. God would not be served by men forced against their will. Thy people shall be willing, Ps 110:3. In running the Christian race, and fighting the good fight of faith, we must lay aside all that would make us unwilling. If a man's unwillingness rose from weakness and fear, he had leave to return from the war. The reason here given is, lest his brethren's heart fail as well as his heart. We must take heed that we fear not with the fear of them that are afraid, Isa 8:12.

## Verses 10–12

The Israelites are here directed about the nations on whom they made war. Let this show God's grace in dealing with sinners. He proclaims peace, and beseeches them to be reconciled. Let it also show us our duty in dealing with our brethren. Whoever are for war, we must be for peace. Of the cities given to Israel, none of their inhabitants must be left. Since it could not be expected that they should be cured of their idolatry, they would hurt Israel. These regulations are not the rules of our conduct, but Christ's law of love. The horrors of war must fill the feeling heart with anguish upon every recollection; and are proofs of the wickedness of man, the power of Satan, and the just vengeance of God, who thus scourges a guilty world. But how dreadful their case who are engaged in unequal conflict with their Maker, who will not submit to render him the easy tribute of worship and praise! Certain ruin awaits them. Let neither the number nor the power of the enemies of our souls dismay us; nor let even our own weakness cause us to tremble or to faint. The Lord will save us; but in this war let none engage whose hearts are fond of the world, or afraid of the cross and the conflict. Care is here taken that in besieging cities the fruit-trees should not be destroyed. God is a better friend to man than he is to himself; and God's law consults our interests and comforts; while our own appetites and passions, which we indulge, are enemies to our welfare. Many of the Divine precepts restrain us from destroying that which is for our life and food. The Jews understand this as forbidding all wilful waste upon any account whatsoever. Every creature of God is good; as nothing is to be refused, so nothing is to be abused. We may live to want what we carelessly waste.

