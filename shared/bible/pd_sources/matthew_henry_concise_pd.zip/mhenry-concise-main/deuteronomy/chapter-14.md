---
title: "Deuteronomy 14 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "14"
description: "In this chapter: The Israelites to distinguish themselves from other nations. (1–21). Respecting the application of tithes. (22–29)."
weight: 14
---

# Deuteronomy 14 

## Chapter Outline

- The Israelites to distinguish themselves from other nations. (1–21)
- Respecting the application of tithes. (22–29)

## Verses 1–21

Moses tells the people of Israel how God had given them three distinguishing privileges, which were their honour, and figures of those spiritual blessings in heavenly things, with which God has in Christ blessed us. Here is election; “The Lord hath chosen thee.” He did not choose them because they were by their own acts a peculiar people to him above other nations, but he chose them that they might be so by his grace; and thus were believers chosen, Eph 1:4. Here is adoption; “Ye are the children of the Lord your God;” not because God needed children, but because they were orphans, and needed a father. Every spiritual Israelite is indeed a child of God, a partaker of his nature and favour. Here is sanctification; “Thou art a holy people.” God's people are required to be holy, and if they are holy, they are indebted to the grace God which makes them so. Those whom God chooses to be his children, he will form to be a holy people, and zealous of good works. They must be careful to avoid every thing which might disgrace their profession, in the sight of those who watch for their halting. Our heavenly Father forbids nothing but for our welfare. Do thyself no harm; do not ruin thy health, thy reputation, thy domestic comforts, thy peace of mind. Especially do not murder thy soul. Do not be the vile slave of thy appetites and passions. Do not render all around thee miserable, and thyself wretched; but aim at that which is most excellent and useful. The laws which regarded many sorts of flesh as unclean, were to keep them from mingling with their idolatrous neighbours. It is plain in the gospel, that these laws are now done away. But let us ask our own hearts, Are we of the children of the Lord our God? Are we separate from the ungodly world, in being set apart to God's glory, the purchase of Christ's blood? Are we subjects of the work of the Holy Ghost? Lord, teach us from these precepts how pure and holy all thy people ought to live!

## Verses 22–29

A second portion from the produce of their land was required. The whole appointment evidently was against the covetousness, distrust, and selfishness of the human heart. It promoted friendliness, liberality, and cheerfulness, and raised a fund for the relief of the poor. They were taught that their worldly portion was most comfortably enjoyed, when shared with their brethren who were in want. If we thus serve God, and do good with what we have, it is promised that the Lord our God will bless us in all the works of our land. The blessing of God is all to our outward prosperity; and without that blessing, the work of our hands will bring nothing to pass. The blessing descends upon the working hand. Expect not that God should bless thee in thy idleness and love of ease. And it descends upon the giving hand. He who thus scatters, certainly increases; and to be free and generous in the support of religion, and any good work, is the surest and safest way of thriving.

