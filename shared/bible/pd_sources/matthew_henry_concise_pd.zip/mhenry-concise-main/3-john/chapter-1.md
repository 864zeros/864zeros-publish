---
title: "3 John 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle commends Gaius for piety and hospitality. (1–8). Cautions him against siding with Diotrephes, who was a turbulent spirit; but recommends Demetrius as a man of excellent character. (9–12). He hopes soon to see Gaius. (13, 14)."
weight: 1
---

# 3 John 1 

## Chapter Outline

- The apostle commends Gaius for piety and hospitality. (1–8)
- Cautions him against siding with Diotrephes, who was a turbulent spirit; but recommends Demetrius as a man of excellent character. (9–12)
- He hopes soon to see Gaius. (13, 14)

## Verses 1–8

Those who are beloved of Christ, will love the brethren for his sake. Soul prosperity is the greatest blessing on this side heaven. Grace and health are rich companions. Grace will employ health. A rich soul may be lodged in a weak body; and grace must then be exercised in submitting to such a dispensation. But we may wish and pray that those who have prosperous souls, may have healthful bodies; that their grace may shine where there is still more room for activity. How many professors there are, about whom the apostle's words must be reversed, and we must earnestly wish and pray that their souls might prosper, as their health and circumstances do! True faith will work by love. A good report is due from those who receive good; they could not but testify to the church, what they found and felt. Good men will rejoice in the soul prosperity of others; and they are glad to hear of the grace and goodness of others. And as it is a joy to good parents, it will be a joy to good ministers, to see their people adorn their profession. Gaius overlooked petty differences among serious Christians, and freely helped all who bore the image, and did the work of Christ. He was upright in what he did, as a faithful servant. Faithful souls can hear their own praises without being puffed up; the commendation of what is good in them, lays them at the foot of the cross of Christ. Christians should consider not only what they must do, but what they may do; and should do even the common actions of life, and of good-will, after a godly sort, serving God therein, and designing his glory. Those who freely make known Christ's gospel, should be helped by others to whom God gives the means. Those who cannot themselves proclaim it, may yet receive, help, and countenance those who do so.

## Verses 9–12

Both the heart and mouth must be watched. The temper and spirit of Diotrephes was full of pride and ambition. It is bad not to do good ourselves; but it is worse to hinder those who would do good. Those cautions and counsels are most likely to be accepted, which are seasoned with love. Follow that which is good, for he that doeth good, as delighting therein, is born of God. Evil-workers vainly pretend or boast acquaintance with God. Let us not follow that which is proud, selfish, and of bad design, though the example may be given by persons of rank and power; but let us be followers of God, and walk in love, after the example of our Lord.

## Verses 13, 14

Here is the character of Demetrius. A name in the gospel, or a good report in the churches, is better than worldly honour. Few are well spoken of by all; and sometimes it is ill to be so. Happy those whose spirit and conduct commend them before God and men. We must be ready to bear our testimony to them; and it is well when those who commend, can appeal to the consciences of such as know most of those who are commended. A personal conversation together often spares time and trouble, and mistakes which rise from letters; and good Christians may well be glad to see one another. The blessing is, Peace be to you; all happiness attend you. Those may well salute and greet one another on earth, who hope to live together in heaven. By associating with and copying the example of such Christians, we shall have peace within, and live at peace with the brethren; our communications with the Lord's people on earth will be pleasing, and we shall be numbered with them in glory everlasting.

