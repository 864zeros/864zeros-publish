---
title: "2 Peter 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: Believers are cautioned against false teachers, and the certainty of their punishment shown from examples. (1–9). An account of these seducers, as exceedingly wicked. (10–16). But as making high pretences to liberty and purity. (17–22)."
weight: 2
---

# 2 Peter 2 

## Chapter Outline

- Believers are cautioned against false teachers, and the certainty of their punishment shown from examples. (1–9)
- An account of these seducers, as exceedingly wicked. (10–16)
- But as making high pretences to liberty and purity. (17–22)

## Verses 1–9

Though the way of error is a hurtful way, many are always ready to walk therein. Let us take care we give no occasion to the enemy to blaspheme the holy name whereby we are called, or to speak evil of the way of salvation by Jesus Christ, who is the Way, the Truth, and the Life. These seducers used feigned words, they deceived the hearts of their followers. Such are condemned already, and the wrath of God abides upon them. God's usual method of proceeding is shown by examples. Angels were cast down from all their glory and dignity, for their disobedience. If creatures sin, even in heaven, they must suffer in hell. Sin is the work of darkness, and darkness is the wages of sin. See how God dealt with the old world. The number of offenders no more procures favour, than their quality. If the sin be universal, the punishment shall likewise extend to all. If in a fruitful soil the people abound in sin, God can at once turn a fruitful land into barrenness, and a well-watered country into ashes. No plans or politics can keep off judgments from a sinful people. He who keeps fire and water from hurting his people, Isa 43:2, can make either destroy his enemies; they are never safe. When God sends destruction on the ungodly, he commands deliverance for the righteous. In bad company we cannot but get either guilt or grief. Let the sins of others be troubles to us. Yet it is possible for the children of the Lord, living among the most profane, to retain their integrity; there being more power in the grace of Christ, and his dwelling in them, than in the temptations of Satan, or the example of the wicked, with all their terrors or allurements. In our intentions and inclinations to commit sin, we meet with strange hinderances, if we mark them When we intend mischief, God sends many stops to hinder us, as if to say, Take heed what you do. His wisdom and power will surely effect the purposes of his love, and the engagements of his truth; while wicked men often escape suffering here, because they are kept to the day of judgment, to be punished with the devil and his angels.

## Verses 10–16

Impure seducers and their abandoned followers, give themselves up to their own fleshly minds. Refusing to bring every thought to the obedience of Christ, they act against God's righteous precepts. They walk after the flesh, they go on in sinful courses, and increase to greater degrees of impurity and wickedness. They also despise those whom God has set in authority over them, and requires them to honour. Outward temporal good things are the wages sinners expect and promise themselves. And none have more cause to tremble, than those who are bold to gratify their sinful lusts, by presuming on the Divine grace and mercy. Many such there have been, and are, who speak lightly of the restraints of God's law, and deem themselves freed from obligations to obey it. Let Christians stand at a distance from such.

## Verses 17–22

The word of truth is the water of life, which refreshes the souls that receive it; but deceivers spread and promote error, and are set forth as empty, because there is no truth in them. As clouds hinder the light of the sun, so do these darken counsel by words wherein there is no truth. Seeing that these men increase darkness in this world, it is very just that the mist of darkness should be their portion in the next. In the midst of their talk of liberty, these men are the vilest slaves; their own lusts gain a complete victory over them, and they are actually in bondage. When men are entangled, they are easily overcome; therefore Christians should keep close to the word of God, and watch against all who seek to bewilder them. A state of apostacy is worse than a state of ignorance. To bring an evil report upon the good way of God, and a false charge against the way of truth, must expose to the heaviest condemnation. How dreadful is the state here described! Yet though such a case is deplorable, it is not utterly hopeless; the leper may be made clean, and even the dead may be raised. Is thy backsliding a grief to thee? Believe in the Lord Jesus, and thou shalt be saved.

