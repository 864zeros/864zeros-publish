---
title: "Ezra 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: The decree for completing the temple. (1–12). The temple is finished. (13–22)."
weight: 6
---

# Ezra 6 

## Chapter Outline

- The decree for completing the temple. (1–12)
- The temple is finished. (13–22)

## Verses 1–12

When God's time is come for fulfilling his gracious purposes concerning his church, he will raise up instruments to do it, from whom such good service was not expected. While our thoughts are directed to this event, we are led by Zechariah to fix our regard on a nobler, a spiritual building. The Lord Jesus Christ continues to lay one stone upon another: let us assist the great design. Difficulties delay the progress of this sacred edifice. Yet let not opposition discourage us, for in due season it will be completed to his abundant praise. He shall bring forth the head-stone thereof with shoutings, crying, Grace, grace unto it.

## Verses 13–22

The gospel church, that spiritual temple, is long in the building, but it will be finished at last, when the mystical body is completed. Every believer is a living temple, building up himself in his most holy faith: much opposition is given to this work by Satan and our own corruptions. We trifle, and proceed in it with many stops and pauses; but He that has begun the good work, will see it performed. Then spirits of just men will be made perfect. By getting their sins taken away, the Jews would free themselves from the sting of their late troubles. Their service was with joy. Let us welcome holy ordinances with joy, and serve the Lord with gladness.

