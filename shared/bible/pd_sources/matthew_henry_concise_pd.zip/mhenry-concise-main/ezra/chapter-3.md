---
title: "Ezra 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The altar and festivals. (1–7). The foundations of the temple laid. (8–13)."
weight: 3
---

# Ezra 3 

## Chapter Outline

- The altar and festivals. (1–7)
- The foundations of the temple laid. (8–13)

## Verses 1–7

From the proceedings of the Jews on their arrival, let us learn to begin with God, and to do what we can in the worship of God, when we cannot do what we would. They could not at once have a temple, but they would not be without an altar. Fear of danger should stir us to our duty. Have we many enemies? Then it is good to have God our Friend, and to keep up communion with him. Our fears should drive us to our knees. The sacrifices for all these solemnities were a heavy expense for so poor a company; yet besides those expressly appointed, many brought free-will offerings to the Lord. And they made preparation for the building of the temple without delay: whatever God calls us to do, we may depend upon his providence to furnish us with the needful means.

## Verses 8–13

There was a remarkable mixture of affections upon laying the foundation of the temple. Those that only knew the misery of having no temple at all, praised the Lord with shouts of joy. To them, even this foundation seemed great. We ought to be thankful for the beginnings of mercy, though it be not yet perfect. But those who remembered the glory of the first temple, and considered how far inferior this was likely to be, wept with a loud voice. There was reason for it, and if they bewailed the sin that was the cause of this melancholy change, they did well. Yet it was wrong to cast a damp upon the common joys. They despised the day of small things, and were unthankful for the good they enjoyed. Let not the remembrance of former afflictions drown the sense of present mercies.

