---
title: "Ezra 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The proclamation of Cyrus for the rebuilding of the temple. (1–4). The people provide for their return. (5–11)."
weight: 1
---

# Ezra 1 

## Chapter Outline

- The proclamation of Cyrus for the rebuilding of the temple. (1–4)
- The people provide for their return. (5–11)

## Verses 1–4

The Lord stirred up the spirit of Cyrus. The hearts of kings are in the hand of the Lord. God governs the world by his influence on the spirits of men; whatever good they do, God stirs up their spirits to do it. It was during the captivity of the Jews, that God principally employed them as the means of calling the attention of the heathen to him. Cyrus took it for granted, that those among the Jews who were able, would offer free-will offerings for the house of God. He would also have them supplied out of his kingdom. Well-wishers to the temple should be well-doers for it.

## Verses 5–11

The same God that raised up the spirit of Cyrus to proclaim liberty to the Jews, raised up their spirits to take the benefit. The temptation was to some to stay in Babylon; but some feared not to return, and they were those whose spirits God raised, by his Spirit and grace. Whatever good we do, is owing to the grace of God. Our spirits naturally bow down to this earth and the things of it; if they move upward in any good affections or good actions, it is God who raises them. The calls and offers of the gospel are like the proclamation of Cyrus. Those bound under the power of sin, may be made free by Jesus Christ. Whosoever will, by repentance and faith, return to God, Jesus Christ has opened the way for him, and raises him out of the slavery of sin into the glorious liberty of the children of God. Many that hear this joyful sound, choose to sit still in Babylon, are in love with their sins, and will not venture upon a holy life; but some break through all discouragements, whatever it cost them; they are those whose spirit God has raised above the world and the flesh, whom he has made willing. Thus will the heavenly Canaan be filled, though many perish in Babylon; and the gospel offer will not have been made in vain. The bringing back the Jews from captivity, represents the redemption of sinners by Jesus Christ.

