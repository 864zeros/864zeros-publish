---
title: "1 Samuel 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: Samuel testifies his integrity. (1–5). Samuel reproves the people. (6–15). Thunder sent in harvest time. (16–25)."
weight: 12
---

# 1 Samuel 12 

## Chapter Outline

- Samuel testifies his integrity. (1–5)
- Samuel reproves the people. (6–15)
- Thunder sent in harvest time. (16–25)

## Verses 1–5

Samuel not only cleared his own character, but set an example before Saul, while he showed the people their ingratitude to God and to himself. There is a just debt which all men to their own good name, especially men in public stations, which is, to guard it against unjust blame and suspicions, that they may finish their course with honour, as well as with joy. And that we have in our places lived honestly, will be our comfort, under any slights and contempt that may be put upon us.

## Verses 6–15

The work of ministers is to reason with people; not only to exhort and direct, but to persuade, to convince men's judgments, and so to gain their wills and affections. Samuel reasons of the righteous acts of the Lord. Those who follow God faithfully, he will enable to continue following him. Disobedience would certainly be the ruin of Israel. We mistake if we think that we can escape God's justice, by trying to shake off his dominion. If we resolve that God shall not rule us, yet he will judge us.

## Verses 16–25

At Samuel's word, God sent thunder and rain, at a season of the year when, in that country, the like was not seen. This was to convince them they had done wickedly in asking a king; not only by its coming at an unusual time, in wheat harvest, and on a clear day, but by the prophet's giving notice of it before. He showed their folly in desiring a king to save them, rather than God, or Samuel; promising themselves more from an arm of flesh, than from the arm of God, or from the power of prayer. Could their prince command such forces as the prophet could do by his prayers? It startled them very much. Some will not be brought to see their sins by any gentler methods than storms and thunders. They entreat Samuel to pray for them. Now they see their need of him whom shortly before they slighted. Thus many who will not have Christ to reign over them, would yet be glad to have him intercede for them, to turn away the wrath of God. Samuel aims to confirm the people in their religion. Whatever we make a god of, we shall find it deceive us. Creatures in their own places are good; but when put in God's place, they are vain things. We sin if we restrain prayer, and in particular if we cease praying for the church. They only asked him to pray for them; but he promises to do more, to teach them. He urges that they were bound in gratitude to serve God, considering what great things he had done for them; and that they were bound in interest to serve him, considering what he would do against them, if they should still do wickedly. Thus, as a faithful watchman, he gave them warning, and so delivered his own soul. If we consider what great things the Lord hath done for us, especially in the great work of redemption, we can neither want motive, encouragement, nor assistance in serving him.

