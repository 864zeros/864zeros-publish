---
title: "1 Samuel 30 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "30"
description: "In this chapter: Ziklag spoiled by the Amalekites. (1–6). David overtakes the Amalekites. (7–15). He recovers what had been lost. (16–20). David's distribution of the spoil. (21–31)."
weight: 30
---

# 1 Samuel 30 

## Chapter Outline

- Ziklag spoiled by the Amalekites. (1–6)
- David overtakes the Amalekites. (7–15)
- He recovers what had been lost. (16–20)
- David's distribution of the spoil. (21–31)

## Verses 1–6

When we go abroad in the way of our duty, we may comfortably hope that God will take care of our families in our absence, but not otherwise. If, when we come off a journey, we find our abode in peace, and not laid waste, as David here found his, let the Lord be praised for it. David's men murmured against him. Great faith must expect such severe trials. But, observe, that David was brought thus low, only just before he was raised to the throne. When things are at the worst with the church and people of God, then they begin to mend. David encouraged himself in the Lord his God. His men fretted at their loss, the soul of the people was bitter; their own discontent and impatience added to the affliction and misery. But David bore it better, though he had more reason than any of them to lament it. They gave liberty to their passions, but he set his graces to work; and while they dispirited each other, he, by encouraging himself in God, kept his spirit calm. Those who have taken the Lord for their God, may take encouragement from him in the worst times.

## Verses 7–15

If in all our ways, even when, as in this case, there can be no doubt they are just, we acknowledge God, we may expect that he will direct our steps, as he did those of David. David, in tenderness to his men, would by no means urge them beyond their strength. The Son of David thus considers the frames of his followers, who are not all alike strong and vigorous in their spiritual pursuits and conflicts; but, where we are weak, there he is kind; nay more, there he is strong, 2Co 12:9, 10. A poor Egyptian lad, scarcely alive, is made the means of a great deal of good to David. Justly did Providence make this poor servant, who was basely used by his master, an instrument in the destruction of the Amalekites; for God hears the cry of the oppressed. Those are unworthy the name of true Israelites, who shut up their compassion from persons in distress. We should neither do an injury nor deny a kindness to any man; some time or other it may be in the power of the lowest to return a kindness or an injury.

## Verses 16–20

Sinners are nearest to ruin, when they cry, Peace and safety, and put the evil day far from them. Nor does any thing give our spiritual enemies more advantage than sensuality and indulgence. Eating and drinking, and dancing, have been the soft and pleasant way in which many have gone down to the congregation of the dead. The spoil was recovered, and brought off; nothing was lost, but a great deal gained.

## Verses 21–31

What God gives us, he designs we should do good with. In distributing the spoil, David was just and kind. Those are men of Belial indeed, who delight in putting hardships upon their brethren, and care not who is starved, so that they may be fed to the full. David was generous and kind to all his friends. Those who consider the Lord as the Giver of their abundance, will dispose of it with fairness and liberality.

