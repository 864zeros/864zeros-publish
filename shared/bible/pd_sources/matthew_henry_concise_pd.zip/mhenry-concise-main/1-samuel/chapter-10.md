---
title: "1 Samuel 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: Samuel anoints Saul. (1–8). Saul prophesies. (9–16). Saul chosen king. (17–27)."
weight: 10
---

# 1 Samuel 10 

## Chapter Outline

- Samuel anoints Saul. (1–8)
- Saul prophesies. (9–16)
- Saul chosen king. (17–27)

## Verses 1–8

The sacred anointing, then used, pointed at the great Messiah, or Anointed One, the King of the church, and High Priest of our profession, who was anointed with the oil of the Spirit, not by measure, but without measure, and above all the priests and princes of the Jewish church. For Saul's further satisfaction, Samuel gives him some signs which should come to pass the same day. The first place he directs him to, was the sepulchre of one of his ancestors; there he must be reminded of his own mortality, and now that he had a crown before him, must think of his grave, in which all his honour would be laid in the dust. From the time of Samuel there appears to have been schools, or places where pious young men were brought up in the knowledge of Divine things. Saul should find himself strongly moved to join with them, and should be turned into another man from what he had been. The Spirit of God changes men, wonderfully transforms them. Saul, by praising God in the communion of saints, became another man, but it may be questioned if he became a new man.

## Verses 9–16

The signs Samuel had given Saul, came to pass punctually; he found that God had given him another heart, another disposition of mind. Yet let not an outward show of devotion, and a sudden change for the present, be too much relied on; Saul among the prophets was Saul still. His being anointed was kept private. He leaves it to God to carry on his own work by Samuel, and sits still, to see how the matter will fall.

## Verses 17–27

Samuel tells the people, Ye have this day rejected your God. So little fond was Saul now of that power, which soon after, when he possessed it, he could not think of parting with, that he hid himself. It is good to be conscious of our unworthiness and insufficiency for the services to which we are called; but men should not go into the contrary extreme, by refusing the employments to which the Lord and the church call them. The greater part of the people treated the matter with indifference. Saul modestly went home to his own house, but was attended by a band of men whose hearts God disposed to support his authority. If the heart bend at any time the right way, it is because He has touched it. One touch is enough when it is Divine. Others despised him. Thus differently are men affected to our exalted Redeemer. There is a remnant who submit to him, and follow him wherever he goes; they are those whose hearts God has touched, whom he has made willing. But there are others who despise him, who ask, How shall this man save us? They are offended in him, and they will be punished.

