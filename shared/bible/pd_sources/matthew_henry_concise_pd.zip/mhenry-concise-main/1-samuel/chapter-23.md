---
title: "1 Samuel 23 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "23"
description: "In this chapter: David rescues Keilah. (1–6). God warns him to escape from Keilah. (7–13). Jonathan comforts David. (14–18). He is rescued from Saul by an invasion of the Philistines. (19–29)."
weight: 23
---

# 1 Samuel 23 

## Chapter Outline

- David rescues Keilah. (1–6)
- God warns him to escape from Keilah. (7–13)
- Jonathan comforts David. (14–18)
- He is rescued from Saul by an invasion of the Philistines. (19–29)

## Verses 1–6

When princes persecute God's people, let them expect vexation on all sides. The way for any country to be quiet, is to let God's church be quiet in it: if Saul fight against David, the Philistines fight against his country. David considered himself the protector of the land. Thus did the Saviour Jesus, and left us an example. Those are unlike David, who sullenly decline to do good, if they are not rewarded for services.

## Verses 7–13

Well might David complain of his enemies, that they rewarded him evil for good, and that for his love they were his adversaries. Christ was used thus basely. David applied to his great Protector for direction. No sooner was the ephod brought him than he made use of it. We have the Scriptures in our hands, let us take advice from them in doubtful cases. Say, Bring hither the Bible. David's address to God is very solemn, also very particular. God allows us to be so in our addresses to him; Lord, direct me in this matter, about which I am now at a loss. God knows not only what will be, but what would be, if it were not hindered; therefore he knows how to deliver the godly out of temptation, and how to render to every man according to his works.

## Verses 14–18

David made no attempt against Saul; he kept God's way, waited God's time, and was content to secure himself in woods and wildernesses. Let it make us think the worse of this world, which often gives such bad treatment to its best men: let it make us long for that kingdom where goodness shall for ever be in glory, and holiness in honour. We find Jonathan comforting David. As a pious friend, he directed him to God, the Foundation of his comfort. As a self-denying friend, he takes pleasure in the prospect of David's advancement to the throne. As a constant friend, he renewed his friendship with him. Our covenant with God should be often renewed, and therein our communion with him kept up. If the converse of one friend, at one meeting, gives comfort and strengthens our hearts, what may not be expected from the continual supports and powerful love of the Saviour of sinners, the covenanted Friend of believers!

## Verses 19–29

In the midst of his wickedness, Saul affected to speak the language of piety. Such expressions, without suitable effects, can only amuse or deceive those who hear, and those who use them. This mountain was an emblem of the Divine Providence coming between David and the destroyer. Let us not be dismayed at the prospect of future difficulties, but stay ourselves upon Him who is wonderful in counsel and excellent in working. Sooner than his promise shall fail, he will commission Philistines to effect our escape, at the very moment when our case appears most desperate. God requires entire dependence on him, If ye will not believe, surely ye shall not be established, Isa 7:9.

