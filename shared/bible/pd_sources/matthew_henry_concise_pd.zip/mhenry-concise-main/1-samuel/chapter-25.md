---
title: "1 Samuel 25 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "25"
description: "In this chapter: Death of Samuel. (1). David's request; Nabal's churlish refusal. (2–11). David's intention to destroy Nabal. (12–17). Abigail takes a present to David. (18–31). He is pacified, Nabal dies. (32–39). David takes Abigail to wife. (39–44)."
weight: 25
---

# 1 Samuel 25 

## Chapter Outline

- Death of Samuel. (1)
- David's request; Nabal's churlish refusal. (2–11)
- David's intention to destroy Nabal. (12–17)
- Abigail takes a present to David. (18–31)
- He is pacified, Nabal dies. (32–39)
- David takes Abigail to wife. (39–44)

## Verse 1

All Israel lamented Samuel, and they had reason. He prayed daily for them. Those have hard hearts, who can bury faithful ministers without grief; who do not feel their loss of those who have prayed for them, and taught them the way of the Lord.

## Verses 2–11

We should not have heard of Nabal, if nothing had passed between him and David. Observe his name, Nabal, “A fool;” so it signifies. Riches make men look great in the eye of the world; but to one that takes right views, Nabal looked very mean. He had no honour or honesty; he was churlish, cross, and ill-humoured; evil in his doings, hard and oppressive; a man that cared not what fraud and violence he used in getting and saving. What little reason have we to value the wealth of this world, when so great a churl as Nabal abounds, and so good a man as David suffers want!, David pleaded the kindness Nabal's shepherds had received. Considering that David's men were in distress and debt, and discontented, and the scarcity of provisions, it was by good management that they were kept from plundering. Nabal went into a passion, as covetous men are apt to do, when asked for any thing, thinking thus to cover one sin with another; and, by abusing the poor, to excuse themselves from relieving them. But God will not thus be mocked. Let this help us to bear reproaches and misrepresentations with patience and cheerfulness, and make us easy under them; it has often been the lot of the excellent ones of the earth. Nabal insists much on the property he had in the provisions of his table. May he not do what he will with his own? We mistake, if we think we are absolute lords of what we have, and may do what we please with it. No; we are but stewards, and must use it as we are directed, remembering it is not our own, but His who intrusted us with it.

## Verses 12–17

God is kind to the evil and unthankful, and why may not we be so? David determined to destroy Nabal, and all that belonged to him. Is this thy voice, O David? Has he been so long in the school of affliction, where he should have learned patience, and yet is so passionate? He at other times was calm and considerate, but is put into such a heat by a few hard words, that he seeks to destroy a whole family. What are the best of men, when God leaves them to themselves, that they may know what is in their hearts? What need to pray, Lord, lead us not into temptation!

## Verses 18–31

By a present Abigail atoned for Nabal's denial of David's request. Her behaviour was very submissive. Yielding pacifies great offences. She puts herself in the place of a penitent, and of a petitioner. She could not excuse her husband's conduct. She depends not upon her own reasonings, but on God's grace, to soften David, and expects that grace would work powerfully. She says that it was below him to take vengeance on so weak and despicable an enemy as Nabal, who, as he would do him no kindness, so he could do him no hurt. She foretells the glorious end of David's present troubles. God will preserve thy life; therefore it becomes not thee unjustly and unnecessarily to take away the lives of any, especially of the people of thy God and Saviour. Abigail keeps this argument for the last, as very powerful with so good a man; that the less he indulged his passion, the more he consulted his peace and the repose of his own conscience. Many have done that in a heat, which they have a thousand times wished undone again. The sweetness of revenge is soon turned into bitterness. When tempted to sin, we should consider how it will appear when we think upon it afterwards.

## Verses 32–39

David gives God thanks for sending him this happy check in a sinful way. Whoever meet us with counsel, direction, comfort, caution, or seasonable reproof, we must see God sending them. We ought to be very thankful for those happy providences which are the means of keeping us from sinning. Most people think it enough, if they take reproof patiently; but few will take it thankfully, and commend those who give it, and accept it as a favour. The nearer we are to committing sin, the greater is the mercy of a seasonable restraint. Sinners are often most secure when most in danger. He was very drunk. A sign he was Nabal, a fool, that could not use plenty without abusing it; who could not be pleasant with his friends without making a beast of himself. There is not a surer sign that a man has but little wisdom, nor a surer way to destroy the little he has, than drinking to excess. Next morning, how he is changed! His heart overnight merry with wine, next morning heavy as a stone; so deceitful are carnal pleasures, so soon passes the laughter of the fool; the end of that mirth is heaviness. Drunkards are sad, when they reflect upon their own folly. About ten days after, the Lord smote Nabal, that he died. David blessed God that he had been kept from killing Nabal. Worldly sorrow, mortified pride, and an affrighted conscience, sometimes end the joys of the sensualist, and separate the covetous man from his wealth; but, whatever the weapon, the Lord smites men with death when it pleases him.

## Verses 39–44

Abigail believed that David would be king over Israel, and greatly esteemed his pious and excellent character. She deemed his proposal of marriage honourable, and advantageous to her, notwithstanding his present difficulties. With great humility, and doubtless agreeably to the customs of those times, she consented, being willing to share his trails. Thus those who join themselves to Christ, must be willing now to suffer with him, believing that hereafter they shall reign with him.

