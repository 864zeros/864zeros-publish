---
title: "1 Samuel 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: The evil government of Samuel's sons. (1–3). The Israelites ask for a king. (4–9). The manner of a king. (10–22)."
weight: 8
---

# 1 Samuel 8 

## Chapter Outline

- The evil government of Samuel's sons. (1–3)
- The Israelites ask for a king. (4–9)
- The manner of a king. (10–22)

## Verses 1–3

It does not appear that Samuel's sons were so profane and vicious as Eli's sons; but they were corrupt judges, they turned aside after lucre. Samuel took no bribes, but his sons did, and then they perverted judgment. What added to the grievance of the people was, that they were threatened by an invasion from Nahash, king of the Ammonites.

## Verses 4–9

Samuel was displeased; he could patiently bear what reflected on himself, and his own family; but it displeased him when they said, Give us a king to judge us, because that reflected upon God. It drove him to his knees. When any thing disturbs us, it is our interest, as well as our duty, to show our trouble before God. Samuel is to tell them that they shall have a king. Not that God was pleased with their request, but as sometimes he opposes us from loving-kindness, so at other times he gratifies us in wrath; he did so here. God knows how to bring glory to himself, and serves his own wise purposes, even by men's foolish counsels.

## Verses 10–22

If they would have a king to rule them, as the eastern kings ruled their subjects, they would find the yoke exceedingly heavy. Those that submit to the government of the world and the flesh, are told plainly, what hard masters they are, and what tyranny the dominion of sin is. The law of God and the manner of men widely differ from each other; the former should be our rule in the several relations of life; the latter should be the measure of our expectations from others. These would be their grievances, and, when they complained to God, he would not hear them. When we bring ourselves into distress by our own wrong desires and projects, we justly forfeit the comfort of prayer, and the benefit of Divine aid. The people were obstinate and urgent in their demand. Sudden resolves and hasty desires make work for long and leisurely repentance. Our wisdom is, to be thankful for the advantages, and patient under the disadvantages of the government we may live under; and to pray continually for our rulers, that they may govern us in the fear of God, and that we may live under them in all godliness and honesty. And it is a hopeful symptom when our desires of worldly objects can brook delay; and when we can refer the time and manner of their being granted to God's providence.

