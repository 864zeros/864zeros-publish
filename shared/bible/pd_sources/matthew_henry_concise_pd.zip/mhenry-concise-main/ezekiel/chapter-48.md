---
title: "Ezekiel 48 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "48"
description: "In this chapter: The Vision of the Temple. (1-35)."
weight: 48
---

# Ezekiel 48 

## Chapter Outline

- The Vision of the Temple. (1-35)

## Verses 1-35

Here is a description of the several portions of the land belonging to each tribe. In gospel times, behold all things are become new. Much is wrapped up in emblems and numbers. This method God has used to state mysterious truths in his word, not to be more clearly revealed till the proper time and season. But into the church of Christ, both in its state of warfare and triumph, there is free access by faith, from every side. Christ has opened the kingdom of heaven for all believers. Whoever will, may come, and take of the water of life, of the tree of life, freely. The Lord is there, in his church, to be nigh unto them in all they call upon him for. This is true of every real Christian; whatever soul has in it a living principle of grace, it may truly be said, The Lord is there. May we be found citizens of this holy city, and act agreeably to that character; and have the benefit of the Lord's presence with us, in life, in death, and for evermore.


