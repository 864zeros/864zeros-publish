---
title: "Ezekiel 9 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "9"
description: "In this chapter: A vision denoting the destruction of the inhabitants of Jerusalem, and the departure of the symbol of the Divine presence. (1-11)."
weight: 9
---

# Ezekiel 9 

## Chapter Outline

- A vision denoting the destruction of the inhabitants of Jerusalem, and the departure of the symbol of the Divine presence. (1-11)

## Verses 1-4

It is a great comfort to believers, that in the midst of destroyers and destructions, there is a Mediator, a great High Priest, who has an interest in heaven, and in whom saints on earth have an interest. The representation of the Divine glory from above the ark, removed to the threshold, denoted that the Lord was about to leave his mercy-seat, and to pronounce judgment on the people. The distinguishing character of this remnant that is to be saved, is such as sigh and cry to God in prayer, because of the abominations in Jerusalem. Those who keep pure in times of general wickedness, God will keep safe in times of general trouble and distress.

## Verses 5-11

The slaughter must begin at the sanctuary, that all may see and know that the Lord hates sin most in those nearest to him. He who was appointed to protect, reported the matter. Christ is faithful to the trust reposed in him. Is he commanded by his Father to secure eternal life to the chosen remnant? He says, Of all that thou hast given me, I have lost none. If others perish, and we are saved, we must ascribe the difference wholly to the mercy of our God, for we too have deserved wrath. Let us still continue to plead in behalf of others. But where the Lord shows no mercy he does no injustice; he only recompenses men's ways.


