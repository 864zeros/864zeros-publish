---
title: "Ezekiel 23 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "23"
description: "In this chapter: "
weight: 23
---

# Ezekiel 23 

## Chapter Outline

A history of the apostacy of God's people from him, and the aggravation thereof. (1-49)

## Verses 1-49

In this parable, Samaria and Israel bear the name Aholah, "her own tabernacle;" because the places of worship those kingdoms had, were of their own devising. Jerusalem and Judah bear the name of Aholibah, "my tabernacle is in her," because their temple was the place which God himself had chosen, to put his name there. The language and figures are according to those times. Will not such humbling representations of nature keep open perpetual repentance and sorrow in the soul, hiding pride from our eyes, and taking us from self-righteousness? Will it not also prompt the soul to look to God continually for grace, that by his Holy Spirit we may mortify the deeds of the body, and live in holy conversation and godliness?


