---
title: "Ezekiel 43 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "43"
description: "In this chapter: The Vision of the Temple. (1-27)."
weight: 43
---

# Ezekiel 43 

## Chapter Outline

- The Vision of the Temple. (1-27)

## Verses 1-27

After Ezekiel had surveyed the temple of God, he had a vision of the glory of God. When Christ crucified, and the things freely given to us of God, through Him, are shown to us by the Holy Ghost, they make us ashamed for our sins. This frame of mind prepares us for fuller discoveries of the mysteries of redeeming love; and the whole of the Scriptures should be opened and applied, that men may see their sins, and repent of them. We are not now to offer any atoning sacrifices, for by one offering Christ has perfected for ever those that are sanctified, Heb. 10:14; but the sprinkling of his blood is needful in all our approaches to God the Father. Our best services can be accepted only as sprinkled with the blood which cleanses from all sin.


