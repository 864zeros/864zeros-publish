---
title: "Ezekiel 33 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "33"
description: "In this chapter: Ezekiel's duty as a watchman. (1-9). He is to vindicate the Divine government. (10-20). The desolation of Judea. (21-29). Judgments on the mockers of the prophets. (30-33)."
weight: 33
---

# Ezekiel 33 

## Chapter Outline

- Ezekiel's duty as a watchman. (1-9)
- He is to vindicate the Divine government. (10-20)
- The desolation of Judea. (21-29)
- Judgments on the mockers of the prophets. (30-33)

## Verses 1-9

The prophet is a watchman to the house of Israel. His business is to warn sinners of their misery and danger. He must warn the wicked to turn from their way, that they may live. If souls perish through his neglect of duty, he brings guilt upon himself. See what those have to answer for, who make excuses for sin, flatter sinners, and encourage them to believe they shall have peace, though they go on. How much wiser are men in their temporal than in their spiritual concerns! They set watchmen to guard their houses, and sentinels to warn of the enemies' approach, but where the everlasting happiness or misery of the soul is at stake, they are offended if ministers obey their Master's command, and give a faithful warning; they would rather perish, listening to smooth things.

## Verses 10-20

Those who despaired of finding mercy with God, are answered with a solemn declaration of God's readiness to show mercy. The ruin of the city and state was determined, but that did not relate to the final state of persons. God says to the righteous, that he shall surely live. But many who have made profession, have been ruined by proud confidence in themselves. Man trusts to his own righteousness, and presuming on his own sufficiency, he is brought to commit iniquity. If those who have lived a wicked life repent and forsake their wicked ways, they shall be saved. Many such amazing and blessed changes have been wrought by the power of Divine grace. When there is a settled separation between a man and sin, there shall no longer be a separation between him and God.

## Verses 21-29

Those are unteachable indeed, who do not learn their dependence upon God, when all creature-comforts fail. Many claim an interest in the peculiar blessings to true believers, while their conduct proves them enemies of God. They call this groundless presumption strong faith, when God's testimony declares them entitled to his threatenings, and nothing else.

## Verses 30-33

Unworthy and corrupt motives often lead men to the places where the word of God is faithfully preached. Many come to find somewhat to oppose: far more come of curiosity or mere habit. Men may have their hearts changed. But whether men hear or forbear, they will know by the event that a servant of God has been among them. All who will not know the worth of mercies by the improvement of them, will justly be made to know their worth by the want of them.


