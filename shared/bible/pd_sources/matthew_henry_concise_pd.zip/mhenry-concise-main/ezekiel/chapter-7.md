---
title: "Ezekiel 7 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "7"
description: "In this chapter: The desolation of the land. (1-15). The distress of the few who should escape. (16-22). The captivity. (23-27)."
weight: 7
---

# Ezekiel 7 

## Chapter Outline

- The desolation of the land. (1-15)
- The distress of the few who should escape. (16-22)
- The captivity. (23-27)

## Verses 1-15

The abruptness of this prophecy, and the many repetitions, show that the prophet was deeply affected by the prospect of these calamities. Such will the destruction of sinners be; for none can avoid it. Oh that the wickedness of the wicked might end before it bring them to an end! Trouble is to the impenitent only an evil, it hardens their hearts, and stirs up their corruptions; but there are those to whom it is sanctified by the grace of God, and made a means of much good. The day of real trouble is near, not a mere echo or rumour of troubles. Whatever are the fruits of God's judgments, our sin is the root of them. These judgments shall be universal. And God will be glorified in all. Now is the day of the Lord's patience and mercy, but the time of the sinner's trouble is at hand.

## Verses 16-22

Sooner or later, sin will cause sorrow; and those who will not repent of their sin, may justly be left to pine away in it. There are many whose wealth is their snare and ruin; and the gaining the world is the losing of their souls. Riches profit not in the day of wrath. The wealth of this world has not that in it which will answer the desires of the soul, or be any satisfaction to it in a day of distress. God's temple shall stand them in no stead. Those are unworthy to be honoured with the form of godliness, who will not be governed by its power.

## Verses 23-27

Whoever break the bands of God's law, will find themselves bound and held by the chains of his judgments. Since they encouraged one another to sin, God would dishearten them. All must needs be in trouble, when God comes to judge them according to their deserts. May the Lord enable us to seek that good part which shall not be taken away.


