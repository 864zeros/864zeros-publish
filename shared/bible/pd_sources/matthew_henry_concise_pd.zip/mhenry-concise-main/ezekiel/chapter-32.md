---
title: "Ezekiel 32 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "32"
description: "In this chapter: The fall of Egypt. (1-16). It is like that of other nations. (17-32)."
weight: 32
---

# Ezekiel 32 

## Chapter Outline

- The fall of Egypt. (1-16)
- It is like that of other nations. (17-32)

## Verses 1-16

It becomes us to weep and tremble for those who will not weep and tremble for themselves. Great oppressors are, in God's account, no better than beasts of prey. Those who admire the pomp of this world, will wonder at the ruin of that pomp; which to those who know the vanity of all things here below, is no surprise. When others are ruined by sin, we have to fear, knowing ourselves guilty. The instruments of the desolation are formidable. And the instances of the desolation are frightful. The waters of Egypt shall run like oil, which signifies there should be universal sadness and heaviness upon the whole nation. God can soon empty those of this world's goods who have the greatest fulness of them. By enlarging the matters of our joy, we increase the occasions of our sorrow. How weak and helpless, as to God, are the most powerful of mankind! The destruction of Egypt was a type of the destruction of the enemies of Christ.

## Verses 17-32

Divers nations are mentioned as gone down to the grave before Egypt, who are ready to give her a scornful reception; these nations had been lately ruined and wasted. But though Judah and Jerusalem were about this time ruined and laid waste, yet they are not mentioned here. Though they suffered the same affliction, and by the same hand, yet the kind design for which they were afflicted, and the mercy God reserved for them, altered its nature. It was not to them a going down to the pit, as it was to the heathen. Pharaoh shall see, and be comforted; but the comfort wicked ones have after death, is poor comfort, not real, but only in fancy. The view this prophecy gives of ruined states shows something of this present world, and the empire of death in it. Come and see the calamitous state of human life. As if men did not die fast enough, they are ingenious at finding out ways to destroy one another. Also of the other world; though the destruction of nations as such, seems chiefly intended, here is plain allusion to the everlasting ruin of impenitent sinners. How are men deceived by Satan! What are the objects they pursue through scenes of bloodshed, and their many sins? Surely man disquiets himself in vain, whether he pursues wealth, fame, power, or pleasure. The hour cometh, when all that are in their graves shall hear the voice of Christ, and shall come forth; those that have done good to the resurrection of life, and those that have done evil to the resurrection of damnation.


