---
title: "Ezekiel 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The prophet is directed what he is to do. (1-5). And encouraged to be resolute, faithful, and devoted. (6-10)."
weight: 2
---

# Ezekiel 2 

## Chapter Outline

- The prophet is directed what he is to do. (1-5)
- And encouraged to be resolute, faithful, and devoted. (6-10)

## Verses 1-5

Lest Ezekiel should be lifted up with the abundance of the revelations, he is put in mind that still he is a son of man, a weak, mortal creature. As Christ usually called himself the Son of man, it was also an honourable distinction. Ezekiel's posture showed reverence, but his standing up would be a posture of greater readiness and fitness for business. God will speak to us, when we stand ready to do what he commands us. As Ezekiel had not strength of his own, the Spirit entered into him. God is graciously pleased to work in us whatever he requires of us. The Holy Spirit sets us upon our feet, by inclining our wills to our duty. Thus, when the Lord calls upon the sinner to awake, and attend to the concerns of his soul, the Spirit of life and grace comes with the call. Ezekiel is sent with a message to the children of Israel. Many might treat his message with contempt, yet they should know by the event that a prophet had been sent to them. God will be glorified, and his word made honourable, whether it be a savour of life unto life, or of death unto death.

## Verses 6-10

Those who will do any thing to purpose in the service of God, must not fear men. Wicked men are as briers and thorns; but they are nigh unto cursing, and their end is to be burned. The prophet must be faithful to the souls of those to whom he was sent. All who speak from God to others, must obey his voice. The discoveries of sin, and the warnings of wrath, should be matter of lamentation. And those acquainted with the word of God, will clearly perceive it is filled with woe to impenitent sinners; and that all the precious promises of the gospel are for the repenting, believing servants of the Lord.


