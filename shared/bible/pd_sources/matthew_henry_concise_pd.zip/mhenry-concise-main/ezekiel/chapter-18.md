---
title: "Ezekiel 18 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "18"
description: "In this chapter: God has no respect of persons. (1-20). The Divine providence is vindicated. (21-29). A gracious invitation to repentance. (30-32)."
weight: 18
---

# Ezekiel 18 

## Chapter Outline

- God has no respect of persons. (1-20)
- The Divine providence is vindicated. (21-29)
- A gracious invitation to repentance. (30-32)

## Verses 1-20

The soul that sinneth it shall die. As to eternity, every man was, is, and will be dealt with, as his conduct shows him to have been under the old covenant of works, or the new covenant of grace. Whatever outward sufferings come upon men through the sins of others, they deserve for their own sins all they suffer; and the Lord overrules every event for the eternal good of believers. All souls are in the hand of the great Creator: he will deal with them in justice or mercy; nor will any perish for the sins of another, who is not in some sense worthy of death for his own. We all have sinned, and our souls must be lost, if God deal with us according to his holy law; but we are invited to come to Christ. If a man who had shown his faith by his works, had a wicked son, whose character and conduct were the reverse of his parent's, could it be expected he should escape the Divine vengeance on account of his father's piety? Surely not. And should a wicked man have a son who walked before God as righteous, this man would not perish for his father's sins. If the son was not free from evils in this life, still he should be partaker of salvation. The question here is not about the meritorious ground of justification, but about the Lord's dealings with the righteous and the wicked.

## Verses 21-29

The wicked man would be saved, if he turned from his evil ways. The true penitent is a true believer. None of his former transgressions shall be mentioned unto him, but in the righteousness which he has done, as the fruit of faith and the effect of conversion, he shall surely live. The question is not whether the truly righteous ever become apostates. It is certain that many who for a time were thought to be righteous, do so, while 26,27 speaks the fulness of pardoning mercy: when sin is forgiven, it is blotted out, it is remembered no more. In their righteousness they shall live; not for their righteousness, as if that were an atonement for their sins, but in their righteousness, which is one of the blessings purchased by the Mediator. What encouragement a repenting, returning sinner has to hope for pardon and life according to this promise! In verse 28 is the beginning and progress of repentance. True believers watch and pray, and continue to the end, and they are saved. In all our disputes with God, he is in the right, and we are in the wrong.

## Verses 30-32

The Lord will judge each of the Israelites according to his ways. On this is grounded an exhortation to repent, and to make them a new heart and a new spirit. God does not command what cannot be done, but admonishes us to do what is in our power, and to pray for what is not. Ordinances and means are appointed, directions and promises are given, that those who desire this change may seek it from God.


