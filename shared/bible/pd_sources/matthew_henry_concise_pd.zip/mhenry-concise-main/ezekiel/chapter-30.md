---
title: "Ezekiel 30 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "30"
description: "In this chapter: A prophecy against Egypt. (1-19). Another. (20-26)."
weight: 30
---

# Ezekiel 30 

## Chapter Outline

- A prophecy against Egypt. (1-19)
- Another. (20-26)

## Verses 1-19

The prophecy of the destruction of Egypt is very full. Those who take their lot with God's enemies, shall be with them in punishment. The king of Babylon and his army shall be instruments of this destruction. God often makes one wicked man a scourge to another. No place in the land of Egypt shall escape the fury of the Chaldeans. The Lord is known by the judgments he executes. Yet these are only present effects of the Divine displeasure, not worthy of our fear, compared with the wrath to come, from which Jesus delivers his people.

## Verses 20-26

Egypt shall grow weaker and weaker. If lesser judgments do not prevail to humble and reform sinners, God will send greater. God justly breaks that power which is abused, either to put wrongs upon people, or to put cheats upon them. Babylon shall grow stronger. In vain do men endeavour to bind up the arm the Lord is pleased to break, and to strengthen those whom he will bring down. Those who disregard the discoveries of his truth and mercy, shall know his power and justice, in the punishment for their sins.


