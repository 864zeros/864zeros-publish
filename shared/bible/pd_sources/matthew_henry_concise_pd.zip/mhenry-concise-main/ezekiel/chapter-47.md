---
title: "Ezekiel 47 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "47"
description: "In this chapter: The Vision of the Temple. (1-23)."
weight: 47
---

# Ezekiel 47 

## Chapter Outline

- The Vision of the Temple. (1-23)

## Verses 1-23

These waters signify the gospel of Christ, which went forth from Jerusalem, and spread into the countries about; also the gifts and powers of the Holy Ghost which accompanied it, by virtue of which is spread far, and produced blessed effects. Christ is the Temple; and he is the Door; from him the living waters flow, out of his pierced side. They are increasing waters. Observe the progress of the gospel in the world, and the process of the work of grace in the heart; attend the motions of the blessed Spirit under Divine guidance. If we search into the things of God, we find some things plain and easy to be understood, as the waters that were but to the ankles; others more difficult, which require a deeper search, as the waters to the knees, or the loins; and some quite beyond our reach, which we cannot penetrate; but must, as St. Paul did, adore the depth, Rom. 11. It is wisdom to begin with that which is most easy, before we proceed to that which is dark and hard to be understood. The promises of the sacred word, and the privileges of believers, as shed abroad in their souls by the quickening Spirit, abound where the gospel is preached; they nourish and delight the souls of men; they never fade nor wither, nor are exhausted. Even the leaves serve as medicines to the soul: the warnings and reproofs of the word, though less pleasant than Divine consolations, tend to heal the diseases of the soul. All who believe in Christ, and are united to him by his sanctifying Spirit, will share the privileges of Israelites. There is room in the church, and in heaven, for all who seek the blessings of that new covenant of which Christ is Mediator.


