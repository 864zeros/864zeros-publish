---
title: "Ezekiel 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The preparation of the prophet for his work. (1-11). His office, as that of a watchman. (12-21). The restraining and restoring his speech. (22-27)."
weight: 3
---

# Ezekiel 3 

## Chapter Outline

- The preparation of the prophet for his work. (1-11)
- His office, as that of a watchman. (12-21)
- The restraining and restoring his speech. (22-27)

## Verses 1-11

Ezekiel was to receive the truths of God as the food for his soul, and to feed upon them by faith, and he would be strengthened. Gracious souls can receive those truths of God with delight, which speak terror to the wicked. He must speak all that, and that only, which God spake to him. How can we better speak God's mind than with his words? If disappointed as to his people, he must not be offended. The Ninevites were wrought upon by Jonah's preaching, when Israel was unhumbled and unreformed. We must leave this unto the Divine sovereignty, and say, Lord, thy judgments are a great deep. They will not regard the word of the prophet, for they will not regard the rod of God. Christ promises to strengthen him. He must continue earnest in preaching, whatever the success might be.

## Verses 12-21

This mission made the holy angels rejoice. All this was to convince Ezekiel, that the God who sent him had power to bear him out in his work. He was overwhelmed with grief for the sins and miseries of his people, and overpowered by the glory of the vision he had seen. And however retirement, meditation, and communion with God may be sweet, the servant of the Lord must prepare to serve his generation. The Lord told the prophet he had appointed him a watchman to the house of Israel. If we warn the wicked, we are not chargeable with their ruin. Though such passages refer to the national covenant made with Israel, they are equally to be applied to the final state of all men under every dispensation. We are not only to encourage and comfort those who appear to be righteous, but they are to be warned, for many have grown high-minded and secure, have fallen, and even died in their sins. Surely then the hearers of the gospel should desire warnings, and even reproofs.

## Verses 22-27

Let us own ourselves for ever indebted to the mediation of Christ, for the blessed intercourse between God and man; and a true believer will say, I am never less alone than when thus alone. When the Lord opened Ezekiel's mouth, he was to deliver his message boldly, to place life and death, the blessing and the curse, before the people, and leave them to their choice.


