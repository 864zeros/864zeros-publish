---
title: "Ezekiel 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: Divine judgments against the wicked at Jerusalem. (1-13). Divine favour towards those in captivity. (14-21). The Divine presence forsakes the city. (22-25)."
weight: 11
---

# Ezekiel 11 

## Chapter Outline

- Divine judgments against the wicked at Jerusalem. (1-13)
- Divine favour towards those in captivity. (14-21)
- The Divine presence forsakes the city. (22-25)

## Verses 1-13

Where Satan cannot persuade men to look upon the judgment to come as uncertain, he gains his point by persuading them to look upon it as at a distance. These wretched rulers dare to say, We are as safe in this city as flesh in a boiling pot; the walls of the city shall be to us as walls of brass, we shall receive no more damage from the besiegers than the caldron does from the fire. When sinners flatter themselves to their own ruin, it is time to tell them they shall have no peace if they go on. None shall remain in possession of the city but those who are buried in it. Those are least safe who are most secure. God is often pleased to single out some sinners for warning to others. Whether Pelatiah died at that time in Jerusalem, or when the fulfilment of the prophecy drew near, is uncertain. Like Ezekiel, we ought to be much affected with the sudden death of others, and we should still plead with the Lord to have mercy on those who remain.

## Verses 14-21

The pious captives in Babylon were insulted by the Jews who continued in Jerusalem; but God made gracious promises to them. It is promised, that God will give them one heart; a heart firmly fixed for God, and not wavering. All who are made holy have a new spirit, a new temper and dispositions; they act from new principles, walk by new rules, and aim at new ends. A new name, or a new face, will not serve without a new spirit. If any man be in Christ, he is a new creature. The carnal heart, like a stone, cannot be made to feel. Men live among the dead and dying, and are neither concerned nor humbled. He will make their hearts tender and fit to receive impressions: this is God's work, it is his gift by promise; and a wonderful and happy change is wrought by it, from death to life. Their practices shall be agreeable to those principles. These two must and will go together. When the sinner feels his need of these blessings, let him present the promises as prayers in the name of Christ, they will be performed.

## Verses 22-25

Here is the departure of God's presence from the city and temple. It was from the Mount of Olives that the vision went up, typifying the ascension of Christ to heaven from that very mountain. Though the Lord will not forsake his people, yet he may be driven away from any part of his visible church by their sins, and woe will be upon them when He withdraws his presence, glory, and protection.


