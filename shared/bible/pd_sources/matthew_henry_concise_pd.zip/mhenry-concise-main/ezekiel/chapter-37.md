---
title: "Ezekiel 37 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "37"
description: "In this chapter: God restores dried bones to life. (1-14). The whole house of Israel is represented as enjoying the blessings of Christ's kingdom. (15-28)."
weight: 37
---

# Ezekiel 37 

## Chapter Outline

- God restores dried bones to life. (1-14)
- The whole house of Israel is represented as enjoying the blessings of Christ's kingdom. (15-28)

## Verses 1-14

No created power could restore human bones to life. God alone could cause them to live. Skin and flesh covered them, and the wind was then told to blow upon these bodies; and they were restored to life. The wind was an emblem of the Spirit of God, and represented his quickening powers. The vision was to encourage the desponding Jews; to predict both their restoration after the captivity, and also their recovery from their present and long-continued dispersion. It was also a clear intimation of the resurrection of the dead; and it represents the power and grace of God, in the conversion of the most hopeless sinners to himself. Let us look to Him who will at last open our graves, and bring us forth to judgment, that He may now deliver us from sin, and put his Spirit within us, and keep us by his power, through faith, unto salvation.

## Verses 15-28

This emblem was to show the people, that the Lord would unite Judah and Israel. Christ is the true David, Israel's King of old; and those whom he makes willing in the day of his power, he makes to walk in his judgments, and to keep his statutes. Events yet to come will further explain this prophecy. Nothing has more hindered the success of the gospel than divisions. Let us study to keep the unity of the Spirit in the bond of peace; let us seek for Divine grace to keep us from detestable things; and let us pray that all nations may be obedient and happy subjects of the Son of David, that the Lord may be our God, and we may be his people for evermore.


