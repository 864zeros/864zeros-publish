---
title: "Acts 7 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "7"
description: "In this chapter: Stephen's defence. (1–50). Stephen reproves the Jews for the death of Christ. (51–53). The martyrdom of Stephen. (54–60)."
weight: 7
---

# Acts 7 

## Chapter Outline

- Stephen's defence. (1–50)
- Stephen reproves the Jews for the death of Christ. (51–53)
- The martyrdom of Stephen. (54–60)

## Verses 1–16

Stephen was charged as a blasphemer of God, and an apostate from the church; therefore he shows that he is a son of Abraham, and values himself on it. The slow steps by which the promise made to Abraham advanced toward performance, plainly show that it had a spiritual meaning, and that the land intended was the heavenly. God owned Joseph in his troubles, and was with him by the power of his Spirit, both on his own mind by giving him comfort, and on those he was concerned with, by giving him favour in their eyes. Stephen reminds the Jews of their mean beginning as a check to priding themselves in the glories of that nation. Likewise of the wickedness of the patriarchs of their tribes, in envying their brother Joseph; and the same spirit was still working in them toward Christ and his ministers. The faith of the patriarchs, in desiring to be buried in the land of Canaan, plainly showed they had regard to the heavenly country. It is well to recur to the first rise of usages, or sentiments, which have been perverted. Would we know the nature and effects of justifying faith, we should study the character of the father of the faithful. His calling shows the power and freeness of Divine grace, and the nature of conversion. Here also we see that outward forms and distinctions are as nothing, compared with separation from the world, and devotedness to God.

## Verses 17–29

Let us not be discouraged at the slowness of the fulfilling of God's promises. Suffering times often are growing times with the church. God is preparing for his people's deliverance, when their day is darkest, and their distress deepest. Moses was exceeding fair, “fair toward God;” it is the beauty of holiness which is in God's sight of great price. He was wonderfully preserved in his infancy; for God will take special care of those of whom he designs to make special use. And did he thus protect the child Moses? Much more will he secure the interests of his holy child Jesus, from the enemies who are gathered together against him. They persecuted Stephen for disputing in defence of Christ and his gospel: in opposition to these they set up Moses and his law. They may understand, if they do not wilfully shut their eyes against the light, that God will, by this Jesus, deliver them out of a worse slavery than that of Egypt. Although men prolong their own miseries, yet the Lord will take care of his servants, and effect his own designs of mercy.

## Verses 30–41

Men deceive themselves, if they think God cannot do what he sees to be good any where; he can bring his people into a wilderness, and there speak comfortably to them. He appeared to Moses in a flame of fire, yet the bush was not consumed; which represented the state of Israel in Egypt, where, though they were in the fire of affliction, yet they were not consumed. It may also be looked upon as a type of Christ's taking upon him the nature of man, and the union between the Divine and human nature. The death of Abraham, Isaac, and Jacob, cannot break the covenant relation between God and them. Our Saviour by this proves the future state, Mt 22:31. Abraham is dead, yet God is still his God, therefore Abraham is still alive. Now, this is that life and immortality which are brought to light by the gospel. Stephen here shows that Moses was an eminent type of Christ, as he was Israel's deliverer. God has compassion for the troubles of his church, and the groans of his persecuted people; and their deliverance takes rise from his pity. And that deliverance was typical of what Christ did, when, for us men, and for our salvation, he came down from heaven. This Jesus, whom they now refused, as their fathers did Moses, even this same has God advanced to be a Prince and Saviour. It does not at all take from the just honour of Moses to say, that he was but an instrument, and that he is infinitely outshone by Jesus. In asserting that Jesus should change the customs of the ceremonial law. Stephen was so far from blaspheming Moses, that really he honoured him, by showing how the prophecy of Moses was come to pass, which was so clear. God who gave them those customs by his servant Moses, might, no doubt, change the custom by his Son Jesus. But Israel thrust Moses from them, and would have returned to their bondage; so men in general will not obey Jesus, because they love this present evil world, and rejoice in their own works and devices.

## Verses 42–50

Stephen upbraids the Jews with the idolatry of their fathers, to which God gave them up as a punishment for their early forsaking him. It was no dishonour, but an honour to God, that the tabernacle gave way to the temple; so it is now, that the earthly temple gives way to the spiritual one; and so it will be when, at last, the spiritual shall give way to the eternal one. The whole world is God's temple, in which he is every where present, and fills it with his glory; what occasion has he then for a temple to manifest himself in? And these things show his eternal power and Godhead. But as heaven is his throne, and the earth his footstool, so none of our services can profit Him who made all things. Next to the human nature of Christ, the broken and spiritual heart is his most valued temple.

## Verses 51–53

Stephen was going on, it seems, to show that the temple and the temple service must come to an end, and it would be the glory of both to give way to the worship of the Father in spirit and in truth; but he perceived they would not bear it. Therefore he broke off, and by the Spirit of wisdom, courage, and power, sharply rebuked his persecutors. When plain arguments and truths provoke the opposers of the gospel, they should be shown their guilt and danger. They, like their fathers, were stubborn and wilful. There is that in our sinful hearts, which always resists the Holy Ghost, a flesh that lusts against the Spirit, and wars against his motions; but in the hearts of God's elect, when the fulness of time comes, this resistance is overcome. The gospel was offered now, not by angels, but from the Holy Ghost; yet they did not embrace it, for they were resolved not to comply with God, either in his law or in his gospel. Their guilt stung them to the heart, and they sought relief in murdering their reprover, instead of sorrow and supplication for mercy.

## Verses 54–60

Nothing is so comfortable to dying saints, or so encouraging to suffering saints, as to see Jesus at the right hand of God: blessed be God, by faith we may see him there. Stephen offered up two short prayers in his dying moments. Our Lord Jesus is God, to whom we are to seek, and in whom we are to trust and comfort ourselves, living and dying. And if this has been our care while we live, it will be our comfort when we die. Here is a prayer for his persecutors. Though the sin was very great, yet if they would lay it to their hearts, God would not lay it to their charge. Stephen died as much in a hurry as ever any man did, yet, when he died, the words used are, he fell asleep; he applied himself to his dying work with as much composure as if he had been going to sleep. He shall awake again in the morning of the resurrection, to be received into the presence of the Lord, where is fulness of joy, and to share the pleasures that are at his right hand, for evermore.

