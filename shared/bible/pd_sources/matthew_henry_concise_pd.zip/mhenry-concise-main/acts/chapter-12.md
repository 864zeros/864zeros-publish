---
title: "Acts 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: The martyrdom of James, and the imprisonment of Peter. (1–5). He is delivered from prison by an angel. (6–11). Peter departs, Herod's rage. (12–19). The death of Herod. (20–25)."
weight: 12
---

# Acts 12 

## Chapter Outline

- The martyrdom of James, and the imprisonment of Peter. (1–5)
- He is delivered from prison by an angel. (6–11)
- Peter departs, Herod's rage. (12–19)
- The death of Herod. (20–25)

## Verses 1–5

James was one of the sons of Zebedee, whom Christ told that they should drink of the cup that he was to drink of, and be baptized with the baptism that he was to be baptized with, Mt 20:23. Now the words of Christ were made good in him; and if we suffer with Christ, we shall reign with him. Herod imprisoned Peter: the way of persecution, as of other sins, is downhill; when men are in it, they cannot easily stop. Those make themselves an easy prey to Satan, who make it their business to please men. Thus James finished his course. But Peter, being designed for further services, was safe; though he seemed now marked out for a speedy sacrifice. We that live in a cold, prayerless generation, can hardly form an idea of the earnestness of these holy men of old. But if the Lord should bring on the church an awful persecution like this of Herod, the faithful in Christ would learn what soul-felt prayer is.

## Verses 6–11

A peaceful conscience, a lively hope, and the consolations of the Holy Spirit, can keep men calm in the full prospect of death; even those very persons who have been most distracted with terrors on that account. God's time to help, is when things are brought to the last extremity. Peter was assured that the Lord would cause this trial to end in the way that should be most for his glory. Those who are delivered out of spiritual imprisonment must follow their Deliverer, like the Israelites when they went out of the house of bondage. They knew not whither they went, but knew whom they followed. When God will work salvation for his people, all difficulties in their way will be overcome, even gates of iron are made to open of their own accord. This deliverance of Peter represents our redemption by Christ, which not only proclaims liberty to the captives, but brings them out of the prison-house. Peter, when he recollected himself, perceived what great things God had done for him. Thus souls delivered out of spiritual bondage, are not at first aware what God has wrought in them; many have the truth of grace, that want evidence of it. But when the Comforter comes, whom the Father will send, sooner or later, he will let them know what a blessed change is wrought.

## Verses 12–19

God's providence leaves room for the use of our prudence, though he has undertaken to perform and perfect what he has begun. These Christians continued in prayer for Peter, for they were truly in earnest. Thus men ought always to pray, and not to faint. As long as we are kept waiting for a mercy, we must continue praying for it. But sometimes that which we most earnestly wish for, we are most backward to believe. The Christian law of self-denial and of suffering for Christ, has not done away the natural law of caring for our own safety by lawful means. In times of public danger, all believers have God for their hiding-place; which is so secret, that the world cannot find them. Also, the instruments of persecution are themselves exposed to danger; the wrath of God hangs over all that engage in this hateful work. And the range of persecutors often vents itself on all in its way.

## Verses 20–25

Many heathen princes claimed and received Divine honours, but it was far more horrible impiety in Herod, who knew the word and worship of the living God, to accept such idolatrous honours without rebuking the blasphemy. And such men as Herod, when puffed with pride and vanity, are ripening fast for signal vengeance. God is very jealous for his own honour, and will be glorified upon those whom he is not glorified by. See what vile bodies we carry about with us; they have in them the seeds of their own dissolution, by which they will soon be destroyed, whenever God does but speak the word. We may learn wisdom from the people of Tyre and Sidon, for we have offended the Lord with our sins. We depend on him for life, and breath, and all things; it surely then behoves us to humble ourselves before him, that through the appointed Mediator, who is ever ready to befriend us, we may be reconciled to him, lest wrath come upon us to the utmost.

