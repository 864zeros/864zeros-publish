---
title: "Acts 21 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "21"
description: "In this chapter: Paul's voyage towards Jerusalem. (1–7). Paul at Cesarea. The prophecy of Agabus, Paul at Jerusalem. (8–18). He is persuaded to join in ceremonial observances. (19–26). Being in danger from the Jews, he is rescued by the Romans. (27–40)."
weight: 21
---

# Acts 21 

## Chapter Outline

- Paul's voyage towards Jerusalem. (1–7)
- Paul at Cesarea. The prophecy of Agabus, Paul at Jerusalem. (8–18)
- He is persuaded to join in ceremonial observances. (19–26)
- Being in danger from the Jews, he is rescued by the Romans. (27–40)

## Verses 1–7

Providence must be acknowledged when our affairs go on well. Wherever Paul came, he inquired what disciples were there, and found them out. Foreseeing his troubles, from love to him, and concern for the church, they wrongly thought it would be most for the glory of God that he should continue at liberty; but their earnestness to dissuade him from it, renders his pious resolution the more illustrious. He has taught us by example, as well as by rule, to pray always, to pray without ceasing. Their last farewell was sweetened with prayer.

## Verses 8–18

Paul had express warning of his troubles, that when they came, they might be no surprise or terror to him. The general notice given us, that through much tribulation we must enter into the kingdom of God, should be of the same use to us. Their weeping began to weaken and slacken his resolution Has not our Master told us to take up our cross? It was a trouble to him, that they should so earnestly press him to do that in which he could not gratify them without wronging his conscience. When we see trouble coming, it becomes us to say, not only, The will of the Lord must be done, and there is no remedy; but, Let the will of the Lord be done; for his will is his wisdom, and he doeth all according to the counsel of it. When a trouble is come, this must allay our griefs, that the will of the Lord is done; when we see it coming, this must silence our fears, that the will of the Lord shall be done; and we ought to say, Amen, let it be done. It is honourable to be an old disciple of Jesus Christ, to have been enabled by the grace of God to continue long in a course of duty, stedfast in the faith, growing more and more experienced, to a good old age. And with these old disciples one would choose to lodge; for the multitude of their years shall teach wisdom. Many brethren at Jerusalem received Paul gladly. We think, perhaps, that if we had him among us, we should gladly receive him; but we should not, if, having his doctrine, we do not gladly receive that.

## Verses 19–26

Paul ascribed all his success to God, and to God they gave the praise. God had honoured him more than any of the apostles, yet they did not envy him; but on the contrary, glorified the Lord. They could not do more to encourage Paul to go on cheerfully in his work. James and the elders of the church at Jerusalem, asked Paul to gratify the believing Jews, by some compliance with the ceremonial law. They thought it was prudent in him to conform thus far. It was great weakness to be so fond of the shadows, when the substance was come. The religion Paul preached, tended not to destroy the law, but to fulfil it. He preached Christ, the end of the law for righteousness, and repentance and faith, in which we are to make great use of the law. The weakness and evil of the human heart strongly appear, when we consider how many, even of the disciples of Christ, had not due regard to the most eminent minister that even lived. Not the excellence of his character, nor the success with which God blessed his labours, could gain their esteem and affection, seeing that he did not render the same respect as themselves to mere ceremonial observances. How watchful should we be against prejudices! The apostles were not free from blame in all they did; and it would be hard to defend Paul from the charge of giving way too much in this matter. It is vain to attempt to court the favour of zealots, or bigots to a party. This compliance of Paul did not answer, for the very thing by which he hoped to pacify the Jews, provoked them, and brought him into trouble. But the all-wise God overruled both their advice and Paul's compliance with it, to serve a better purpose than was intended. It was in vain to think of pleasing men who would be pleased with nothing but the rooting out of Christianity. Integrity and uprightness will be more likely to preserve us than insincere compliances. And it should warn us not to press men to doing what is contrary to their own judgment to oblige us.

## Verses 27–40

In the temple, where Paul should have been protected as in a place of safety, he was violently set upon. They falsely charged him with ill doctrine and ill practice against the Mosaic ceremonies. It is no new thing for those who mean honestly and act regularly, to have things laid to their charge which they know not and never thought of. It is common for the wise and good to have that charged against them by malicious people, with which they thought to have obliged them. God often makes those a protection to his people, who have no affection to them, but only have compassion for sufferers, and regard to the public peace. And here see what false, mistaken notions of good people and good ministers, many run away with. But God seasonably interposes for the safety of his servants, from wicked and unreasonable men; and gives them opportunities to speak for themselves, to plead for the Redeemer, and to spread abroad his glorious gospel.

