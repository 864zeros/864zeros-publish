---
title: "Acts 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: The appointment of deacons. (1–7). Stephen falsely accused of blasphemy. (8–15)."
weight: 6
---

# Acts 6 

## Chapter Outline

- The appointment of deacons. (1–7)
- Stephen falsely accused of blasphemy. (8–15)

## Verses 1–7

Hitherto the disciples had been of one accord; this often had been noticed to their honour; but now they were multiplied, they began to murmur. The word of God was enough to take up all the thoughts, cares, and time of the apostles. The persons chosen to serve tables must be duly qualified. They must be filled with gifts and graces of the Holy Ghost, necessary to rightly managing this trust; men of truth, and hating covetousness. All who are employed in the service of the church, ought to be commended to the Divine grace by the prayers of the church. They blessed them in the name of the Lord. The word and grace of God are greatly magnified, when those are wrought upon by it, who were least likely.

## Verses 8–15

When they could not answer Stephen's arguments as a disputant, they prosecuted him as a criminal, and brought false witnesses against him. And it is next to a miracle of providence, that no greater number of religious persons have been murdered in the world, by the way of perjury and pretence of law, when so many thousands hate them, who make no conscience of false oaths. Wisdom and holiness make a man's face to shine, yet will not secure men from being treated badly. What shall we say of man, a rational being, yet attempting to uphold a religious system by false witness and murder! And this has been done in numberless instances. But the blame rests not so much upon the understanding, as upon the heart of a fallen creature, which is deceitful above all things and desperately wicked. Yet the servant of the Lord, possessing a clear conscience, cheerful hope, and Divine consolations, may smile in the midst of danger and death.

