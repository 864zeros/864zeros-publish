---
title: "Acts 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The descent of the Holy Spirit at the day of Pentecost. (1–4). The apostles speak in divers languages. (5–13). Peter's address to the Jews. (14–36). Three thousand souls converted. (37–41). The piety and affection of the disciples. (42–47)."
weight: 2
---

# Acts 2 

## Chapter Outline

- The descent of the Holy Spirit at the day of Pentecost. (1–4)
- The apostles speak in divers languages. (5–13)
- Peter's address to the Jews. (14–36)
- Three thousand souls converted. (37–41)
- The piety and affection of the disciples. (42–47)

## Verses 1–4

We cannot forget how often, while their Master was with them there were strifes among the disciples which should be the greatest; but now all these strifes were at an end. They had prayed more together of late. Would we have the Spirit poured out upon us from on high, let us be all of one accord. And notwithstanding differences of sentiments and interests, as there were among those disciples, let us agree to love one another; for where brethren dwell together in unity, there the Lord commands his blessing. A rushing mighty wind came with great force. This was to signify the powerful influences and working of the Spirit of God upon the minds of men, and thereby upon the world. Thus the convictions of the Spirit make way for his comforts; and the rough blasts of that blessed wind, prepare the soul for its soft and gentle gales. There was an appearance of something like flaming fire, lighting on every one of them, according to John Baptist's saying concerning Christ; He shall baptize you with the Holy Ghost, and with fire. The Spirit, like fire, melts the heart, burns up the dross, and kindles pious and devout affections in the soul; in which, as in the fire on the altar, the spiritual sacrifices are offered up. They were all filled with the Holy Ghost, more than before. They were filled with the graces of the Spirit, and more than ever under his sanctifying influences; more weaned from this world, and better acquainted with the other. They were more filled with the comforts of the Spirit, rejoiced more than ever in the love of Christ and the hope of heaven: in it all their griefs and fears were swallowed up. They were filled with the gifts of the Holy Ghost; they had miraculous powers for the furtherance of the gospel. They spake, not from previous though or meditation, but as the Spirit gave them utterance.

## Verses 5–13

The difference in languages which arose at Babel, has much hindered the spread of knowledge and religion. The instruments whom the Lord first employed in spreading the Christian religion, could have made no progress without this gift, which proved that their authority was from God.

## Verses 14–21

Peter's sermon shows that he was thoroughly recovered from his fall, and thoroughly restored to the Divine favour; for he who had denied Christ, now boldly confessed him. His account of the miraculous pouring forth of the Spirit, was designed to awaken the hearers to embrace the faith of Christ, and to join themselves to his church. It was the fulfilling the Scripture, and the fruit of Christ's resurrection and ascension, and proof of both. Though Peter was filled with the Holy Ghost, and spake with tongues as the Spirit gave him utterance, yet he did not think to set aside the Scriptures. Christ's scholars never learn above their Bible; and the Spirit is given, not to do away the Scriptures, but to enable us to understand, approve, and obey them. Assuredly none will escape the condemnation of the great day, except those who call upon the name of the Lord, in and through his Son Jesus Christ, as the Saviour of sinners, and the Judge of all mankind.

## Verses 22–36

From this gift of the Holy Ghost, Peter preaches unto them Jesus: and here is the history of Christ. Here is an account of his death and sufferings, which they witnessed but a few weeks before. His death is considered as God's act; and of wonderful grace and wisdom. Thus Divine justice must be satisfied, God and man brought together again, and Christ himself glorified, according to an eternal counsel, which could not be altered. And as the people's act; in them it was an act of awful sin and folly. Christ's resurrection did away the reproach of his death; Peter speaks largely upon this. Christ was God's Holy One, sanctified and set apart to his service in the work of redemption. His death and sufferings should be, not to him only, but to all his, the entrance to a blessed life for evermore. This event had taken place as foretold, and the apostles were witnesses. Nor did the resurrection rest upon this alone; Christ had poured upon his disciples the miraculous gifts and Divine influences, of which they witnessed the effects. Through the Saviour, the ways of life are made known; and we are encouraged to expect God's presence, and his favour for evermore. All this springs from assured belief that Jesus is the Lord, and the anointed Saviour.

## Verses 37–41

From the first delivery of that Divine message, it appeared that there was Divine power going with it; and thousands were brought to the obedience of faith. But neither Peter's words, nor the miracle they witnessed, could have produced such effects, had not the Holy Spirit been given. Sinners, when their eyes are opened, cannot but be pricked to the heart for sin, cannot but feel an inward uneasiness. The apostle exhorted them to repent of their sins, and openly to avow their belief in Jesus as the Messiah, by being baptized in his name. Thus professing their faith in Him, they would receive remission of their sins, and partake of the gifts and graces of the Holy Spirit. To separate from wicked people, is the only way to save ourselves from them. Those who repent of their sins, and give up themselves to Jesus Christ, must prove their sincerity by breaking off from the wicked. We must save ourselves from them; which denotes avoiding them with dread and holy fear. By God's grace three thousand persons accepted the gospel invitation. There can be no doubt that the gift of the Holy Ghost, which they all received, and from which no true believer has ever been shut out, was that Spirit of adoption, that converting, guiding, sanctifying grace, which is bestowed upon all the members of the family of our heavenly Father. Repentance and remission of sins are still preached to the chief of sinners, in the Redeemer's name; still the Holy Spirit seals the blessing on the believer's heart; still the encouraging promises are to us and our children; and still the blessings are offered to all that are afar off.

## Verses 42–47

In these verses we have the history of the truly primitive church, of the first days of it; its state of infancy indeed, but, like that, the state of its greatest innocence. They kept close to holy ordinances, and abounded in piety and devotion; for Christianity, when admitted in the power of it, will dispose the soul to communion with God in all those ways wherein he has appointed us to meet him, and has promised to meet us. The greatness of the event raised them above the world, and the Holy Ghost filled them with such love, as made every one to be to another as to himself, and so made all things common, not by destroying property, but doing away selfishness, and causing charity. And God who moved them to it, knew that they were quickly to be driven from their possessions in Judea. The Lord, from day to day, inclined the hearts of more to embrace the gospel; not merely professors, but such as were actually brought into a state of acceptance with God, being made partakers of regenerating grace. Those whom God has designed for eternal salvation, shall be effectually brought to Christ, till the earth is filled with the knowledge of his glory.

