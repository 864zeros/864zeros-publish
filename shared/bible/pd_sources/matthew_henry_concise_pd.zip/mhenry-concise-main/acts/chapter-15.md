---
title: "Acts 15 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "15"
description: "In this chapter: The dispute raised by Judaizing teachers. (1–6). The council at Jerusalem. (7–21). The letter from the council. (22–35). Paul and Barnabas separate. (36–41)."
weight: 15
---

# Acts 15 

## Chapter Outline

- The dispute raised by Judaizing teachers. (1–6)
- The council at Jerusalem. (7–21)
- The letter from the council. (22–35)
- Paul and Barnabas separate. (36–41)

## Verses 1–6

Some from Judea taught the Gentile converts at Antioch, that they could not be saved, unless they observed the whole ceremonial law as given by Moses; and thus they sought to destroy Christian liberty. There is a strange proneness in us to think that all do wrong who do not just as we do. Their doctrine was very discouraging. Wise and good men desire to avoid contests and disputes as far as they can; yet when false teachers oppose the main truths of the gospel, or bring in hurtful doctrines, we must not decline to oppose them.

## Verses 7–21

We see from the words “purifying their hearts by faith,” and the address of St. Peter, that justification by faith, and sanctification by the Holy Ghost, cannot be separated; and that both are the gift of God. We have great cause to bless God that we have heard the gospel. May we have that faith which the great Searcher of hearts approves, and attests by the seal of the Holy Spirit. Then our hearts and consciences will be purified from the guilt of sin, and we shall be freed from the burdens some try to lay upon the disciples of Christ. Paul and Barnabas showed by plain matters of fact, that God owned the preaching of the pure gospel to the Gentiles without the law of Moses; therefore to press that law upon them, was to undo what God had done. The opinion of James was, that the Gentile converts ought not to be troubled about Jewish rites, but that they should abstain from meats offered to idols, so that they might show their hatred of idolatry. Also, that they should be cautioned against fornication, which was not abhorred by the Gentiles as it should be, and even formed a part of some of their rites. They were counselled to abstain from things strangled, and from eating blood; this was forbidden by the law of Moses, and also here, from reverence to the blood of the sacrifices, which being then still offered, it would needlessly grieve the Jewish converts, and further prejudice the unconverted Jews. But as the reason has long ceased, we are left free in this, as in the like matters. Let converts be warned to avoid all appearances of the evils which they formerly practised, or are likely to be tempted to; and caution them to use Christian liberty with moderation and prudence.

## Verses 22–35

Being warranted to declare themselves directed by the immediate influence of the Holy Ghost, the apostles and disciples were assured that it seemed good unto God the Holy Spirit, as well as to them, to lay upon the converts no other burden than the things before mentioned, which were necessary, either on their own account, or from present circumstances. It was a comfort to hear that carnal ordinances were no longer imposed on them, which perplexed the conscience, but could not purify or pacify it; and that those who troubled their minds were silenced, so that the peace of the church was restored, and that which threatened division was removed. All this was consolation for which they blessed God. Many others were at Antioch. Where many labour in the word and doctrine, yet there may be opportunity for us: the zeal and usefulness of others should stir us up, not lay us asleep.

## Verses 36–41

Here we have a private quarrel between two ministers, no less than Paul and Barnabas, yet made to end well. Barnabas wished his nephew John Mark to go with them. We should suspect ourselves of being partial, and guard against this in putting our relations forward. Paul did not think him worthy of the honour, nor fit for the service, who had departed from them without their knowledge, or without their consent: see ch. 13:13. Neither would yield, therefore there was no remedy but they must part. We see that the best of men are but men, subject to like passions as we are. Perhaps there were faults on both sides, as usual in such contentions. Christ's example alone, is a copy without a blot. Yet we are not to think it strange, if there are differences among wise and good men. It will be so while we are in this imperfect state; we shall never be all of one mind till we come to heaven. But what mischief the remainders of pride and passion which are found even in good men, do in the world, and do in the church! Many who dwelt at Antioch, who had heard but little of the devotedness and piety of Paul and Barnabas, heard of their dispute and separation; and thus it will be with ourselves, if we give way to contention. Believers must be constant in prayer, that they may never be led by the allowance of unholy tempers, to hurt the cause they really desire to serve. Paul speaks with esteem and affection both of Barnabas and Mark, in his epistles, written after this event. May all who profess thy name, O loving Saviour, be thoroughly reconciled by that love derived from thee which is not easily provoked, and which soon forgets and buries injuries.

