---
title: "Acts 14 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "14"
description: "In this chapter: Paul and Barnabas at Iconium. (1–7). A cripple healed at Lystra, The people would have sacrificed to Paul and Barnabas. (8–18). Paul stoned at Lystra, The churches visited again. (19–28)."
weight: 14
---

# Acts 14 

## Chapter Outline

- Paul and Barnabas at Iconium. (1–7)
- A cripple healed at Lystra, The people would have sacrificed to Paul and Barnabas. (8–18)
- Paul stoned at Lystra, The churches visited again. (19–28)

## Verses 1–7

The apostles spake so plainly, with such evidence and proof of the Spirit, and with such power; so warmly, and with such concern for the souls of men; that those who heard them could not but say, God was with them of a truth. Yet the success was not to be reckoned to the manner of their preaching, but to the Spirit of God who used that means. Perseverance in doing good, amidst dangers and hardships, is a blessed evidence of grace. Wherever God's servants are driven, they should seek to declare the truth. When they went on in Christ's name and strength, he failed not to give testimony to the word of his grace. He has assured us it is the word of God, and that we may venture our souls upon it. The Gentiles and Jews were at enmity with one another, yet united against Christians. If the church's enemies join to destroy it, shall not its friends unite for its preservation? God has a shelter for his people in a storm; he is, and will be their Hiding-place. In times of persecution, believers may see cause to quit a spot, though they do not quit their Master's work.

## Verses 8–18

All things are possible to those that believe. When we have faith, that most precious gift of God, we shall be delivered from the spiritual helplessness in which we were born, and from the dominion of sinful habits since formed; we shall be made able to stand upright and walk cheerfully in the ways of the Lord. When Christ, the Son of God, appeared in the likeness of men, and did many miracles, men were so far from doing sacrifice to him, that they made him a sacrifice to their pride and malice; but Paul and Barnabas, upon their working one miracle, were treated as gods. The same power of the god of this world, which closes the carnal mind against truth, makes errors and mistakes find easy admission. We do not learn that they rent their clothes when the people spake of stoning them; but when they spake of worshipping them; they could not bear it, being more concerned for God's honour than their own. God's truth needs not the services of man's falsehood. The servants of God might easily obtain undue honours if they would wink at men's errors and vices; but they must dread and detest such respect more than any reproach. When the apostles preached to the Jews, who hated idolatry, they had only to preach the grace of God in Christ; but when they had to do with the Gentiles, they must set right their mistakes in natural religion. Compare their conduct and declaration with the false opinions of those who think the worship of a God, under any name, or in any manner, is equally acceptable to the Lord Almighty. The most powerful arguments, the most earnest and affectionate addresses, even with miracles, are scarcely enough to keep men from absurdities and abominations; much less can they, without special grace, turn the hearts of sinners to God and to holiness.

## Verses 19–28

See how restless the rage of the Jews was against the gospel of Christ. The people stoned Paul, in a popular tumult. So strong is the bent of the corrupt and carnal heart, that as it is with great difficulty that men are kept back from evil on one side, so it is with great ease they are persuaded to evil on the other side. If Paul would have been Mercury, he might have been worshipped; but if he will be a faithful minister of Christ, he shall be stoned, and thrown out of the city. Thus men who easily submit to strong delusions, hate to receive the truth in the love of it. All who are converted need to be confirmed in the faith; all who are planted need to be rooted. Ministers' work is to establish saints as well as to awaken sinners. The grace of God, and nothing less, effectually establishes the souls of the disciples. It is true, we must count upon much tribulation, but it is encouragement that we shall not be lost and perish in it. The Person to whose power and grace the converts and the newly-established churches are commended, clearly was the Lord Jesus, “on whom they had believed.” It was an act of worship. The praise of all the little good we do at any time, must be ascribed to God; for it is He who not only worketh in us both to will and to do, but also worketh with us to make what we do successful. All who love the Lord Jesus, will rejoice to hear that he has opened the door of faith wide, to those who were strangers to him and to his salvation. And let us, like the apostles, abide with those who know and love the Lord.

