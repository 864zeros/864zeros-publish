---
title: "Ephesians 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: Exhortations to mutual forbearance and union. (1–6). To a due use of spiritual gifts and graces. (7–16). To purity and holiness. (17–24). And to take heed of the sins practised among the heathen. (25–32)."
weight: 4
---

# Ephesians 4 

## Chapter Outline

- Exhortations to mutual forbearance and union. (1–6)
- To a due use of spiritual gifts and graces. (7–16)
- To purity and holiness. (17–24)
- And to take heed of the sins practised among the heathen. (25–32)

## Verses 1–6

Nothing is pressed more earnestly in the Scriptures, than to walk as becomes those called to Christ's kingdom and glory. By lowliness, understand humility, which is opposed to pride. By meekness, that excellent disposition of soul, which makes men unwilling to provoke, and not easily to be provoked or offended. We find much in ourselves for which we can hardly forgive ourselves; therefore we must not be surprised if we find in others that which we think it hard to forgive. There is one Christ in whom all believers hope, and one heaven they are all hoping for; therefore they should be of one heart. They had all one faith, as to its object, Author, nature, and power. They all believed the same as to the great truths of religion; they had all been admitted into the church by one baptism, with water, in the name of the Father, and of the Son, and of the Holy Ghost, as the sign of regeneration. In all believers God the Father dwells, as in his holy temple, by his Spirit and special grace.

## Verses 7–16

Unto every believer is given some gift of grace, for their mutual help. All is given as seems best to Christ to bestow upon every one. He received for them, that he might give to them, a large measure of gifts and graces; particularly the gift of the Holy Ghost. Not a mere head knowledge, or bare acknowledging Christ to be the Son of God, but such as brings trust and obedience. There is a fulness in Christ, and a measure of that fulness given in the counsel of God to every believer; but we never come to the perfect measure till we come to heaven. God's children are growing, as long as they are in this world; and the Christian's growth tends to the glory of Christ. The more a man finds himself drawn out to improve in his station, and according to his measure, all that he has received, to the spiritual good of others, he may the more certainly believe that he has the grace of sincere love and charity rooted in his heart. (Eph 4:17-24)

## Verses 17–24

The apostle charged the Ephesians in the name and by the authority of the Lord Jesus, that having professed the gospel, they should not be as the unconverted Gentiles, who walked in vain fancies and carnal affections. Do not men, on every side, walk in the vanity of their minds? Must not we then urge the distinction between real and nominal Christians? They were void of all saving knowledge; they sat in darkness, and loved it rather than light. They had a dislike and hatred to a life of holiness, which is not only the way of life God requires and approves, and by which we live to him, but which has some likeness to God himself in his purity, righteousness, truth, and goodness. The truth of Christ appears in its beauty and power, when it appears as in Jesus. The corrupt nature is called a man; like the human body, it is of divers parts, supporting and strengthening one another. Sinful desires are deceitful lusts; they promise men happiness, but render them more miserable; and bring them to destruction, if not subdued and mortified. These therefore must be put off, as an old garment, a filthy garment; they must be subdued and mortified. But it is not enough to shake off corrupt principles; we must have gracious ones. By the new man, is meant the new nature, the new creature, directed by a new principle, even regenerating grace, enabling a man to lead a new life of righteousness and holiness. This is created, or brought forth by God's almighty power.

## Verses 25–28

Notice the particulars wherewith we should adorn our Christian profession. Take heed of every thing contrary to truth. No longer flatter or deceive others. God's people are children who will not lie, who dare not lie, who hate and abhor lying. Take heed of anger and ungoverned passions. If there is just occasion to express displeasure at what is wrong, and to reprove, see that it be without sin. We give place to the devil, when the first motions of sin are not grievous to our souls; when we consent to them; and when we repeat an evil deed. This teaches that as sin, if yielded unto, lets in the devil upon us, we are to resist it, keeping from all appearance of evil. Idleness makes thieves. Those who will not work, expose themselves to temptations to steal. Men ought to be industrious, that they may do some good, and that they may be kept from temptation. They must labour, not only that they may live honestly, but that they may have to give to the wants of others. What then must we think of those called Christians, who grow rich by fraud, oppression, and deceitful practices! Alms, to be accepted of God, must not be gained by unrighteousness and robbery, but by honesty and industry. God hates robbery for burnt-offerings.

## Verses 29–32

Filthy words proceed from corruption in the speaker, and they corrupt the minds and manners of those who hear them: Christians should beware of all such discourse. It is the duty of Christians to seek, by the blessing of God, to bring persons to think seriously, and to encourage and warn believers by their conversation. Be ye kind one to another. This sets forth the principle of love in the heart, and the outward expression of it, in a humble, courteous behaviour. Mark how God's forgiveness causes us to forgive. God forgives us, though we had no cause to sin against him. We must forgive, as he has forgiven us. All lying, and corrupt communications, that stir up evil desires and lusts, grieve the Spirit of God. Corrupt passions of bitterness, wrath, anger, clamour, evil-speaking, and malice, grieve the Holy Spirit. Provoke not the holy, blessed Spirit of God to withdraw his presence and his gracious influences. The body will be redeemed from the power of the grave at the resurrection day. Wherever that blessed Spirit dwells as a Sanctifier, he is the earnest of all the joys and glories of that redemption day; and we should be undone, should God take away his Holy Spirit from us.

