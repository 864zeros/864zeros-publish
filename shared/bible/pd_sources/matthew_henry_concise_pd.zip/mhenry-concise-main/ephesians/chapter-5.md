---
title: "Ephesians 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: Exhortation to brotherly love. (1, 2). Cautions against several sins. (3–14). Directions to a contrary behaviour, and to relative duties. (15–21). The duties of wives and husbands are enforced by the spiritual relation between Christ and the church. (22–33)."
weight: 5
---

# Ephesians 5 

## Chapter Outline

- Exhortation to brotherly love. (1, 2)
- Cautions against several sins. (3–14)
- Directions to a contrary behaviour, and to relative duties. (15–21)
- The duties of wives and husbands are enforced by the spiritual relation between Christ and the church. (22–33)

## Verses 1, 2

Because God, for Christ's sake, has forgiven you, therefore be ye followers of God, imitators of God. Resemble him especially in his love and pardoning goodness, as becomes those beloved by their heavenly Father. In Christ's sacrifice his love triumphs, and we are to consider it fully.

## Verses 3–14

Filthy lusts must be rooted out. These sins must be dreaded and detested. Here are not only cautions against gross acts of sin, but against what some may make light of. But these things are so far from being profitable. that they pollute and poison the hearers. Our cheerfulness should show itself as becomes Christians, in what may tend to God's glory. A covetous man makes a god of his money; places that hope, confidence, and delight, in worldly good, which should be in God only. Those who allow themselves, either in the lusts of the flesh or the love of the world, belong not to the kingdom of grace, nor shall they come to the kingdom of glory. When the vilest transgressors repent and believe the gospel, they become children of obedience, from whom God's wrath is turned away. Dare we make light of that which brings down the wrath of God? Sinners, like men in the dark, are going they know not whither, and doing they know not what. But the grace of God wrought a mighty change in the souls of many. Walk as children of light, as having knowledge and holiness. These works of darkness are unfruitful, whatever profit they may boast; for they end in the destruction of the impenitent sinner. There are many ways of abetting, or taking part in the sins of others; by commendation, counsel, consent, or concealment. And if we share with others in their sins, we must expect to share in their plagues. If we do not reprove the sins of others, we have fellowship with them. A good man will be ashamed to speak of what many wicked men are not ashamed to do. We must have not only a sight and a knowledge that sin is sin, and in some measure shameful, but see it as a breach of God's holy law. After the example of prophets and apostles, we should call on those asleep and dead in sin, to awake and arise, that Christ may give them light.

## Verses 15–21

Another remedy against sin, is care, or caution, it being impossible else to maintain purity of heart and life. Time is a talent given us by God, and it is misspent and lost when not employed according to his design. If we have lost our time heretofore, we must double our diligence for the future. Of that time which thousands on a dying bed would gladly redeem at the price of the whole world, how little do men think, and to what trifles they daily sacrifice it! People are very apt to complain of bad times; it were well if that stirred them more to redeem time. Be not unwise. Ignorance of our duty, and neglect of our souls, show the greatest folly. Drunkenness is a sin that never goes alone, but carries men into other evils; it is a sin very provoking to God. The drunkard holds out to his family and to the world the sad spectacle of a sinner hardened beyond what is common, and hastening to perdition. When afflicted or weary, let us not seek to raise our spirits by strong drink, which is hateful and hurtful, and only ends in making sorrows more felt. But by fervent prayer let us seek to be filled with the Spirit, and to avoid whatever may grieve our gracious Comforter. All God's people have reason to sing for joy. Though we are not always singing, we should be always giving thanks; we should never want disposition for this duty, as we never want matter for it, through the whole course of our lives. Always, even in trials and afflictions, and for all things; being satisfied of their loving intent, and good tendency. God keeps believers from sinning against him, and engages them to submit one to another in all he has commanded, to promote his glory, and to fulfil their duties to each other.

## Verses 22–33

The duty of wives is, submission to their husbands in the Lord, which includes honouring and obeying them, from a principle of love to them. The duty of husbands is to love their wives. The love of Christ to the church is an example, which is sincere, pure, and constant, notwithstanding her failures. Christ gave himself for the church, that he might sanctify it in this world, and glorify it in the next, that he might bestow on all his members a principle of holiness, and deliver them from the guilt, the pollution, and the dominion of sin, by those influences of the Holy Spirit, of which baptismal water was the outward sign. The church and believers will not be without spot or wrinkle till they come to glory. But those only who are sanctified now, shall be glorified hereafter. The words of Adam, mentioned by the apostle, are spoken literally of marriage; but they have also a hidden sense in them, relating to the union between Christ and his church. It was a kind of type, as having resemblance. There will be failures and defects on both sides, in the present state of human nature, yet this does not alter the relation. All the duties of marriage are included in unity and love. And while we adore and rejoice in the condescending love of Christ, let husbands and wives learn hence their duties to each other. Thus the worst evils would be prevented, and many painful effects would be avoided.

