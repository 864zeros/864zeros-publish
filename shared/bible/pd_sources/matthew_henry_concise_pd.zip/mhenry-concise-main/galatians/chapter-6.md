---
title: "Galatians 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: Exhortations to meekness, gentleness, and humility. (1–5). To kindness towards all men, especially believers. (6–11). The Galatians guarded against the judaizing teachers. (12–15). A solemn blessing. (16–18)."
weight: 6
---

# Galatians 6 

## Chapter Outline

- Exhortations to meekness, gentleness, and humility. (1–5)
- To kindness towards all men, especially believers. (6–11)
- The Galatians guarded against the judaizing teachers. (12–15)
- A solemn blessing. (16–18)

## Verses 1–5

We are to bear one another's burdens. So we shall fulfil the law of Christ. This obliges to mutual forbearance and compassion towards each other, agreeably to his example. It becomes us to bear one another's burdens, as fellow-travellers. It is very common for a man to look upon himself as wiser and better than other men, and as fit to dictate to them. Such a one deceives himself; by pretending to what he has not, he puts a cheat upon himself, and sooner or later will find the sad effects. This will never gain esteem, either with God or men. Every one is advised to prove his own work. The better we know our own hearts and ways, the less shall we despise others, and the more be disposed to help them under infirmities and afflictions. How light soever men's sins seem to them when committed, yet they will be found a heavy burden, when they come to reckon with God about them. No man can pay a ransom for his brother; and sin is a burden to the soul. It is a spiritual burden; and the less a man feels it to be such, the more cause has he to suspect himself. Most men are dead in their sins, and therefore have no sight or sense of the spiritual burden of sin. Feeling the weight and burden of our sins, we must seek to be eased thereof by the Saviour, and be warned against every sin.

## Verses 6–11

Many excuse themselves from the work of religion, though they may make a show, and profess it. They may impose upon others, yet they deceive themselves if they think to impose upon God, who knows their hearts as well as actions; and as he cannot be deceived, so he will not be mocked. Our present time is seed time; in the other world we shall reap as we sow now. As there are two sorts of sowing, one to the flesh, and the other to the Spirit, so will the reckoning be hereafter. Those who live a carnal, sensual life, must expect no other fruit from such a course than misery and ruin. But those who, under the guidance and influences of the Holy Spirit, live a life of faith in Christ, and abound in Christian graces, shall of the Spirit reap life everlasting. We are all very apt to tire in duty, particularly in doing good. This we should carefully watch and guard against. Only to perseverance in well-doing is the reward promised. Here is an exhortation to all to do good in their places. We should take care to do good in our life-time, and make this the business of our lives. Especially when fresh occasions offer, and as far as our power reaches.

## Verses 12–15

Proud, vain, and carnal hearts, are content with just so much religion as will help to keep up a fair show. But the apostle professes his own faith, hope, and joy; and that his principal glory was in the cross of Christ. By which is here meant, his sufferings and death on the cross, the doctrine of salvation by a crucified Redeemer. By Christ, or by the cross of Christ, the world is crucified to the believer, and he to the world. The more we consider the sufferings of the Redeemer from the world, the less likely shall we be to love the world. The apostle was as little affected by its charms, as a beholder would be by any thing which had been graceful in the face of a crucified person, when he beholds it blackened in the agonies of death. He was no more affected by the objects around him, than one who is expiring would be struck with any of the prospects his dying eyes might view from the cross on which he hung. And as to those who have truly believed in Christ Jesus, all things are counted as utterly worthless compared with him. There is a new creation; old things are passed away, and new views and dispositions are brought in under the regenerating influences of God the Holy Spirit. Believers are brought into a new world, and being created in Christ Jesus unto good works, are formed to a life of holiness. It is a change of mind and heart, whereby we are enabled to believe in the Lord Jesus, and to live to God; and where this inward, practical religion is wanting, outward professions, or names, will never stand in any stead.

## Verses 16–18

A new creation to the image of Christ, as showing faith in him, is the greatest distinction between one man and another, and a blessing is declared on all who walk according to this rule. The blessings are, peace and mercy. Peace with God and our conscience, and all the comforts of this life, as far as they are needful. And mercy, an interest in the free love and favour of God in Christ, the spring and fountain of all other blessings. The written word of God is the rule we are to go by, both in its doctrines and precepts. May his grace ever be with our spirit, to sanctify, quicken, and cheer us, and may we always be ready to maintain the honour of that which is indeed our life. The apostle had in his body the marks of the Lord Jesus, the scars of wounds from persecuting enemies, for his cleaving to Christ, and the doctrine of the gospel. The apostle calls the Galatians his brethren, therein he shows his humility and his tender affection for them; and he takes his leave with a very serious prayer, that they might enjoy the favour of Christ Jesus, both in its effects and in its evidences. We need desire no more to make us happy than the grace of our Lord Jesus Christ. The apostle does not pray that the law of Moses, or the righteousness of works, but that the grace of Christ, might be with them; that it might be in their hearts and with their spirits, quickening, comforting, and strengthening them: to all which he sets his Amen; signifying his desire that so it might be, and his faith that so it would be.

