---
title: "Galatians 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: The folly of returning to legal observances for justification. (1–7). The happy change made in the Gentile believers. (8–11). The apostle reasons against following false teachers. (12–18). He expresses his earnest concern for them. (19, 20). And then explains the difference between what is to be expected from the law, and from the gospel. (21–31)."
weight: 4
---

# Galatians 4 

## Chapter Outline

- The folly of returning to legal observances for justification. (1–7)
- The happy change made in the Gentile believers. (8–11)
- The apostle reasons against following false teachers. (12–18)
- He expresses his earnest concern for them. (19, 20)
- And then explains the difference between what is to be expected from the law, and from the gospel. (21–31)

## Verses 1–7

The apostle deals plainly with those who urged the law of Moses together with the gospel of Christ, and endeavoured to bring believers under its bondage. They could not fully understand the meaning of the law as given by Moses. And as that was a dispensation of darkness, so of bondage; they were tied to many burdensome rites and observances, by which they were taught and kept subject like a child under tutors and governors. We learn the happier state of Christians under the gospel dispensation. From these verses see the wonders of Divine love and mercy; particularly of God the Father, in sending his Son into the world to redeem and save us; of the Son of God, in submitting so low, and suffering so much for us; and of the Holy Spirit, in condescending to dwell in the hearts of believers, for such gracious purposes. Also, the advantages Christians enjoy under the gospel. Although by nature children of wrath and disobedience, they become by grace children of love, and partake of the nature of the children of God; for he will have all his children resemble him. Among men the eldest son is heir; but all God's children shall have the inheritance of eldest sons. May the temper and conduct of sons ever show our adoption; and may the Holy Spirit witness with our spirits that we are children and heirs of God.

## Verses 8–11

The happy change whereby the Galatians were turned from idols to the living God, and through Christ had received the adoption of sons, was the effect of his free and rich grace; they were laid under the greater obligation to keep to the liberty wherewith he had made them free. All our knowledge of God begins on his part; we know him because we are known of him. Though our religion forbids idolatry, yet many practise spiritual idolatry in their hearts. For what a man loves most, and cares most for, that is his god: some have their riches for their god, some their pleasures, and some their lusts. And many ignorantly worship a god of their own making; a god made all of mercy and no justice. For they persuade themselves that there is mercy for them with God, though they repent not, but go on in their sins. It is possible for those who have made great professions of religion, to be afterwards drawn aside from purity and simplicity. And the more mercy God has shown, in bringing any to know the gospel, and the liberties and privileges of it, the greater their sin and folly in suffering themselves to be deprived of them. Hence all who are members of the outward church should learn to fear and to suspect themselves. We must not be content because we have some good things in ourselves. Paul fears lest his labour is in vain, yet he still labours; and thus to do, whatever follows, is true wisdom and the fear of God. This every man must remember in his place and calling.

## Verses 12–18

The apostle desires that they would be of one mind with him respecting the law of Moses, as well as united with him in love. In reproving others, we should take care to convince them that our reproofs are from sincere regard to the honour of God and religion and their welfare. The apostle reminds the Galatians of the difficulty under which he laboured when he first came among them. But he notices, that he was a welcome messenger to them. Yet how very uncertain are the favour and respect of men! Let us labour to be accepted of God. You once thought yourselves happy in receiving the gospel; have you now reason to think otherwise? Christians must not forbear speaking the truth, for fear of offending others. The false teachers who drew the Galatians from the truth of the gospel were designing men. They pretended affection, but they were not sincere and upright. An excellent rule is given. It is good to be zealous always in a good thing; not for a time only, or now and then, but always. Happy would it be for the church of Christ, if this zeal was better maintained.

## Verses 19, 20

The Galatians were ready to account the apostle their enemy, but he assures them he was their friend; he had the feelings of a parent toward them. He was in doubt as to their state, and was anxious to know the result of their present delusions. Nothing is so sure a proof that a sinner has passed into a state of justification, as Christ being formed in him by the renewal of the Holy Spirit; but this cannot be hoped for, while men depend on the law for acceptance with God.

## Verses 21–27

The difference between believers who rested in Christ only, and those who trusted in the law, is explained by the histories of Isaac and Ishmael. These things are an allegory, wherein, beside the literal and historical sense of the words, the Spirit of God points out something further. Hagar and Sarah were apt emblems of the two different dispensations of the covenant. The heavenly Jerusalem, the true church from above, represented by Sarah, is in a state of freedom, and is the mother of all believers, who are born of the Holy Spirit. They were by regeneration and true faith, made a part of the true seed of Abraham, according to the promise made to him.

## Verses 28–31

The history thus explained is applied. So then, brethren, we are not children of the bond-woman, but of the free. If the privileges of all believers were so great, according to the new covenant, how absurd for the Gentile converts to be under that law, which could not deliver the unbelieving Jews from bondage or condemnation! We should not have found out this allegory in the history of Sarah and Hagar, if it had not been shown to us, yet we cannot doubt it was intended by the Holy Spirit. It is an explanation of the subject, not an argument in proof of it. The two covenants of works and grace, and legal and evangelical professors, are shadowed forth. Works and fruits brought forth in a man's own strength, are legal. But if arising from faith in Christ, they are evangelical. The first covenant spirit is of bondage unto sin and death. The second covenant spirit is of liberty and freedom; not liberty to sin, but in and unto duty. The first is a spirit of persecution; the second is a spirit of love. Let those professors look to it, who have a violent, harsh, imposing spirit, towards the people of God. Yet as Abraham turned aside to Hagar, so it is possible a believer may turn aside in some things to the covenant of works, when through unbelief and neglect of the promise he acts according to the law, in his own strength; or in a way of violence, not of love, towards the brethren. Yet it is not his way, not his spirit to do so; hence he is never at rest, till he returns to his dependence on Christ again. Let us rest our souls on the Scriptures, and by a gospel hope and cheerful obedience, show that our conversation and treasure are indeed in heaven.

