---
title: "1 Peter 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: The consideration of Christ's sufferings is urged for purity and holiness. (1–6). And the approaching end of the Jewish state, as a reason for sobriety, watchfulness, and prayer. (7–11). Believers encouraged to rejoice and glory in reproaches and sufferings for Christ, and to commit their souls to the care of a faithful God. (12–19)."
weight: 4
---

# 1 Peter 4 

## Chapter Outline

- The consideration of Christ's sufferings is urged for purity and holiness. (1–6)
- And the approaching end of the Jewish state, as a reason for sobriety, watchfulness, and prayer. (7–11)
- Believers encouraged to rejoice and glory in reproaches and sufferings for Christ, and to commit their souls to the care of a faithful God. (12–19)

## Verses 1–6

The strongest and best arguments against sin, are taken from the sufferings of Christ. He died to destroy sin; and though he cheerfully submitted to the worst sufferings, yet he never gave way to the least sin. Temptations could not prevail, were it not for man's own corruption; but true Christians make the will of God, not their own lust or desires, the rule of their lives and actions. And true conversion makes a marvellous change in the heart and life. It alters the mind, judgment, affections, and conversation. When a man is truly converted, it is very grievous to him to think how the time past of his life has been spent. One sin draws on another. Six sins are here mentioned which have dependence one upon another. It is a Christian's duty, not only to keep from gross wickedness, but also from things that lead to sin, or appear evil. The gospel had been preached to those since dead, who by the proud and carnal judgment of wicked men were condemned as evil-doers, some even suffering death. But being quickened to Divine life by the Holy Spirit, they lived to God as his devoted servants. Let not believers care, though the world scorns and reproaches them.

## Verses 7–11

The destruction of the Jewish church and nation, foretold by our Saviour, was very near. And the speedy approach of death and judgment concerns all, to which these words naturally lead our minds. Our approaching end, is a powerful argument to make us sober in all worldly matters, and earnest in religion. There are so many things amiss in all, that unless love covers, excuses, and forgives in others, the mistakes and faults for which every one needs the forbearance of others, Satan will prevail to stir up divisions and discords. But we are not to suppose that charity will cover or make amends for the sins of those who exercise it, so as to induce God to forgive them. The nature of a Christian's work, which is high work and hard work, the goodness of the Master, and the excellence of the reward, all require that our endeavours should be serious and earnest. And in all the duties and services of life, we should aim at the glory of God as our chief end. He is a miserable, unsettled wretch, who cleaves to himself, and forgets God; is only perplexed about his credit, and gain, and base ends, which are often broken, and which, when he attains, both he and they must shortly perish together. But he who has given up himself and his all to God, may say confidently that the Lord is his portion; and nothing but glory through Christ Jesus, is solid and lasting; that abideth for ever.

## Verses 12–19

By patience and fortitude in suffering, by dependence on the promises of God, and keeping to the word the Holy Spirit hath revealed, the Holy Spirit is glorified; but by the contempt and reproaches cast upon believers, he is evil spoken of, and is blasphemed. One would think such cautions as these were needless to Christians. But their enemies falsely charged them with foul crimes. And even the best of men need to be warned against the worst of sins. There is no comfort in sufferings, when we bring them upon ourselves by our own sin and folly. A time of universal calamity was at hand, as foretold by our Saviour, Mt 24:9, 10. And if such things befall in this life, how awful will the day of judgment be! It is true that the righteous are scarcely saved; even those who endeavour to walk uprightly in the ways of God. This does not mean that the purpose and performance of God are uncertain, but only the great difficulties and hard encounters in the way; that they go through so many temptations and tribulations, so many fightings without and fears within. Yet all outward difficulties would be as nothing, were it not for lusts and corruptions within. These are the worst clogs and troubles. And if the way of the righteous be so hard, then how hard shall be the end of the ungodly sinner, who walks in sin with delight, and thinks the righteous is a fool for all his pains! The only way to keep the soul well, is, to commit it to God by prayer, and patient perseverance in well-doing. He will overrule all to the final advantage of the believer.

