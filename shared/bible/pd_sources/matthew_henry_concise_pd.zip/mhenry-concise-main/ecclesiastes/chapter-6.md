---
title: "Ecclesiastes 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: The vanity of riches. Also of long life and flourishing families. (1-6). The little advantage any one has in outward things. (7-12)."
weight: 6
---

# Ecclesiastes 6 

## Chapter Outline

- The vanity of riches. Also of long life and flourishing families. (1-6)
- The little advantage any one has in outward things. (7-12)

## Verses 1-6

A man often has all he needs for outward enjoyment; yet the Lord leaves him so to covetousness or evil dispositions, that he makes no good or comfortable use of what he has. By one means or other his possessions come to strangers; this is vanity, and an evil disease. A numerous family was a matter of fond desire and of high honour among the Hebrews; and long life is the desire of mankind in general. Even with these additions a man may not be able to enjoy his riches, family, and life. Such a man, in his passage through life, seems to have been born for no end or use. And he who has entered on life only for one moment, to quit it the next, has a preferable lot to him who has lived long, but only to suffer.

## Verses 7-12

A little will serve to sustain us comfortably, and a great deal can do no more. The desires of the soul find nothing in the wealth of the world to give satisfaction. The poor man has comfort as well as the richest, and is under no real disadvantage. We cannot say, Better is the sight of the eyes than the resting of the soul in God; for it is better to live by faith in things to come, than to live by sense, which dwells only upon present things. Our lot is appointed. We have what pleases God, and let that please us. The greatest possessions and honours cannot set us above the common events of human life. Seeing that the things men pursue on earth increase vanities, what is man the better for his worldly devices? Our life upon earth is to be reckoned by days. It is fleeting and uncertain, and with little in it to be fond of, or to be depended on. Let us return to God, trust in his mercy through Jesus Christ, and submit to his will. Then soon shall we glide through this vexatious world, and find ourselves in that happy place, where there is fulness of joy and pleasures for evermore.


