---
title: "Ecclesiastes 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: What renders devotion vain. (1-3). Of vows, and oppression. (4-8). the vanity of riches shown. (9-7). The right use of riches. (18-20)."
weight: 5
---

# Ecclesiastes 5 

## Chapter Outline

- What renders devotion vain. (1-3)
- Of vows, and oppression. (4-8)
- the vanity of riches shown. (9-7)
- The right use of riches. (18-20)

## Verses 1-3

Address thyself to the worship of God, and take time to compose thyself for it. Keep thy thoughts from roving and wandering: keep thy affections from running out toward wrong objects. We should avoid vain repetitions; copious prayers are not here condemned, but those that are unmeaning. How often our wandering thoughts render attendance on Divine ordinances little better than the sacrifice of fools! Many words and hasty ones, used in prayer, show folly in the heart, low thoughts of God, and careless thoughts of our own souls.

## Verses 4-8

When a person made engagements rashly, he suffered his mouth to cause his flesh to sin. The case supposes a man coming to the priest, and pretending that his vow was made rashly, and that it would be wrong to fulfil it. Such mockery of God would bring the Divine displeasure, which might blast what was thus unduly kept. We are to keep down the fear of man. Set God before thee; then, if thou seest the oppression of the poor, thou wilt not find fault with Divine Providence; nor think the worse of the institution of magistracy, when thou seest the ends of it thus perverted; nor of religion, when thou seest it will not secure men from suffering wrong. But though oppressors may be secure, God will reckon for all.

## Verses 9-17

The goodness of Providence is more equally distributed than appears to a careless observer. The king needs the common things of life, and the poor share them; they relish their morsel better than he does his luxuries. There are bodily desires which silver itself will not satisfy, much less will worldly abundance satisfy spiritual desires. The more men have, the better house they must keep, the more servants they must employ, the more guests they must entertain, and the more they will have hanging on them. The sleep of the labourer is sweet, not only because he is tired, but because he has little care to break his sleep. The sleep of the diligent Christian, and his long sleep, are sweet; having spent himself and his time in the service of God, he can cheerfully repose in God as his Rest. But those who have every thing else, often fail to secure a good night's sleep; their abundance breaks their rest. Riches do hurt, and draw away the heart from God and duty. Men do hurt with their riches, not only gratifying their own lusts, but oppressing others, and dealing hardly with them. They will see that they have laboured for the wind, when, at death, they find the profit of their labour is all gone like the wind, they know not whither. How ill the covetous worldling bears the calamities of human life! He does not sorrow to repentance, but is angry at the providence of God, angry at all about him; which doubles his affliction.

## Verses 18-20

Life is God's gift. We must not view our calling as a drudgery, but take pleasure in the calling where God puts us. A cheerful spirit is a great blessing; it makes employments easy, and afflictions light. Having made a proper use of riches, a man will remember the days of his past life with pleasure. The manner in which Solomon refers to God as the Giver, both of life and its enjoyments, shows they ought to be received and to be used, consistently with his will, and to his glory. Let this passage recommend to all the kind words of the merciful Redeemer, "Labour not for the meat that perisheth, but for that meat which endureth unto everlasting life." Christ is the Bread of life, the only food of the soul. All are invited to partake of this heavenly provision.


