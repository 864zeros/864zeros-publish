---
title: "Ecclesiastes 9 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "9"
description: "In this chapter: Good and bad men fare alike as to this world. (1-3). All men must die, Their portion as to this life. (4-10). Disappointments common. (11,12) . Benefits of wisdom. (13-18)."
weight: 9
---

# Ecclesiastes 9 

## Chapter Outline

- Good and bad men fare alike as to this world. (1-3)
- All men must die, Their portion as to this life. (4-10)
- Disappointments common. (11,12) 
- Benefits of wisdom. (13-18)

## Verses 1-3

We are not to think our searching into the word or works of God useless, because we cannot explain all difficulties. We may learn many things good for ourselves and useful to others. But man cannot always decide who are objects of God's special love, or under his wrath; and God will certainly put a difference between the precious and the vile, in the other world. The difference as to present happiness, arises from the inward supports and consolations the righteous enjoy, and the benefit they derive from varied trials and mercies. As far as the sons of men are left to themselves, their hearts are full of evil; and prosperity in sin, causes them even to set God at defiance by daring wickedness. Though, on this side death, the righteous and the wicked may often seem to fare alike, on the other side there will be a vast difference between them.

## Verses 4-10

The most despicable living man's state, is preferable to that of the most noble who have died impenitent. Solomon exhorts the wise and pious to cheerful confidence in God, whatever their condition in life. The meanest morsel, coming from their Father's love, in answer to prayer, will have a peculiar relish. Not that we may set our hearts upon the delights of sense, but what God has given us we may use with wisdom. The joy here described, is the gladness of heart that springs from a sense of the Divine favour. This is the world of service, that to come is the world of recompence. All in their stations, may find some work to do. And above all, sinners have the salvation of their souls to seek after, believers have to prove their faith, adorn the gospel, glorify God, and serve their generation.

## Verses 11,12 

Men's success seldom equals their expectations. We must use means, but not trust to them: if we succeed, we must give God the praise; if crossed, we must submit to his will. Those who put off the great concerns of their souls, are caught in Satan's net, which he baits with some worldly object, for which they reject or neglect the gospel, and go on in sin till they suddenly fall into destruction.

## Verses 13-18

A man may, by his wisdom, bring to pass that which he could never do by his strength. If God be for us, who can be against us, or stand before us? Solomon observes the power of wisdom, though it may labour under outward disadvantages. How forcible are right words! But wise and good men must often content themselves with the satisfaction of having done good, or, at least, endeavoured to do it, when they cannot do the good they would, nor have the praise they should. How many of the good gifts, both of nature and Providence, does one sinner destroy and make waste! He who destroys his own soul destroys much good. One sinner may draw many into his destroying ways. See who are the friends and enemies of a kingdom or a family, if one saint does much good, and one sinner destroys much good.


