---
title: "Ecclesiastes 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: To preserve a character for wisdom. (1-3). Respecting subjects and rulers. (4-10). Of foolish talk. (11-15). Duties of rulers and subjects. (16-20)."
weight: 10
---

# Ecclesiastes 10 

## Chapter Outline

- To preserve a character for wisdom. (1-3)
- Respecting subjects and rulers. (4-10)
- Of foolish talk. (11-15)
- Duties of rulers and subjects. (16-20)

## Verses 1-3

Those especially who make a profession of religion, should keep from all appearances of evil. A wise man has great advantage over a fool, who is always at a loss when he has anything to do. Sin is the reproach of sinners, wherever they go, and shows their folly.

## Verses 4-10

Solomon appears to caution men not to seek redress in a hasty manner, nor to yield to pride and revenge. Do not, in a passion, quit thy post of duty; wait awhile, and thou wilt find that yielding pacifies great offences. Men are not preferred according to their merit. And those are often most forward to offer help, who are least aware of the difficulties, or the consequences. The same remark is applied to the church, or the body of Christ, that all the members should have the same care one for another.

## Verses 11-15

There is a practice in the East, of charming serpents by music. The babbler's tongue is an unruly evil, full of deadly poison; and contradiction only makes it the more violent. We must find the way to keep him gentle. But by rash, unprincipled, or slanderous talk, he brings open or secret vengeance upon himself. Would we duly consider our own ignorance as to future events, it would cut off many idle words which we foolishly multiply. Fools toil a great deal to no purpose. They do not understand the plainest things, such as the entrance into a great city. But it is the excellency of the way to the heavenly city, that it is a high-way, in which the simplest wayfaring men shall not err, 8. But sinful folly makes men miss that only way to happiness.

## Verses 16-20

The happiness of a land depends on the character of its rulers. The people cannot be happy when their princes are childish, and lovers of pleasure. Slothfulness is of ill consequence both to private and public affairs. Money, of itself, will neither feed nor clothe, though it answers the occasions of this present life, as what is to be had, may generally be had for money. But the soul, as it is not redeemed, so it is not maintained with corruptible things, as silver and gold. God sees what men do, and hears what they say in secret; and, when he pleases, brings it to light by strange and unsuspected ways. If there be hazard in secret thoughts and whispers against earthly rulers, what must be the peril from every deed, word, or thought of rebellion against the King of kings, and Lord of lords! He seeth in secret. His ear is ever open. Sinner! curse not THIS KING in thy inmost thought. Your curses cannot affect Him; but his curse, coming down upon you, will sink you to the lowest hell.


