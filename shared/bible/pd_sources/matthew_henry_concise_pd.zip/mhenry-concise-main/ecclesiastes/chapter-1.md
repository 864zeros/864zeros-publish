---
title: "Ecclesiastes 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: Solomon shows that all human things are vain. (1-3). Man's toil and want of satisfaction. (4-8). There is nothing new. (9-11). The vexation in pursuit of knowledge. (12-18)."
weight: 1
---

# Ecclesiastes 1 

## Chapter Outline

- Solomon shows that all human things are vain. (1-3)
- Man's toil and want of satisfaction. (4-8)
- There is nothing new. (9-11)
- The vexation in pursuit of knowledge. (12-18)

## Verses 1-3

Much is to be learned by comparing one part of Scripture with another. We here behold Solomon returning from the broken and empty cisterns of the world, to the Fountain of living water; recording his own folly and shame, the bitterness of his disappointment, and the lessons he had learned. Those that have taken warning to turn and live, should warn others not to go on and die. He does not merely say all things are vain, but that they are vanity. VANITY OF VANITIES, ALL IS VANITY. This is the text of the preacher's sermon, of which in this book he never loses sight. If this world, in its present state, were all, it would not be worth living for; and the wealth and pleasure of this world, if we had ever so much, are not enough to make us happy. What profit has a man of all his labour? All he gets by it will not supply the wants of the soul, nor satisfy its desires; will not atone for the sins of the soul, nor hinder the loss of it: what profit will the wealth of the world be to the soul in death, in judgment, or in the everlasting state?

## Verses 4-8

All things change, and never rest. Man, after all his labour, is no nearer finding rest than the sun, the wind, or the current of the river. His soul will find no rest, if he has it not from God. The senses are soon tired, yet still craving what is untried.

## Verses 9-11

Men's hearts and their corruptions are the same now as in former times; their desires, and pursuits, and complaints, still the same. This should take us from expecting happiness in the creature, and quicken us to seek eternal blessings. How many things and persons in Solomon's day were thought very great, yet there is no remembrance of them now!

## Verses 12-18

Solomon tried all things, and found them vanity. He found his searches after knowledge weariness, not only to the flesh, but to the mind. The more he saw of the works done under the sun, the more he saw their vanity; and the sight often vexed his spirit. He could neither gain that satisfaction to himself, nor do that good to others, which he expected. Even the pursuit of knowledge and wisdom discovered man's wickedness and misery; so that the more he knew, the more he saw cause to lament and mourn. Let us learn to hate and fear sin, the cause of all this vanity and misery; to value Christ; to seek rest in the knowledge, love, and service of the Saviour.


