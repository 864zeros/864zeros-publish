---
title: "Ecclesiastes 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: Miseries from oppression. (1-3). troubles from envy. (4-6). The folly of covetousness. (7,8) . The advantages of mutual assistance. (9-12). the changes of royalty. (13-16)."
weight: 4
---

# Ecclesiastes 4 

## Chapter Outline

- Miseries from oppression. (1-3)
- troubles from envy. (4-6)
- The folly of covetousness. (7,8) 
- The advantages of mutual assistance. (9-12)
- the changes of royalty. (13-16)

## Verses 1-3

It grieved Solomon to see might prevail against right. Wherever we turn, we see melancholy proofs of the wickedness and misery of mankind, who try to create trouble to themselves and to each other. Being thus hardly used, men are tempted to hate and despise life. But a good man, though badly off while in this world, cannot have cause to wish he had never been born, since he is glorifying the Lord, even in the fires, and will be happy at last, for ever happy. Ungodly men have most cause to wish the continuance of life with all its vexations, as a far more miserable condition awaits them if they die in their sins. If human and worldly things were our chief good, not to exist would be preferable to life, considering the various oppressions here below.

## Verses 4-6

Solomon notices the sources of trouble peculiar to well-doers, and includes all who labour with diligence, and whose efforts are crowned with success. They often become great and prosperous, but this excites envy and opposition. Others, seeing the vexations of an active course, foolishly expect more satisfaction in sloth and idleness. But idleness is a sin that is its own punishment. Let us by honest industry lay hold on the handful, that we may not want necessaries, but not grasp at both hands full, which would only create vexation of spirit. Moderate pains and gains do best.

## Verses 7,8 

Frequently, the more men have, the more they would have; and on this they are so intent, that they get no enjoyment from what they have. Selfishness is the cause of this evil. A selfish man cares for nobody; there is none to take care of but himself, yet he will scarcely allow necessary rest to himself, and the people he employs. He never thinks he has enough. He has enough for his calling, for his family, but he has not enough for his eyes. Many are so set upon the world, that in pursuit of it they bereave themselves, not only of the favour of God and eternal life, but of the pleasures of this life. The distant relations or strangers who inherit such a man's wealth, never thank him. Covetousness gathers strength by time and habit; men tottering on the brink of the grave, grow more grasping and griping. Alas, and how often do we see men professing to be followers of Him, who, "though he was rich, for our sakes became poor," anxiously scraping money together and holding it fast, excusing themselves by common-place talking about the necessity of care, and the danger of extravagance!

## Verses 9-12

Surely he has more satisfaction in life, who labours hard to maintain those he loves, than the miser has in his toil. In all things union tends to success and safety, but above all, the union of Christians. They assist each other by encouragement, or friendly reproof. They warm each other's hearts while they converse together of the love of Christ, or join in singing his praises. Then let us improve our opportunities of Christian fellowship. In these things all is not vanity, though there will be some alloy as long as we are under the sun. Where two are closely joined in holy love and fellowship, Christ will by his Spirit come to them; then there is a threefold cord.

## Verses 13-16

People are never long easy and satisfied; they are fond of changes. This is no new thing. Princes see themselves slighted by those they have studied to oblige; this is vanity and vexation of spirit. But the willing servants of the Lord Jesus, our King, rejoice in him alone, and they will love Him more and more to all eternity.


