---
title: "Ecclesiastes 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The vanity and vexation of mirth, sensual pleasure, riches, and pomp. (1-11). Human wisdom insufficient. (12-17). This world to be used according to the will of God. (18-26)."
weight: 2
---

# Ecclesiastes 2 

## Chapter Outline

- The vanity and vexation of mirth, sensual pleasure, riches, and pomp. (1-11)
- Human wisdom insufficient. (12-17)
- This world to be used according to the will of God. (18-26)

## Verses 1-11

Solomon soon found mirth and pleasure to be vanity. What does noisy, flashy mirth towards making a man happy? The manifold devices of men's hearts, to get satisfaction from the world, and their changing from one thing to another, are like the restlessness of a man in a fever. Perceiving it was folly to give himself to wine, he next tried the costly amusements of princes. The poor, when they read such a description, are ready to feel discontent. But the remedy against all such feelings is in the estimate of it all by the owner himself. All was vanity and vexation of spirit: and the same things would yield the same result to us, as to Solomon. Having food and raiment, let us therewith be content. His wisdom remained with him; a strong understanding, with great human knowledge. But every earthly pleasure, when unconnected with better blessings, leaves the mind as eager and unsatisfied as before. Happiness arises not from the situation in which we are placed. It is only through Jesus Christ that final blessedness can be attained.

## Verses 12-17

Solomon found that knowledge and prudence were preferable to ignorance and folly, though human wisdom and knowledge will not make a man happy. The most learned of men, who dies a stranger to Christ Jesus, will perish equally with the most ignorant; and what good can commendations on earth do to the body in the grave, or the soul in hell? And the spirits of just men made perfect cannot want them. So that if this were all, we might be led to hate our life, as it is all vanity and vexation of spirit.

## Verses 18-26

Our hearts are very loth to quit their expectations of great things from the creature; but Solomon came to this at length. The world is a vale of tears, even to those that have much of it. See what fools they are, who make themselves drudges to the world, which affords a man nothing better than subsistence for the body. And the utmost he can attain in this respect is to allow himself a sober, cheerful use thereof, according to his rank and condition. But we must enjoy good in our labour; we must use those things to make us diligent and cheerful in worldly business. And this is the gift of God. Riches are a blessing or a curse to a man, according as he has, or has not, a heart to make a good use of them. To those that are accepted of the Lord, he gives joy and satisfaction in the knowledge and love of him. But to the sinner he allots labour, sorrow, vanity, and vexation, in seeking a worldly portion, which yet afterwards comes into better hands. Let the sinner seriously consider his latter end. To seek a lasting portion in the love of Christ and the blessings it bestows, is the only way to true and satisfying enjoyment even of this present world.


