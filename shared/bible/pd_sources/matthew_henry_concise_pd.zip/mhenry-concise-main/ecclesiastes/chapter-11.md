---
title: "Ecclesiastes 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: Exhortation to liberality. (1-6). An admonition to prepare for death, and to young persons to be religious. (7-10)."
weight: 11
---

# Ecclesiastes 11 

## Chapter Outline

- Exhortation to liberality. (1-6)
- An admonition to prepare for death, and to young persons to be religious. (7-10)

## Verses 1-6

Solomon presses the rich to do good to others. Give freely, though it may seem thrown away and lost. Give to many. Excuse not thyself with the good thou hast done, from the good thou hast further to do. It is not lost, but well laid out. We have reason to expect evil, for we are born to trouble; it is wisdom to do good in the day of prosperity. Riches cannot profit us, if we do not benefit others. Every man must labour to be a blessing to that place where the providence of God casts him. Wherever we are, we may find good work to do, if we have but hearts to do it. If we magnify every little difficulty, start objections, and fancy hardships, we shall never go on, much less go through with our work. Winds and clouds of tribulation are, in God's hands, designed to try us. God's work shall agree with his word, whether we see it or not. And we may well trust God to provide for us, without our anxious, disquieting cares. Be not weary in well-doing, for in due season, in God's time, you shall reap, Gal. 6:9.

## Verses 7-10

Life is sweet to bad men, because they have their portion in this life; it is sweet to good men, because it is the time of preparation for a better; it is sweet to all. Here is a caution to think of death, even when life is most sweet. Solomon makes an effecting address to young persons. They would desire opportunity to pursue every pleasure. Then follow your desires, but be assured that God will call you into judgment. How many give loose to every appetite, and rush into every vicious pleasure! But God registers every one of their sinful thoughts and desires, their idle words and wicked words. If they would avoid remorse and terror, if they would have hope and comfort on a dying bed, if they would escape misery here and hereafter, let them remember the vanity of youthful pleasures. That Solomon means to condemn the pleasures of sin is evident. His object is to draw the young to purer and more lasting joys. This is not the language of one grudging youthful pleasures, because he can no longer partake of them; but of one who has, by a miracle of mercy, been brought back in safety. He would persuade the young from trying a course whence so few return. If the young would live a life of true happiness, if they would secure happiness hereafter, let them remember their Creator in the days of their youth.


