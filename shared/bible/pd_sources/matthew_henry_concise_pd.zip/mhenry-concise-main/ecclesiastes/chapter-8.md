---
title: "Ecclesiastes 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: Commendations of wisdom. (1-5). To prepare for sudden evils and death. (6-8). It shall be well with the righteous, and ill with the wicked. (9-13). Mysteries of Providence. (14-17)."
weight: 8
---

# Ecclesiastes 8 

## Chapter Outline

- Commendations of wisdom. (1-5)
- To prepare for sudden evils and death. (6-8)
- It shall be well with the righteous, and ill with the wicked. (9-13)
- Mysteries of Providence. (14-17)

## Verses 1-5

None of the rich, the powerful, the honourable, or the accomplished of the sons of men, are so excellent, useful, or happy, as the wise man. Who else can interpret the words of God, or teach aright from his truths and dispensations? What madness must it be for weak and dependent creatures to rebel against the Almighty! What numbers form wrong judgments, and bring misery on themselves, in this life and that to come!

## Verses 6-8

God has, in wisdom, kept away from us the knowledge of future events, that we may be always ready for changes. We must all die, no flight or hiding-place can save us, nor are there any weapons of effectual resistance. Ninety thousand die every day, upwards of sixty every minute, and one every moment. How solemn the thought! Oh that men were wise, that they understood these things, that they would consider their latter end! The believer alone is prepared to meet the solemn summons. Wickedness, by which men often escape human justice, cannot secure from death.

## Verses 9-13

Solomon observed, that many a time one man rules over another to his hurt, and that prosperity hardens them in their wickedness. Sinners herein deceive themselves. Vengeance comes slowly, but it comes surely. A good man's days have some substance; he lives to a good purpose: a wicked man's days are all as a shadow, empty and worthless. Let us pray that we may view eternal things as near, real, and all-important.

## Verses 14-17

Faith alone can establish the heart in this mixed scene, where the righteous often suffer, and the wicked prosper. Solomon commended joy, and holy security of mind, arising from confidence in God, because a man has no better thing under the sun, though a good man has much better things above the sun, than soberly and thankfully to use the things of this life according to his rank. He would not have us try to give a reason for what God does. But, leaving the Lord to clear up all difficulties in his own time, we may cheerfully enjoy the comforts, and bear up under the trials of life; while peace of conscience and joy in the Holy Ghost will abide in us through all outward changes, and when flesh and heart shall fail.


