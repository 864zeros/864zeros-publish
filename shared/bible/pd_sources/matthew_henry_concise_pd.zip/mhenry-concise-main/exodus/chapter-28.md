---
title: "Exodus 28 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "28"
description: "In this chapter: Aaron and his sons set apart for the priest's office, Their garments. (1–5). The ephod. (6–14). The breastplate, The Urim and Thummim. (15–30). The robe of the ephod, The plate of the mitre. (31–39). The garments for Aaron's sons. (40–43)."
weight: 28
---

# Exodus 28 

## Chapter Outline

- Aaron and his sons set apart for the priest's office, Their garments. (1–5)
- The ephod. (6–14)
- The breastplate, The Urim and Thummim. (15–30)
- The robe of the ephod, The plate of the mitre. (31–39)
- The garments for Aaron's sons. (40–43)

## Verses 1–5

Hitherto the heads of families were the priests, and offered sacrifices; but now this office was confined to the family of Aaron only; and so continued till the gospel dispensation. The holy garments not only distinguished the priests from the people, but were emblems of that holy conduct which should ever be the glory and beauty, the mark of the ministers of religion, without which their persons and ministrations will be had in contempt. They also typified the glory of the Divine majesty, and the beauty of complete holiness, which rendered Jesus Christ the great High Priest. But our adorning under the gospel, is not to be of gold and costly array, but the garments of salvation, the robe of righteousness.

## Verses 6–14

This richly-wrought ephod was the outmost garment of the high priest; plain linen ephods were worn by the inferior priests. It was a short coat without sleeves, fastened close to the body with a girdle. The shoulder-pieces were buttoned together with precious stones set in gold, one on each shoulder, on which were engraven the names of the children of Israel. Thus Christ, our High Priest, presents his people before the Lord for a memorial. As Christ's coat had no seam, but was woven from the top throughout, so it was with the ephod. The golden bells on this ephod, by their preciousness and pleasant sound, well represent the good profession that the saints make, and the pomegranates the fruit they bring forth.

## Verses 15–30

The chief ornament of the high priest, was the breastplate, a rich piece of cloth, curiously worked. The name of each tribe was graven in a precious stone, fixed in the breastplate, to signify how precious, in God's sight, believers are, and how honourable. How small and poor soever the tribe was, it was as a precious stone in the breastplate of the high priest; thus are all the saints dear to Christ, however men esteem them. The high priest had the names of the tribes, both on his shoulders and on his breast, which reminds us of the power and the love with which our Lord Jesus pleads for those that are his. He not only bears them up in his arms with almighty strength, but he carries them in his bosom with tender affection. What comfort is this to us in all our addresses to God! The Urim and Thummim, by which the will of God was made known in doubtful cases, were put in this breastplate. Urim and Thummim signify light and integrity. There are many conjectures what these were; the most probable opinion seems to be, that they were the twelve precious stones in the high priest's breastplate. Now, Christ is our Oracle. By him God, in these last days, makes known himself and his mind to us, Heb 1:1, 2; Joh 1:18. He is the true Light, the faithful Witness, the Truth itself, and from him we receive the Spirit of Truth, who leads into all truth.

## Verses 31–39

The robe of the ephod was under the ephod, and reached down to the knees, without sleeves. Aaron must minister in the garments appointed. We must serve the Lord with holy fear, as those who know they deserve to die. A golden plate was fixed on Aaron's forehead, engraven with “Holiness to the Lord.” Aaron was hereby reminded that God is holy, and that his priests must be holy, devoted to the Lord. This must appear in their forehead, in open profession of their relation to God. It must be engraven like the engravings of a signet; deep and durable; not painted so as to be washed off, but firm and lasting; such must our holiness to the Lord be. Christ is our High Priest; through him sins are forgiven to us, and not laid to our charge. Our persons, our doings, are pleasing to God upon the account of Christ, and not otherwise.

## Verses 40–43

The priest's garments typify the righteousness of Christ. If we appear not before God in that, we shall bear our iniquity, and die. Blessed is he, therefore, that watcheth, and keepeth his garments, Re 16:15. And blessed be God that we have a High Priest, appointed of God, and set apart for his work; furnished for his high office by the glory of his Divine majesty, and the beauty of perfect holiness. Happy are we, if by the law spiritually understood, we see that such a High Priest became us; that we cannot draw near to a holy God, or be accepted, but by him. There is no light, no wisdom, no perfection, but from him; no glory, no beauty, but in being like unto him. Let us take encouragement from the power, love, and compassion of our High Priest, to draw near with boldness to the throne of grace, that we may obtain mercy, and find grace to help in time of need.

