---
title: "Exodus 14 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "14"
description: "In this chapter: God directs the Israelites to Pihahiroth, Pharaoh pursues after them. (1–9). The Israelites murmur, Moses comforts them. (10–14). God instructs Moses, The cloud between the Israelites and the Egyptians. (15–20). The Israelites pass through the Red sea, which drowns the Egyptians. (21–31)."
weight: 14
---

# Exodus 14 

## Chapter Outline

- God directs the Israelites to Pihahiroth, Pharaoh pursues after them. (1–9)
- The Israelites murmur, Moses comforts them. (10–14)
- God instructs Moses, The cloud between the Israelites and the Egyptians. (15–20)
- The Israelites pass through the Red sea, which drowns the Egyptians. (21–31)

## Verses 1–9

Pharaoh would think that all Israel was entangled in the wilderness, and so would become an easy prey. But God says, I will be honoured upon Pharaoh. All men being made for the honour of their Maker, those whom he is not honoured by, he will be honoured upon. What seems to tend to the church's ruin, is often overruled to the ruin of the church's enemies. While Pharaoh gratified his malice and revenge, he furthered the bringing to pass God's counsels concerning him. Though with the greatest reason he had let Israel go, yet now he was angry with himself for it. God makes the envy and rage of men against his people, a torment to themselves. Those who set their faces heavenward, and will live godly in Christ Jesus, must expect to be set upon by Satan's temptations and terrors. He will not tamely part with any out of his service.

## Verses 10–14

There was no way open to Israel but upward, and thence their deliverance came. We may be in the way of duty, following God, and hastening toward heaven, yet may be troubled on every side. Some cried out unto the Lord; their fear led them to pray, and that was well. God brings us into straits, that he may bring us to our knees. Others cried out against Moses; fear set them murmuring as if God were not still able to work miracles. They quarrel with Moses for bringing them out of Egypt; and so were angry with God for the greatest kindness ever done them; thus gross are the absurdities of unbelief. Moses says, Fear ye not. It is always our duty and interest, when we cannot get out of troubles, yet to get above our fears; let them quicken our prayers and endeavours, but not silence our faith and hope. “Stand still,” think not to save yourselves either by fighting or flying; wait God's orders, and observe them. Compose yourselves, by confidence in God, into peaceful thoughts of the great salvation God is about to work for you. If God brings his people into straits, he will find a way to bring them out.

## Verses 15–20

Moses' silent prayers of faith prevailed more with God than Israel's loud outcries of fear. The pillar of cloud and fire came behind them, where they needed a guard, and it was a wall between them and their enemies. The word and providence of God have a black and dark side toward sin and sinners, but a bright and pleasant side toward the people of the Lord. He, who divided between light and darkness, Ge 1:4, allotted darkness to the Egyptians, and light to the Israelites. Such a difference there will be between the inheritance of the saints in light, and that utter darkness which will be the portion of hypocrites for ever.

## Verses 21–31

The dividing the Red sea was the terror of the Canaanites, Jos 2:9; the praise and triumph of the Israelites, Ps 114:3; 106:9; 136:13. It was a type of baptism, 1Co 10:1, 2. Israel's passage through it was typical of the conversion of souls, Isa 11:15; and the Egyptians being drowned in it was typical of the final ruin of all unrepenting sinners. God showed his almighty power, by opening a passage through the waters, some miles over. God can bring his people through the greatest difficulties, and force a way where he does not find it. It was an instance of his wonderful favour to his Israel. They went through the sea, they walked upon dry land in the midst of the sea. This was done, in order to encourage God's people in all ages to trust him in the greatest straits. What cannot he do who did this? What will not he do for those that fear and love him, who did this for these murmuring, unbelieving Israelites? Then followed the just and righteous wrath of God upon his and his people's enemies. The ruin of sinners is brought on by their own rage and presumption. They might have let Israel alone, and would not; now they would flee from the face of Israel, and cannot. Men will not be convinced, till it is too late, that those who meddle with God's people, meddle to their own hurt. Moses was ordered to stretch out his hand over the sea; the waters returned, and overwhelmed all the host of the Egyptians. Pharaoh and his servants, who had hardened one another in sin, now fell together, not one escaped. The Israelites saw the Egyptians dead upon the sands. The sight very much affected them. While men see God's works, and feel the benefit, they fear him and trust in him. How well were it for us, if we were always in as good a frame as sometimes! Behold the end to which a Christian may look forward. His enemies rage, and are mighty; but while he holds fast by God, he shall pass the waves in safety guarded by that very power of his Saviour, which shall come down on every spiritual foe. The enemies of his soul whom he hath seen to-day, he shall see no more for ever.

