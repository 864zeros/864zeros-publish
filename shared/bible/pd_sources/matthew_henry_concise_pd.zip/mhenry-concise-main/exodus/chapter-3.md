---
title: "Exodus 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: God appears to Moses in a burning bush. (1–6). God sends Moses to deliver Israel. (7–10). The name Jehovah. (11–15). The deliverance of the Israelites promised. (16–22)."
weight: 3
---

# Exodus 3 

## Chapter Outline

- God appears to Moses in a burning bush. (1–6)
- God sends Moses to deliver Israel. (7–10)
- The name Jehovah. (11–15)
- The deliverance of the Israelites promised. (16–22)

## Verses 1–6

The years of the life of Moses are divided into three forties; the first forty he spent as a prince in Pharaoh's court, the second as a shepherd in Midian, the third as a king in Jeshurun. How changeable is the life of man! The first appearance of God to Moses, found him tending sheep. This seems a poor employment for a man of his parts and education, yet he rests satisfied with it; and thus learns meekness and contentment, for which he is more noted in sacred writ, than for all his learning. Satan loves to find us idle; God is pleased when he finds us employed. Being alone, is a good friend to our communion with God. To his great surprise, Moses saw a bush burning without fire to kindle it. The bush burned, and yet did not burn away; an emblem of the church in bondage in Egypt. And it fitly reminds us of the church in every age, under its severest persecutions kept by the presence of God from being destroyed. Fire is an emblem, in Scripture, of the Divine holiness and justice, also of the afflictions and trials with which God proves and purifies his people, and even of that baptism of the Holy Ghost, by which sinful affections are consumed, and the soul changed into the Divine nature and image. God gave Moses a gracious call, to which he returned a ready answer. Those that would have communion with God, must attend upon him in the ordinances wherein he is pleased to manifest himself and his glory, though it be in a bush. Putting off the shoe was a token of respect and submission. We ought to draw nigh to God with a solemn pause and preparation, carefully avoiding every thing that looks light and rude, and unbecoming his service. God does not say, I was the God of Abraham, Isaac, and Jacob, but I am. The patriarchs still live, so many years after their bodies have been in the grave. No length of time can separate the souls of the just from their Maker. By this, God instructed Moses as to another world, and strengthened his belief of a future state. Thus it is interpreted by our Lord Jesus, who, from hence, proves that the dead are raised, Lu 20:37. Moses hid his face, as if both ashamed and afraid to look upon God. The more we see of God, and his grace, and covenant love, the more cause we shall see to worship him with reverence and godly fear.

## Verses 7–10

God notices the afflictions of Israel. Their sorrows; even the secret sorrows of God's people are known to him. Their cry; God hears the cries of his afflicted people. The oppression they endured; the highest and greatest of their oppressors are not above him. God promises speedy deliverance by methods out of the common ways of providence. Those whom God, by his grace, delivers out of a spiritual Egypt, he will bring to a heavenly Canaan. (Ex 3:11-15)

## Verses 11–15

Formerly Moses thought himself able to deliver Israel, and set himself to the work too hastily. Now, when the fittest person on earth for it, he knows his own weakness. This was the effect of more knowledge of God and of himself. Formerly, self-confidence mingled with strong faith and great zeal, now sinful distrust of God crept in under the garb of humility; so defective are the strongest graces and the best duties of the most eminent saints. But all objections are answered in, Certainly I will be with thee. That is enough. Two names God would now be known by. A name that denotes what he is in himself, I AM THAT I AM. This explains his name Jehovah, and signifies, 1. That he is self-existent: he has his being of himself. 2. That he is eternal and unchangeable, and always the same, yesterday, to-day, and for ever. 3. That he is incomprehensible; we cannot by searching find him out: this name checks all bold and curious inquiries concerning God. 4. That he is faithful and true to all his promises, unchangeable in his word as well as in his nature; let Israel know this, I AM hath sent me unto you. I am, and there is none else besides me. All else have their being from God, and are wholly dependent upon him. Also, here is a name that denotes what God is to his people. The Lord God of your fathers sent me unto you. Moses must revive among them the religion of their fathers, which was almost lost; and then they might expect the speedy performance of the promises made unto their fathers.

## Verses 16–22

Moses' success with the elders of Israel would be good. God, who, by his grace, inclines the heart, and opens the ear, could say beforehand, They shall hearken to thy voice; for he would make them willing in this day of power. As to Pharaoh, Moses is here told that petitions and persuasions, and humble complaints, would not prevail with him; nor a mighty hand stretched out in signs and wonders. But those will certainly be broken by the power of God's hand, who will not bow to the power of his word. Pharaoh's people should furnish Israel with riches at their departure. In Pharaoh's tyranny and Israel's oppression, we see the miserable, abject state of sinners. However galling the yoke, they drudge on till the Lord sends redemption. With the invitations of the gospel, God sends the teaching of his Spirit. Thus are men made willing to seek and to strive for deliverance. Satan loses his power to hold them, they come forth with all they have and are, and apply all to the glory of God and the service of his church.

