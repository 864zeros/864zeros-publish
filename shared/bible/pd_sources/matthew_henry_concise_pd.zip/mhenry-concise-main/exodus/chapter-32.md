---
title: "Exodus 32 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "32"
description: "In this chapter: The people cause Aaron to make a golden calf. (1–6). God's displeasure, The intercession of Moses. (7–14). Moses breaks the tables of the law, He destroys the golden calf. (15–20). Aaron's excuse, The idolaters slain. (21–29). Moses prays for the people. (30–35)."
weight: 32
---

# Exodus 32 

## Chapter Outline

- The people cause Aaron to make a golden calf. (1–6)
- God's displeasure, The intercession of Moses. (7–14)
- Moses breaks the tables of the law, He destroys the golden calf. (15–20)
- Aaron's excuse, The idolaters slain. (21–29)
- Moses prays for the people. (30–35)

## Verses 1–6

While Moses was in the mount, receiving the law from God, the people made a tumultuous address to Aaron. This giddy multitude were weary of waiting for the return of Moses. Weariness in waiting betrays to many temptations. The Lord must be waited for till he comes, and waited for though he tarry. Let their readiness to part with their ear-rings to make an idol, shame our niggardliness in the service of the true God. They did not draw back on account of the cost of their idolatry; and shall we grudge the expenses of religion? Aaron produced the shape of an ox or calf, giving it some finish with a graving tool. They offered sacrifice to this idol. Having set up an image before them, and so changed the truth of God into a lie, their sacrifices were abomination. Had they not, only a few days before, in this very place, heard the voice of the Lord God speaking to them out of the midst of the fire, Thou shalt not make to thyself any graven image? Had they not themselves solemnly entered into covenant with God, that they would do all he had said to them, and would be obedient? ch. 24:7. Yet before they stirred from the place where this covenant had been solemnly made, they brake an express command, in defiance of an express threatening. It plainly shows, that the law was no more able to make holy, than it was to justify; by it is the knowledge of sin, but not the cure of sin. Aaron was set apart by the Divine appointment to the office of the priesthood; but he, who had once shamed himself so far as to build an altar to a golden calf, must own himself unworthy of the honour of attending at the altar of God, and indebted to free grace alone for it. Thus pride and boasting were silenced.

## Verses 7–14

God says to Moses, that the Israelites had corrupted themselves. Sin is the corruption of the sinner, and it is a self-corruption; every man is tempted when he is drawn aside of his own lust. They had turned aside out of the way. Sin is a departing from the way of duty into a by-path. They soon forgot God's works. He sees what they cannot discover, nor is any wickedness of the world hid from him. We could not bear to see the thousandth part of that evil which God sees every day. God expresses the greatness of his just displeasure, after the manner of men who would have prayer of Moses could save them from ruin; thus he was a type of Christ, by whose mediation alone, God would reconcile the world to himself. Moses pleads God's glory. The glorifying God's name, as it ought to be our first petition, and it is so in the Lord's prayer, so it ought to be our great plea. And God's promises are to be our pleas in prayer; for what he has promised he is able to perform. See the power of prayer. In answer to the prayers of Moses, God showed his purpose of sparing the people, as he had before seemed determined on their destruction; which change of the outward discovery of his purpose, is called repenting of the evil.

## Verses 15–20

What a change it is, to come down from the mount of communion with God, to converse with a wicked world. In God we see nothing but what is pure and pleasing; in the world nothing but what is sinful and provoking. That it might appear an idol is nothing in the world, Moses ground the calf to dust. Mixing this powder with their drink, signified that the backslider in heart should be filled with his own ways.

## Verses 21–29

Never did any wise man make a more frivolous and foolish excuse than that of Aaron. We must never be drawn into sin by any thing man can say or do to us; for men can but tempt us to sin, they cannot force us. The approach of Moses turned the dancing into trembling. They were exposed to shame by their sin. The course Moses took to roll away this reproach, was, not by concealing the sin, or putting any false colour upon it, but by punishing it. The Levites were to slay the ringleaders in this wickedness; yet none were executed but those who openly stood forth. Those are marked for ruin who persist in sin: those who in the morning were shouting and dancing, before night were dying. Such sudden changes do the judgments of the Lord sometimes make with sinners that are secure and jovial in their sin.

## Verses 30–35

Moses calls it a great sin. The work of ministers is to show people the greatness of their sins. The great evil of sin appears in the price of pardon. Moses pleads with God for mercy; he came not to make excuses, but to make atonement. We are not to suppose that Moses means that he would be willing to perish for ever, for the people's sake. We are to love our neighbour as ourselves, and not more than ourselves. But having that mind which was in Christ, he was willing to lay down his life in the most painful manner, if he might thereby preserve the people. Moses could not wholly turn away the wrath of God; which shows that the law of Moses was not able to reconcile men to God, and to perfect our peace with him. In Christ alone, God so pardons sin as to remember it no more. From this history we see, that no unhumbled, carnal heart, can long endure the holy precepts, the humbling truths, and the spiritual worship of God. But a god, a priest, a worship, a doctrine, and a sacrifice, suited to the carnal mind, will ever meet with abundance of worshippers. The very gospel itself may be so perverted as to suit a worldly taste. Well is it for us, that the Prophet like unto Moses, but who is beyond compare more powerful and merciful, has made atonement for our souls, and now intercedes in our behalf. Let us rejoice in his grace.

