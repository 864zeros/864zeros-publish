---
title: "Exodus 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: God's last instructions to Moses respecting Pharaoh and the Egyptians. (1–3). The death of the first-born threatened. (4–10)."
weight: 11
---

# Exodus 11 

## Chapter Outline

- God's last instructions to Moses respecting Pharaoh and the Egyptians. (1–3)
- The death of the first-born threatened. (4–10)

## Verses 1–3

A secret revelation was made to Moses while in the presence of Pharaoh, that he might give warning of the last dreadful judgment, before he went out. This was the last day of the servitude of Israel; they were about to go away. Their masters, who had abused them in their work, would have sent them away empty; but God provided that the labourers should not lose their hire, and ordered them to demand it now, at their departure, and it was given to them. God will right the injured, who in humble silence commit their cause to him; and none are losers at last by patient suffering. The Lord gave them favour in the sight of the Egyptians, by making it appear how much he favoured them. He also changed the spirit of the Egyptians toward them, and made them to be pitied of their oppressors. Those that honour God, he will honour.

## Verses 4–10

The death of all the first-born in Egypt at once: this plague had been the first threatened, but is last executed. See how slow God is to wrath. The plague is foretold, the time is fixed; all their first-born should sleep the sleep of death, not silently, but so as to rouse the families at midnight. The prince was not too high to be reached by it, nor the slaves at the mill too low to be noticed. While angels slew the Egyptians, not so much as a dog should bark at any of the children of Israel. It is an earnest of the difference there shall be in the great day, between God's people and his enemies. Did men know what a difference God puts, and will put to eternity, between those that serve him and those that serve him not, religion would not seem to them an indifferent thing; nor would they act in it with so much carelessness as they do. When Moses had thus delivered his message, he went out from Pharaoh in great anger at his obstinacy; though he was the meekest of the men of the earth. The Scripture has foretold the unbelief of many who hear the gospel, that it might not be a surprise or stumbling-block to us, Ro 10:16. Let us never think the worse of the gospel of Christ for the slights men put upon it. Pharaoh was hardened, yet he was compelled to abate his stern and haughty demands, till the Israelites got full freedom. In like manner the people of God will find that every struggle against their spiritual adversary, made in the might of Jesus Christ, every attempt to overcome him by the blood of the Lamb, and every desire to attain increasing likeness and love to that Lamb, will be rewarded by increasing freedom from the enemy of souls.

