---
title: "Exodus 34 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "34"
description: "In this chapter: The tables of the law renewed. (1–4). The name of the Lord proclaimed, The entreaty of Moses. (5–9). God's covenant. (10–17). The festivals. (18–27). The vail of Moses. (28–35)."
weight: 34
---

# Exodus 34 

## Chapter Outline

- The tables of the law renewed. (1–4)
- The name of the Lord proclaimed, The entreaty of Moses. (5–9)
- God's covenant. (10–17)
- The festivals. (18–27)
- The vail of Moses. (28–35)

## Verses 1–4

When God made man in his own image, the moral law was written in his heart, by the finger of God, without outward means. But since the covenant then made with man was broken, the Lord has used the ministry of men, both in writing the law in the Scriptures, and in writing it in the heart. When God was reconciled to the Israelites, he ordered the tables to be renewed, and wrote his law in them. Even under the gospel of peace by Christ, the moral law continues to bind believers. Though Christ has redeemed us from the curse of the law, yet not from the commands of it. The first and the best evidence of the pardon of sin, and peace with God, is the writing the law in the heart.

## Verses 5–9

The Lord descended by some open token of his presence and manifestation of his glory in a cloud, and thence proclaimed his NAME; that is, the perfections and character which are denoted by the name JEHOVAH. The Lord God is merciful; ready to forgive the sinner, and to relieve the needy. Gracious; kind, and ready to bestow undeserved benefits. Long-suffering; slow to anger, giving time for repentance, only punishing when it is needful. He is abundant in goodness and truth; even sinners receive the riches of his bounty abundantly, though they abuse them. All he reveals is infallible truth, all he promises is in faithfulness. Keeping mercy for thousands; he continually shows mercy to sinners, and has treasures, which cannot be exhausted, to the end of time. Forgiving iniquity, and transgression, and sin; his mercy and goodness reach to the full and free forgiveness of sin. And will by no means clear the guilty; the holiness and justice of God are part of his goodness and love towards all his creatures. In Christ's sufferings, the Divine holiness and justice are fully shown, and the evil of sin is made known. God's forgiving mercy is always attended by his converting, sanctifying grace. None are pardoned but those who repent and forsake the allowed practice of every sin; nor shall any escape, who abuse, neglect, or despise this great salvation. Moses bowed down, and worshipped reverently. Every perfection in the name of God, the believer may plead with Him for the forgiveness of his sins, the making holy of his heart, and the enlargement of the Redeemer's kingdom.

## Verses 10–17

The Israelites are commanded to destroy every monument of idolatry, however curious or costly; to refuse all alliance, friendship, or marriage with idolaters, and all idolatrous feasts; and they were reminded not with idolaters, and all idolatrous feats; and they were reminded not to repeat the crime of making molten images. Jealously is called the rage of a man, Pr 6:34; but in God it is holy and just displeasure. Those cannot worship God aright, who do not worship him only.

## Verses 18–27

Once a week they must rest, even in ploughing time, and in harvest. All worldly business must give way to that holy rest; even harvest work will prosper the better, for the religious observance of the sabbath day in harvest time. We must show that we prefer our communion with God, and our duty to him, before the business or the joy of harvest. Thrice a year they must appear before the Lord God, the God of Israel. Canaan was a desirable land, and the neighbouring nations were greedy; yet God says, They shall not desire it. Let us check all sinful desires against God and his glory, in our hearts, and then trust him to check all sinful desires in the hearts of others against us. The way of duty is the way of safety. Those who venture for him never lose by him. Three feasts are here mentioned: 1. The Passover, in remembrance of the deliverance out of Egypt. 2. The feast of weeks, or the feast of Pentecost; added to it is the law of the first-fruits. 3. The feast of in-gathering, or the feast of Tabernacles. Moses is to write these words, that the people might know them better. We can never be enough thankful to God for the written word. God would make a covenant with Israel, in Moses as a mediator. Thus the covenant of grace is made with believers through Christ.

## Verses 28–35

Near and spiritual communion with God improves the graces of a renewed and holy character. Serious godliness puts a lustre upon a man's countenance, such as commands esteem and affection. The vail which Moses put on, marked the obscurity of that dispensation, compared with the gospel dispensation of the New Testament. It was also an emblem of the natural vail on the hearts of men respecting spiritual things. Also the vail that was and is upon the nation of Israel, which can only be taken away by the Spirit of the Lord showing to them Christ, as the end of the law for righteousness to every one that believeth. Fear and unbelief would put the vail before us, they would hinder our free approach to the mercy-seat above. We should spread our wants, temporal and spiritual, fully before our heavenly Father; we should tell him our hinderances, struggles, trails, and temptations; we should acknowledge our offences.

