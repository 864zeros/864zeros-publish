---
title: "Exodus 15 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "15"
description: "In this chapter: The song of Moses for the deliverance of Israel. (1–21). The bitter waters at Marah, The Israelites come to Elim. (22–27)."
weight: 15
---

# Exodus 15 

## Chapter Outline

- The song of Moses for the deliverance of Israel. (1–21)
- The bitter waters at Marah, The Israelites come to Elim. (22–27)

## Verses 1–21

This song is the most ancient we know of. It is a holy song, to the honour of God, to exalt his name, and celebrate his praise, and his only, not in the least to magnify any man. Holiness to the Lord is in every part of it. It may be considered as typical, and prophetical of the final destruction of the enemies of the church. Happy the people whose God is the Lord. They have work to do, temptations to grapple with, and afflictions to bear, and are weak in themselves; but his grace is their strength. They are often in sorrow, but in him they have comfort; he is their song. Sin, and death, and hell threaten them, but he is, and will be their salvation. The Lord is a God of almighty power, and woe to those that strive with their Maker! He is a God of matchless perfection; he is glorious in holiness; his holiness is his glory. His holiness appears in the hatred of sin, and his wrath against obstinate sinners. It appears in the deliverance of Israel, and his faithfulness to his own promise. He is fearful in praises; that which is matter of praise to the servants of God, is very dreadful to his enemies. He is doing wonders, things out of the common course of nature; wondrous to those in whose favour they are wrought, who are so unworthy, that they had no reason to expect them. There were wonders of power and wonders of grace; in both, God was to be humbly adored.

## Verses 22–27

In the wilderness of Shur the Israelites had no water. At Marah they had water, but it was bitter; so that they could not drink it. God can make bitter to us that from which we promise ourselves most, and often does so in the wilderness of this world, that our wants, and disappointments in the creature, may drive us to the Creator, in whose favour alone true comfort is to be had. In this distress the people fretted, and quarrelled with Moses. Hypocrites may show high affections, and appear earnest in religious exercises, but in the time of temptation they fall away. Even true believers, in seasons of sharp trial, will be tempted to fret, distrust, and murmur. But in every trial we should cast our care upon the Lord, and pour out our hearts before him. We shall then find that a submissive will, a peaceful conscience, and the comforts of the Holy Ghost, will render the bitterest trial tolerable, yea, pleasant. Moses did what the people had neglected to do; he cried unto the Lord. And God provided graciously for them. He directed Moses to a tree which he cast into the waters, when, at once, they were made sweet. Some make this tree typical of the cross of Christ, which sweetens the bitter waters of affliction to all the faithful, and enables them to rejoice in tribulation. But a rebellious Israelite shall fare no better than a rebellious Egyptian. The threatening is implied only, the promise is expressed. God is the great Physician. If we are kept well, it is he that keeps us; if we are made well, it is he that recovers us. He is our life and the length of our days. Let us not forget that we are kept from destruction, and delivered from our enemies, to be the Lord's servants. At Elim they had good water, and enough of it. Though God may, for a time, order his people to encamp by the bitter waters of Marah, that shall not always be their lot. Let us not faint at tribulations.

