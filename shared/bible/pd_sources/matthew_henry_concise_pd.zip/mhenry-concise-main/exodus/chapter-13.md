---
title: "Exodus 13 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "13"
description: "In this chapter: The first-born sanctified to God, The remembrance of the passover commanded. (1–10). The firstlings of beasts set apart. (11–16). Joseph's bones carried with the Israelites, They come to Etham. (17–20). God guideth the Israelites by a pillar of cloud fire. (21, 22)."
weight: 13
---

# Exodus 13 

## Chapter Outline

- The first-born sanctified to God, The remembrance of the passover commanded. (1–10)
- The firstlings of beasts set apart. (11–16)
- Joseph's bones carried with the Israelites, They come to Etham. (17–20)
- God guideth the Israelites by a pillar of cloud fire. (21, 22)

## Verses 1–10

In remembrance of the destruction of the first-born of Egypt, both of man and of beast, and the deliverance of the Israelites out of bondage, the first-born males of the Israelites were set apart to the Lord. By this was set before them, that their lives were preserved through the ransom of the atonement, which in due time was to be made for sin. They were also to consider their lives, thus ransomed from death, as now to be consecrated to the service of God. The parents were not to look upon themselves as having any right in their first-born, till they solemnly presented them to God, and allowed his title to them. That which is, by special mercy, spared to us, should be applied to God's honour; at least, some grateful acknowledgment, in works of piety and charity, should be made. The remembrance of their coming out of Egypt must be kept up every year. The day of Christ's resurrection is to be remembered, for in it we were raised up with Christ out of death's house of bondage. The Scripture tells us not expressly what day of the year Christ rose, but it states particularly what day of the week it was; as the more valuable deliverance, it should be remembered weekly. The Israelites must keep the feast of unleavened bread. Under the gospel, we must not only remember Christ, but observe his holy supper. Do this in remembrance of him. Also care must be taken to teach children the knowledge of God. Here is an old law for catechising. It is of great use to acquaint children betimes with the histories of the Bible. And those who have God's law in their heart should have it in their mouth, and often speak of it, to affect themselves, and to teach others.

## Verses 11–16

The firstlings of beast not used in sacrifice, were to be changed for others so used, or they were to be destroyed. Our souls are forfeited to God's justice, and unless ransomed by the sacrifice of Christ, will certainly perish. These institutions would continually remind them of their duty, to love and serve the Lord. In like manner, baptism and the Lord's supper, if explained and attended to, would remind us, and give us occasion to remind one another of our profession and duty.

## Verses 17–20

There were two ways from Egypt to Canaan. One was only a few days' journey; the other was much further about, through the wilderness, and that was the way in which God chose to lead his people Israel. The Egyptians were to be drowned in the Red sea; the Israelites were to be humbled and proved in the wilderness. God's way is the right way, though it seems about. If we think he leads not his people the nearest way, yet we may be sure he leads them the best way, and so it will appear when we come to our journey's end. The Philistines were powerful enemies; it was needful that the Israelites should be prepared for the wars of Canaan, by passing through the difficulties of the wilderness. Thus God proportions his people's trials to their strength, 1Co 10:13. They went up in good order. They went up in five in a rank, some; in five bands, so others, which it seems rather to their faith and hope, that God would bring them to Canaan, in expectation of which they carried these bones with them while in the desert.

## Verses 21, 22

The Lord went before them in a pillar, or appearance of the Divine Majesty. Christ was with the church in the wilderness, 1Co 10:9. Those whom God brings into a wilderness, he will not leave nor lose there, but will take care to lead them through it. It was great satisfaction to Moses and the pious Israelites, to be sure that they were under Divine guidance. Those who make the glory of God their end, and the word of God their rule, the Spirit of God the guide of their affections, and the providence of God the guide of their affairs, may be sure that the Lord goes before them, though they cannot see it with their eyes: we must now live by faith. When Israel marched, this pillar went before, and pointed out the place of encampment, as Divine Wisdom saw fit. It sheltered by day from the heat, and gave light by night. The Bible is a light to our feet, a lantern to our paths, with which the Saviour's love has provided us. It testifies of Christ. It is to us like the pillar to the Israelites. Listen to that voice which cries, I am the Light of the world; he that followeth me shall not walk in darkness, but shall have the Light of life, Joh 8:12. Jesus Christ alone, as shown in the Bible, and as the Holy Spirit, in answer to prayer, recommends him to the soul, is the Way, the Truth, and the Life, Joh 14:6.

