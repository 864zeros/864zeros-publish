---
title: "Exodus 19 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "19"
description: "In this chapter: The people come to Sinai, God's message to them, and their answer. (1–8). The people directed to prepare to hear the law. (9–15). The presence of God on Sinai. (16–25)."
weight: 19
---

# Exodus 19 

## Chapter Outline

- The people come to Sinai, God's message to them, and their answer. (1–8)
- The people directed to prepare to hear the law. (9–15)
- The presence of God on Sinai. (16–25)

## Verses 1–8

Moses was called up the mountain, and was employed as the messenger of this covenant. The Maker and first Mover of the covenant, is God himself. This blessed charter was granted out of God's own free grace. The covenant here mentioned was the national covenant, by which the Israelites were a people under the government of Jehovah. It was a type of the new covenant made with true believers in Christ Jesus; but, like other types, it was only a shadow of good things to come. As a nation they broke this covenant; therefore the Lord declared that he would make a new covenant with Israel, writing his law, not upon tables of stone, but in their hearts, Jer 31:33; Heb 8:7–10. The covenant spoken of in these places as ready to vanish away, is the national covenant with Israel, which they forfeited by their sins. Unless we carefully attend to this, we shall fall into mistakes while reading the Old Testament. We must not suppose that the nation of the Jews were under the covenant of works, which knows nothing of repentance, faith in a Mediator, forgiveness of sins, or grace; nor yet that the whole nation of Israel bore the character, and possessed the privileges of true believers, as being actually sharers in the covenant of grace. They were all under a dispensation of mercy; they had outward privileges and advantages for salvation; but, like professing Christians, most rested therein, and went no further. Israel consented to the conditions. They answered as one man, All that the Lord hath spoken we will do. Oh that there had been such a heart in them! Moses, as a mediator, returned the words of the people to God. Thus Christ, the Mediator, as a Prophet, reveals God's will to us, his precepts and promises; and then, as a Priest, offers up to God our spiritual sacrifices, not only of prayer and praise, but of devout affections, and pious resolutions, the work of his own Spirit in us.

## Verses 9–15

The solemn manner in which the law was delivered, was to impress the people with a right sense of the Divine majesty. Also to convince them of their own guilt, and to show that they could not stand in judgment before God by their own obedience. In the law, the sinner discovers what he ought to be, what he is, and what he wants. There he learns the nature, necessity, and glory of redemption, and of being made holy. Having been taught to flee to Christ, and to love him, the law is the rule of his obedience and faith.

## Verses 16–25

Never was there such a sermon preached, before or since, as this which was preached to the church in the wilderness. It might be supposed that the terrors would have checked presumption and curiosity in the people; but the hard heart of an unawakened sinner can trifle with the most terrible threatenings and judgments. In drawing near to God, we must never forget his holiness and greatness, nor our own meanness and pollution. We cannot stand in judgment before him according to his righteous law. The convinced transgressor asks, What must I do to be saved? and he hears the voice, Believe in the Lord Jesus Christ, and thou shalt be saved. The Holy Ghost, who made the law to convince of sin, now takes of the things of Christ, and shows them to us. In the gospel we read, Christ hath redeemed us from the curse of the law, being made a curse for us. We have redemption through his blood, even the forgiveness of sins. Through him we are justified from all things, from which we could not be justified by the law of Moses. But the Divine law is binding as a rule of life. The Son of God came down from heaven, and suffered poverty, shame, agony, and death, not only to redeem us from its curse, but to bind us more closely to keep its commands.

