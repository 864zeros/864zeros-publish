---
title: "2 Corinthians 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: The apostle states his authority with meekness and humility. (1–6). Reasons with the Corinthians. (7–11). Seeks the glory of God, and to be approved of him. (12–18)."
weight: 10
---

# 2 Corinthians 10 

## Chapter Outline

- The apostle states his authority with meekness and humility. (1–6)
- Reasons with the Corinthians. (7–11)
- Seeks the glory of God, and to be approved of him. (12–18)

## Verses 1–6

While others thought meanly, and spake scornfully of the apostle, he had low thoughts, and spake humbly of himself. We should be aware of our own infirmities, and think humbly of ourselves, even when men reproach us. The work of the ministry is a spiritual warfare with spiritual enemies, and for spiritual purposes. Outward force is not the method of the gospel, but strong persuasions, by the power of truth and the meekness of wisdom. Conscience is accountable to God only; and people must be persuaded to God and their duty, not driven by force. Thus the weapons of our warfare are very powerful; the evidence of truth is convincing. What opposition is made against the gospel, by the powers of sin and Satan in the hearts of men! But observe the conquest the word of God gains. The appointed means, however feeble they appear to some, will be mighty through God. And the preaching of the cross, by men of faith and prayer, has always been fatal to idolatry, impiety, and wickedness.

## Verses 7–11

In outward appearance, Paul was mean and despised in the eyes of some, but this was a false rule to judge by. We must not think that none outward appearance, as if the want of such things proved a man not to be a real Christian, or an able, faithful minister of the lowly Saviour.

## Verses 12–18

If we would compare ourselves with others who excel us, this would be a good method to keep us humble. The apostle fixes a good rule for his conduct; namely, not to boast of things without his measure, which was the measure God had distributed to him. There is not a more fruitful source of error, than to judge of persons and opinions by our own prejudices. How common is it for persons to judge of their own religious character, by the opinions and maxims of the world around them! But how different is the rule of God's word! And of all flattery, self-flattery is the worst. Therefore, instead of praising ourselves, we should strive to approve ourselves to God. In a word, let us glory in the Lord our salvation, and in all other things only as evidences of his love, or means of promoting his glory. Instead of praising ourselves, or seeking the praise of men, let us desire that honour which cometh from God only.

