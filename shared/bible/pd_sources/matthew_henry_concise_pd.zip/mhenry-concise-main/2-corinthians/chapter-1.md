---
title: "2 Corinthians 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The apostle blesses God for comfort in, and deliverance out of troubles. (1–11). He professes his own and his fellow-labourers' integrity. (12–14). Gives reasons for his not coming to them. (15–24)."
weight: 1
---

# 2 Corinthians 1 

## Chapter Outline

- The apostle blesses God for comfort in, and deliverance out of troubles. (1–11)
- He professes his own and his fellow-labourers' integrity. (12–14)
- Gives reasons for his not coming to them. (15–24)

## Verses 1–11

We are encouraged to come boldly to the throne of grace, that we may obtain mercy, and find grace to help in time of need. The Lord is able to give peace to the troubled conscience, and to calm the raging passions of the soul. These blessings are given by him, as the Father of his redeemed family. It is our Saviour who says, Let not your heart be troubled. All comforts come from God, and our sweetest comforts are in him. He speaks peace to souls by granting the free remission of sins; and he comforts them by the enlivening influences of the Holy Spirit, and by the rich mercies of his grace. He is able to bind up the broken-hearted, to heal the most painful wounds, and also to give hope and joy under the heaviest sorrows. The favours God bestows on us, are not only to make us cheerful, but also that we may be useful to others. He sends comforts enough to support such as simply trust in and serve him. If we should be brought so low as to despair even of life, yet we may then trust God, who can bring back even from death. Their hope and trust were not in vain; nor shall any be ashamed who trust in the Lord. Past experiences encourage faith and hope, and lay us under obligation to trust in God for time to come. And it is our duty, not only to help one another with prayer, but in praise and thanksgiving, and thereby to make suitable returns for benefits received. Thus both trials and mercies will end in good to ourselves and others.

## Verses 12–14

Though, as a sinner, the apostle could only rejoice and glory in Christ Jesus, yet, as a believer, he might rejoice and glory in being really what he professed. Conscience witnesses concerning the steady course and tenor of the life. Thereby we may judge ourselves, and not by this or by that single act. Our conversation will be well ordered, when we live and act under such a gracious principle in the heart. Having this, we may leave our characters in the Lord's hands, but using proper means to clear them, when the credit of the gospel, or our usefulness, calls for it.

## Verses 15–24

The apostle clears himself from the charge of levity and inconstancy, in not coming to Corinth. Good men should be careful to keep the reputation of sincerity and constancy; they should not resolve, but on careful thought; and they will not change unless for weighty reasons. Nothing can render God's promises more certain: his giving them through Christ, assures us they are his promises; as the wonders God wrought in the life, resurrection, and ascension of his Son, confirm faith. The Holy Spirit makes Christians firm in the faith of the gospel: the quickening of the Spirit is an earnest of everlasting life; and the comforts of the Spirit are an earnest of everlasting joy. The apostle desired to spare the blame he feared would be unavoidable, if he had gone to Corinth before he learned what effect his former letter produced. Our strength and ability are owing to faith; and our comfort and joy must flow from faith. The holy tempers and gracious fruits which attend faith, secure from delusion in so important a matter.

