---
title: "2 Corinthians 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: Reasons for the apostle not coming to Corinth. (1–4). Directions about restoring the repentant offender. (5–11). An account of his labours and success in spreading the gospel of Christ. (12–17)."
weight: 2
---

# 2 Corinthians 2 

## Chapter Outline

- Reasons for the apostle not coming to Corinth. (1–4)
- Directions about restoring the repentant offender. (5–11)
- An account of his labours and success in spreading the gospel of Christ. (12–17)

## Verses 1–4

The apostle desired to have a cheerful meeting with them; and he had written in confidence of their doing what was to their benefit and his comfort; and that therefore they would be glad to remove every cause of disquiet from him. We should always give pain unwillingly, even when duty requires that it must be given.

## Verses 5–11

The apostle desires them to receive the person who had done wrong, again into their communion; for he was aware of his fault, and much afflicted under his punishment. Even sorrow for sin should not unfit for other duties, and drive to despair. Not only was there danger last Satan should get advantage, by tempting the penitent to hard thoughts of God and religion, and so drive him to despair; but against the churches and the ministers of Christ, by bringing an evil report upon Christians as unforgiving; thus making divisions, and hindering the success of the ministry. In this, as in other things, wisdom is to be used, that the ministry may not be blamed for indulging sin on the one hand, or for too great severity towards sinners on the other hand. Satan has many plans to deceive, and knows how to make a bad use of our mistakes.

## Verses 12–17

A believer's triumphs are all in Christ. To him be the praise and glory of all, while the success of the gospel is a good reason for a Christian's joy and rejoicing. In ancient triumphs, abundance of perfumes and sweet odours were used; so the name and salvation of Jesus, as ointment poured out, was a sweet savour diffused in every place. Unto some, the gospel is a savour of death unto death. They reject it to their ruin. Unto others, the gospel is a savour of life unto life: as it quickened them at first when they were dead in trespasses and sins, so it makes them more lively, and will end in eternal life. Observe the awful impressions this matter made upon the apostle, and should also make upon us. The work is great, and of ourselves we have no strength at all; all our sufficiency is of God. But what we do in religion, unless it is done in sincerity, as in the sight of God, is not of God, does not come from him, and will not reach to him. May we carefully watch ourselves in this matter; and seek the testimony of our consciences, under the teaching of the Holy Spirit, that as of sincerity, so speak we in Christ and of Christ.

