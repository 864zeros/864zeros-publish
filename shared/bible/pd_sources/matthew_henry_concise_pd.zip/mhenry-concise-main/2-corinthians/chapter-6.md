---
title: "2 Corinthians 6 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "6"
description: "In this chapter: The apostle, with others, proved themselves faithful ministers of Christ, by their unblamable life and behaviour. (1–10). By affection for them, And by earnest concern, that they might have no fellowship with unbelievers and idolaters. (11–18)."
weight: 6
---

# 2 Corinthians 6 

## Chapter Outline

- The apostle, with others, proved themselves faithful ministers of Christ, by their unblamable life and behaviour. (1–10)
- By affection for them, And by earnest concern, that they might have no fellowship with unbelievers and idolaters. (11–18)

## Verses 1–10

The gospel is a word of grace sounding in our ears. The gospel day is a day of salvation, the means of grace the means of salvation, the offers of the gospel the offers of salvation, and the present time the proper time to accept these offers. The morrow is none of ours: we know not what will be on the morrow, nor where we shall be. We now enjoy a day of grace; then let all be careful not to neglect it. Ministers of the gospel should look upon themselves as God's servants, and act in every thing suitably to that character. The apostle did so, by much patience in afflictions, by acting from good principles, and by due temper and behaviour. Believers, in this world, need the grace of God, to arm them against temptations, so as to bear the good report of men without pride; and so as to bear their reproaches with patience. They have nothing in themselves, but possess all things in Christ. Of such differences is a Christian's life made up, and through such a variety of conditions and reports, is our way to heaven; and we should be careful in all things to approve ourselves to God. The gospel, when faithfully preached, and fully received, betters the condition even of the poorest. They save what before they riotously spent, and diligently employ their time to useful purposes. They save and gain by religion, and thus are made rich, both for the world to come and for this, when compared with their sinful, profligate state, before they received the gospel.

## Verses 11–18

It is wrong for believers to join with the wicked and profane. The word unbeliever applies to all destitute of true faith. True pastors will caution their beloved children in the gospel, not to be unequally yoked. The fatal effects of neglecting Scripture precepts as to marriages clearly appear. Instead of a help meet, the union brings a snare. Those whose cross it is to be unequally united, without their wilful fault, may expect consolation under it; but when believers enter into such unions, against the express warnings of God's word, they must expect must distress. The caution also extends to common conversation. We should not join in friendship and acquaintance with wicked men and unbelievers. Though we cannot wholly avoid seeing and hearing, and being with such, yet we should never choose them for friends. We must not defile ourselves by converse with those who defile themselves with sin. Come out from the workers of iniquity, and separate from their vain and sinful pleasures and pursuits; from all conformity to the corruptions of this present evil world. If it be an envied privilege to be the son or daughter of an earthly prince, who can express the dignity and happiness of being sons and daughters of the Almighty?

