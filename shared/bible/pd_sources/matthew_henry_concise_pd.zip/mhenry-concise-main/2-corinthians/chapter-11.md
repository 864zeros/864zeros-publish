---
title: "2 Corinthians 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: The apostle gives the reasons for speaking in his own commendation. (1–14). Shows that he had freely preached the gospel. (5–15). Explains what he was going to add in defence of his own character. (16–21). He gives an account of his labours, cares, sufferings, dangers, and deliverances. (22–33)."
weight: 11
---

# 2 Corinthians 11 

## Chapter Outline

- The apostle gives the reasons for speaking in his own commendation. (1–14)
- Shows that he had freely preached the gospel. (5–15)
- Explains what he was going to add in defence of his own character. (16–21)
- He gives an account of his labours, cares, sufferings, dangers, and deliverances. (22–33)

## Verses 1–4

The apostle desired to preserve the Corinthians from being corrupted by the false apostles. There is but one Jesus, one Spirit, and one gospel, to be preached to them, and received by them; and why should any be prejudiced, by the devices of an adversary, against him who first taught them in faith? They should not listen to men, who, without cause, would draw them away from those who were the means of their conversion.

## Verses 5–15

It is far better to be plain in speech, yet walking openly and consistently with the gospel, than to be admired by thousands, and be lifted up in pride, so as to disgrace the gospel by evil tempers and unholy lives. The apostle would not give room for any to accuse him of worldly designs in preaching the gospel, that others who opposed him at Corinth, might not in this respect gain advantage against him. Hypocrisy may be looked for, especially when we consider the great power which Satan, who rules in the hearts of the children of disobedience, has upon the minds of many. And as there are temptations to evil conduct, so there is equal danger on the other side. It serves Satan's purposes as well, to set up good works against the atonement of Christ, and salvation by faith and grace. But the end will discover those who are deceitful workers; their work will end in ruin. Satan will allow his ministers to preach either the law or the gospel separately; but the law as established by faith in Christ's righteousness and atonement, and the partaking of his Spirit, is the test of every false system.

## Verses 16–21

It is the duty and practice of Christians to humble themselves, in obedience to the command and example of the Lord; yet prudence must direct in what it is needful to do things which we may do lawfully, even the speaking of what God has wrought for us, and in us, and by us. Doubtless here is reference to facts in which the character of the false apostles had been shown. It is astonishing to see how such men bring their followers into bondage, and how they take from them and insult them.

## Verses 22–33

The apostle gives an account of his labours and sufferings; not out of pride or vain-glory, but to the honour of God, who enabled him to do and suffer so much for the cause of Christ; and shows wherein he excelled the false apostles, who tried to lessen his character and usefulness. It astonishes us to reflect on this account of his dangers, hardships, and sufferings, and to observe his patience, perseverance, diligence, cheerfulness, and usefulness, in the midst of all these trials. See what little reason we have to love the pomp and plenty of this world, when this blessed apostle felt so much hardship in it. Our utmost diligence and services appear unworthy of notice when compared with his, and our difficulties and trials scarcely can be perceived. It may well lead us to inquire whether or not we really are followers of Christ. Here we may study patience, courage, and firm trust in God. Here we may learn to think less of ourselves; and we should ever strictly keep to truth, as in God's presence; and should refer all to his glory, as the Father of our Lord Jesus Christ, who is blessed for evermore.

