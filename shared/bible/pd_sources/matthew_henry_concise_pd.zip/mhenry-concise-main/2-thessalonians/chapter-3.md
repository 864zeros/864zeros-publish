---
title: "2 Thessalonians 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The apostle expresses confidence in the Thessalonians, and prays for them. (1–5). He charges them to withdraw from disorderly walkers, particularly from the lazy and busybodies. (6–15). And concludes with a prayer for them, and a greeting. (16–18)."
weight: 3
---

# 2 Thessalonians 3 

## Chapter Outline

- The apostle expresses confidence in the Thessalonians, and prays for them. (1–5)
- He charges them to withdraw from disorderly walkers, particularly from the lazy and busybodies. (6–15)
- And concludes with a prayer for them, and a greeting. (16–18)

## Verses 1–5

Those who are far apart still may meet together at the throne of grace; and those not able to do or receive any other kindness, may in this way do and receive real and very great kindness. Enemies to the preaching of the gospel, and persecutors of its faithful preachers, are unreasonable and wicked men. Many do not believe the gospel; and no wonder if such are restless and show malice in their endeavours to oppose it. The evil of sin is the greatest evil, but there are other evils we need to be preserved from, and we have encouragement to depend upon the grace of God. When once the promise is made, the performance is sure and certain. The apostle had confidence in them, but that was founded upon his confidence in God; for there is otherwise no confidence in man. He prays for them for spiritual blessings. It is our sin and our misery, that we place our affections upon wrong objects. There is not true love of God, without faith in Jesus Christ. If, by the special grace of God, we have that faith which multitudes have not, we should earnestly pray that we may be enabled, without reserve, to obey his commands, and that we may be enabled, without reserve, to the love of God, and the patience of Christ.

## Verses 6–15

Those who have received the gospel, are to live according to the gospel. Such as could work, and would not, were not to be maintained in idleness. Christianity is not to countenance slothfulness, which would consume what is meant to encourage the industrious, and to support the sick and afflicted. Industry in our callings as men, is a duty required by our calling as Christians. But some expected to be maintained in idleness, and indulged a curious and conceited temper. They meddled with the concerns of others, and did much harm. It is a great error and abuse of religion, to make it a cloak for idleness or any other sin. The servant who waits for the coming of his Lord aright, must be working as his Lord has commanded. If we are idle, the devil and a corrupt heart will soon find us somewhat to do. The mind of man is a busy thing; if it is not employed in doing good, it will be doing evil. It is an excellent, but rare union, to be active in our own business, yet quiet as to other people's. If any refused to labour with quietness, they were to note him with censure, and to separate from his company, yet they were to seek his good by loving admonitions. The Lords is with you while you are with him. Hold on your way, and hold on to the end. We must never give over, or tire in our work. It will be time enough to rest when we come to heaven.

## Verses 16–18

The apostle prays for the Thessalonians. And let us desire the same blessings for ourselves and our friends. Peace with God. This peace is desired for them always, or in every thing. Peace by all means; in every way; that, as they enjoyed the means of grace, they might use all methods to secure peace. We need nothing more to make us safe and happy, nor can we desire any thing better for ourselves and our friends, than to have God's gracious presence with us and them. No matter where we are, if God be with us; nor who is absent, if God be present. It is through the grace of our Lord Jesus Christ, that we hope to have peace with God, and to enjoy the presence of God. This grace is all in all to make us happy; though we wish ever so much to others, there remains enough for ourselves.

