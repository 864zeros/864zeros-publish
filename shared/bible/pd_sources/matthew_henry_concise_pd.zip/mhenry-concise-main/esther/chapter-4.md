---
title: "Esther 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: The Jews lament their danger. (1–4). Esther undertakes to plead for the Jews. (5–17)."
weight: 4
---

# Esther 4 

## Chapter Outline

- The Jews lament their danger. (1–4)
- Esther undertakes to plead for the Jews. (5–17)

## Verses 1–4

Mordecai avowed his relation to the Jews. Public calamities, that oppress the church of God, should affect our hearts more than any private affliction, and it is peculiarly distressing to occasion sufferings to others. God will keep those that are exposed to evil by the tenderness of their consciences.

## Verses 5–17

We are prone to shrink from services that are attended with peril or loss. But when the cause of Christ and his people demand it, we must take up our cross, and follow him. When Christians are disposed to consult their own ease or safety, rather than the public good, they should be blamed. The law was express, all knew it. It is not thus in the court of the King of kings: to the footstool of his throne of grace we may always come boldly, and may be sure of an answer of peace to the prayer of faith. We are welcome, even into the holiest, through the blood of Jesus. Providence so ordered it, that, just then, the king's affections had cooled toward Esther; her faith and courage thereby were the more tried; and God's goodness in the favour she now found with the king, thereby shone the brighter. Haman no doubt did what he could to set the king against her. Mordecai suggests, that it was a cause which, one way or other, would certainly be carried, and which therefore she might safely venture in. This was the language of strong faith, which staggered not at the promise when the danger was most threatening, but against hope believed in hope. He that by sinful devices will save his life, and will not trust God with it in the way of duty, shall lose it in the way of sin. Divine Providence had regard to this matter, in bringing Esther to be queen. Therefore thou art bound in gratitude to do this service for God and his church, else thou dost not answer the end of thy being raised up. There is wise counsel and design in all the providences of God, which will prove that they are all intended for the good of the church. We should, every one, consider for what end God has put us in the place where we are, and study to answer that end: and take care that we do not let it slip. Having solemnly commended our souls and our cause to God, we may venture upon his service. All dangers are trifling compared with the danger of losing our souls. But the trembling sinner is often as much afraid of casting himself, without reserve, upon the Lord's free mercy, as Esther was of coming before the king. Let him venture, as she did, with earnest prayer and supplication, and he shall fare as well and better than she did. The cause of God must prevail: we are safe in being united to it.

