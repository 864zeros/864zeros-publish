---
title: "Esther 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: Greatness of Ahasuerus—Mordecai's advancement. (1-3)."
weight: 10
---

# Esther 10 

## Chapter Outline

- Greatness of Ahasuerus—Mordecai's advancement. (1-3)

## Verses 1-3

Many instances of the grandeur of Ahasuerus might have been given: these were written in the Persian chronicles, which are long since lost, while the sacred writings will live till time shall be no more. The concerns of the despised worshippers of the Lord are deemed more important by the Holy Spirit, than the exploits of the most illustrious monarch on earth. Mordecai was truly great, and his greatness gave him opportunities of doing the more good. He did not disown his people the Jews, and no doubt kept to the true religion. He did not seek his own wealth, but the welfare of his people. Few have it in their power to do so much good as Mordecai; but all have it in their power to do hurt, and who has it not in his power to do some good? We are not required to do what is not in our power, or is unsuited to our station; but all are bound to live under the influence of the tempers displayed in the saints, whose examples are recorded in the Bible. If we live by the faith of Christ, we shall be active according to the ability and opportunities he gives us, in promoting his glory and the best interests of men. If our faith be genuine, it will work by love. Wait in faith and prayer, and the event will be safe and glorious; our salvation is sure, through our Lord Jesus Christ.


