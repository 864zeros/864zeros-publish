---
title: "2 Samuel 21 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "21"
description: "In this chapter: The Gibeonites avenged. (1–9). Rizpah's care for the bodies of Saul's descendants. (10–14). Battles with the Philistines. (15–22)."
weight: 21
---

# 2 Samuel 21 

## Chapter Outline

- The Gibeonites avenged. (1–9)
- Rizpah's care for the bodies of Saul's descendants. (10–14)
- Battles with the Philistines. (15–22)

## Verses 1–9

Every affliction arises from sin, and should lead us to repent and humble ourselves before God; but some troubles especially show that they are sent to bring sin to remembrance. God's judgments often look a great way back, which requires us to do so, when we are under his rebukes. It is not for us to object against the people's smarting for the sin of their king; perhaps they helped him. Nor against this generation suffering for the sin of the last. God often visits the sins of the fathers upon the children, and he gives no account of any matters. Time does not wear out the guilt of sin; nor can we build hopes of escape upon the delay of judgments. If we cannot understand all the reasons of Providence in this matter, still we have no right to demand that God should acquaint us with those reasons. It must be right, because it is the will of God, and in the end it will be proved to be so. Money is no satisfaction for blood. It should seem, Saul's posterity trod in his steps, for it is called a bloody house. It was the spirit of the family, therefore they are justly reckoned with for his sin, as well as for their own. The Gibeonites did not require this out of malice against Saul or his family. It was not to gratify any revenge, but for the public good. They were put to death at the beginning of harvest; they were thus sacrificed to turn away the wrath of Almighty God, who had withheld the harvest-mercies for some years past, and to obtain his favour in the present harvest. In vain do we expect mercy from God, unless we do justice upon our sins. Executions must not be thought cruel, which are for the public welfare.

## Verses 10–14

That a guilty land should enjoy many years of plenty, calls for gratitude; and we need not wonder misused abundance should be punished with scarcity; yet how few are disposed to ask of the Lord concerning the sinful cause, while numbers search for the second causes by which he is pleased to work! But the Lord will plead the cause of those who cannot or will not avenge themselves; and the prayers of the poor are of great power. When God sent rain to water the earth, these bodies were buried, for then it appeared that God was entreated for the land. When justice is done on earth, vengeance from heaven ceases. God is pacified, and is entreated for us through Christ, who was hanged on a tree, and so made a curse for us, to do away our guilt, though he was himself guiltless.

## Verses 15–22

These events seem to have taken place towards the end of David's reign. David fainted, but he did not flee, and God sent help in the time of need. In spiritual conflicts, even strong saints sometimes wax faint; then Satan attacks them furiously; but those who stand their ground and resist him, shall be relieved and made more than conquerors. Death is a Christian's last enemy, and a son of Anak; but through Him that triumphed for us, believers shall be more than conquerors at last, even over that enemy.

