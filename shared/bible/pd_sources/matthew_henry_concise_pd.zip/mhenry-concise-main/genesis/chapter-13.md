---
title: "Genesis 13 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "13"
description: "In this chapter: Abram returns out of Egypt with great riches. (1–4). Strife between the herdsmen of Abram and Lot. Abram gives Lot his choice of the country. (5–9). Lot chooses to dwell at Sodom. (10–13). God renews his promise to Abram, who removes to Hebron. (14–18)."
weight: 13
---

# Genesis 13 

## Chapter Outline

- Abram returns out of Egypt with great riches. (1–4)
- Strife between the herdsmen of Abram and Lot. Abram gives Lot his choice of the country. (5–9)
- Lot chooses to dwell at Sodom. (10–13)
- God renews his promise to Abram, who removes to Hebron. (14–18)

## Verses 1–4

Abram was very rich: he was very heavy, so the Hebrew word is; for riches are a burden; and they that will be rich, do but load themselves with thick clay, Hab 2:6. There is a burden of care in getting riches, fear in keeping them, temptation in using them, guilt in abusing them, sorrow in losing them, and a burden of account at last to be given up about them. Yet God in his providence sometimes makes good men rich men, and thus God's blessing made Abram rich without sorrow, Pr 10:22. Though it is hard for a rich man to get to heaven, yet in some cases it may be, Mr 10:23, 24. Nay, outward prosperity, if well managed, is an ornament to piety, and an opportunity for doing more good. Abram removed to Bethel. His altar was gone, so that he could not offer sacrifice; but he called on the name of the Lord. You may as soon find a living man without breath as one of God's people without prayer.

## Verses 5–9

Riches not only afford matter for strife, and are the things most commonly striven about; but they also stir up a spirit of contention, by making people proud and covetous. Mine and thine are the great make-bates of the world. Poverty and labour, wants and wanderings, could not separate Abram and Lot; but riches did so. Bad servants often make a great deal of mischief in families and among neighbours, by their pride and passion, lying, slandering, and talebearing. What made the quarrel worse was, that the Canaanite and the Perizzite dwelt then in the land. The quarrels of professors are the reproach of religion, and give occasion to the enemies of the Lord to blaspheme. It is best to keep the peace, that it be not broken; but the next best is, if differences do happen, with all speed to quench the fire that is broken out. The attempt to stay this strife was made by Abram, although he was the elder and the greater man. Abram shows himself to be a man of cool spirit, that had the command of his passion, and knew how to turn away wrath by a soft answer. Those that would keep the peace, must never render railing for railing. And of a condescending spirit; he was willing to beseech even his inferior to be at peace. Whatever others are for, the people of God must be for peace. Abram's plea for peace was very powerful. Let the people of the land contend about trifles; but let not us fall out, who know better things, and look for a better country. Professors of religion should be most careful to avoid contention. Many profess to be for peace who will do nothing towards it: not so Abram. When God condescends to beseech us to be reconciled, we may well beseech one another. Though God had promised Abram to give this land to his seed, yet he offered an equal or better share to Lot, who had not an equal right; and he will not, under the protection of God's promise, act hardly to his kinsman. It is noble to be willing to yield for peace’ sake.

## Verses 10–13

Abram having offered Lot the choice, he at once accepted it. Passion and selfishness make men rude. Lot looked to the goodness of the land; therefore he doubted not that in such a fruitful soil he should certainly thrive. But what came of it? Those who, in choosing relations, callings, dwellings, or settlements, are guided and governed by the lust of the flesh, the lust of the eye, or the pride of life, cannot expect God's presence or blessing. They are commonly disappointed even in that which they principally aim at. In all our choices this principle should rule, That is best for us, which is best for our souls. Lot little considered the badness of the inhabitants. The men of Sodom were impudent, daring sinners. This was the iniquity of Sodom, pride, fulness of bread, and abundance of idleness, Eze 16:49. God often gives great plenty to great sinners. It has often been the vexatious lot of good men to live among wicked neighbours; and it must be the more grievous, if, as Lot here, they have brought it upon themselves by a wrong choice.

## Verses 14–18

Those are best prepared for the visits of Divine grace, whose spirits are calm, and not ruffled with passion. God will abundantly make up in spiritual peace, what we lose for preserving neighbourly peace. When our relations are separated from us, yet God is not. Observe also the promises with which God now comforted and enriched Abram. Of two things he assures him; a good land, and a numerous issue to enjoy it. The prospects seen by faith are more rich and beautiful than those we see around us. God bade him walk through the land, not to think of fixing in it, but expect to be always unsettled, and walking through it to a better Canaan. He built an altar, in token of his thankfulness to God. When God meets us with gracious promises, he expects that we should attend him with humble praises. In outward difficulties, it is very profitable for the true believer to mediate on the glorious inheritance which the Lord has for him at the last.

