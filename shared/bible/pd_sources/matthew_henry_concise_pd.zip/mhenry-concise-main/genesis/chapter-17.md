---
title: "Genesis 17 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "17"
description: "In this chapter: God renews the covenant with Abram. (1–6). Circumcision instituted. (7–14). Sarai's name changed, Isaac promised. (15–22). Abraham and his family are circumcised. (23–27)."
weight: 17
---

# Genesis 17 

## Chapter Outline

- God renews the covenant with Abram. (1–6)
- Circumcision instituted. (7–14)
- Sarai's name changed, Isaac promised. (15–22)
- Abraham and his family are circumcised. (23–27)

## Verses 1–6

The covenant was to be accomplished in due time. The promised Seed was Christ, and Christians in him. And all who are of faith are blessed with faithful Abram, being partakers of the same covenant blessings. In token of this covenant his name was changed from Abram, “a high father,” to Abraham, “the father of a multitude.” All that the Christian world enjoys, it is indebted for to Abraham and his Seed.

## Verses 7–14

The covenant of grace is from everlasting in the counsels of it, and to everlasting in the consequences of it. The token of the covenant was circumcision. It is here said to be the covenant which Abraham and his seed must keep. Those who will have the Lord to be to them a God, must resolve to be to him a people. Not only Abraham and Isaac, and his posterity by Isaac, were to be circumcised, but also Ishmael and the bond-servants. It sealed not only the covenant of the land of Canaan to Isaac's posterity, but of heaven, through Christ, to the whole church of God. The outward sign is for the visible church; the inward seal of the Spirit is peculiar to those whom God knows to be believers, and he alone can know them. The religious observance of this institution was required, under a very severe penalty. It is dangerous to make light of Divine institutions, and to live in the neglect of them. The covenant in question was one that involved great blessings for the world in all future ages. Even the blessedness of Abraham himself, and all the rewards conferred upon him, were for Christ's sake. Abraham was justified, as we have seen, not by his own righteousness, but by faith in the promised Messiah.

## Verses 15–22

Here is the promise made to Abraham of a son by Sarai, in whom the promise made to him should be fulfilled. The assurance of this promise was the change of Sarai's name into Sarah. Sarai signifies my princess, as if her honour were confined to one family only; Sarah signifies a princess. The more favours God confers upon us, the more low we should be in our own eyes. Abraham showed great joy; he laughed, it was a laughter of delight, not of distrust. Now it was that Abraham rejoiced to see Christ's day; now he saw it and was glad, Joh 8:56. Abraham, dreading lest Ishmael should be abandoned and forsaken of God, put up a petition on his behalf. God gives us leave in prayer to be particular in making known our requests. Whatever is our care and fear, should be spread before God in prayer. It is the duty of parents to pray for their children, and the great thing we should desire is, that they may be kept in covenant with Him, and may have grace to walk before him in uprightness. Common blessings are secured to Ishmael. Outward good things are often given to those children of godly parents who are born after the flesh, for their parents' sake. Covenant blessings are reserved for Isaac, and appropriated to him.

## Verses 23–27

Abraham and all his family were circumcised; so receiving the token of the covenant, and distinguishing themselves from other families that had no part nor lot in the matter. It was an implicit obedience; he did as God said unto him, and did not ask why or wherefore. He did it because God bade him. It was a speedy obedience; in the self-same day. Sincere obedience makes no delay. Not only the doctrines of revelation, but the seals of God's covenant, remind us that we are guilty, polluted sinners. They show us our need of the blood of atonement; they point to the promised Saviour, and teach us to exercise faith in him. They show us that without regeneration, and sanctification by his Spirit, and the mortification of our corrupt and carnal inclinations, we cannot be in covenant with God. But let us remember that the true circumcision is that of the heart, by the Spirit, Ro 2:28, 29. Both under the old and new dispensation, many have had the outward profession, and the outward seal, who were never sealed by the Holy Spirit of promise.

