---
title: "Genesis 19 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "19"
description: "In this chapter: The destruction of Sodom, and the deliverance of Lot. (1–29). The sin and disgrace of Lot. (30–38)."
weight: 19
---

# Genesis 19 

## Chapter Outline

- The destruction of Sodom, and the deliverance of Lot. (1–29)
- The sin and disgrace of Lot. (30–38)

## Verses 1–29

Lot was good, but there was not one more of the same character in the city. All the people of Sodom were very wicked and vile. Care was therefore taken for saving Lot and his family. Lot lingered; he trifled. Thus many who are under convictions about their spiritual state, and the necessity of a change, defer that needful work. The salvation of the most righteous men is of God's mercy, not by their own merit. We are saved by grace. God's power also must be acknowledged in bringing souls out of a sinful state If God had not been merciful to us, our lingering had been our ruin. Lot must flee for his life. He must not hanker after Sodom. Such commands as these are given to those who, through grace, are delivered out of a sinful state and condition. Return not to sin and Satan. Rest not in self and the world. Reach toward Christ and heaven, for that is escaping to the mountain, short of which we must not stop. Concerning this destruction, observe that it is a revelation of the wrath of God against sin and sinners of all ages. Let us learn from hence the evil of sin, and its hurtful nature; it leads to ruin.

## Verses 30–38

See the peril of security. Lot, who kept chaste in Sodom, and was a mourner for the wickedness of the place, and a witness against it, when in the mountain, alone, and, as he thought, out of the way of temptation, is shamefully overtaken. Let him that thinks he stands high, and stands firm, take heed lest he fall. See the peril of drunkenness; it is not only a great sin itself, but lets in many sins, which bring a lasting wound and dishonour. Many a man does that, when he is drunk, which, when he is sober, he could not think of without horror. See also the peril of temptation, even from relations and friends, whom we love and esteem, and expect kindness from. We must dread a snare, wherever we are, and be always upon our guard. No excuse can be made for the daughters, nor for Lot. Scarcely any account can be given of the affair but this, The heart is deceitful above all things, and desperately wicked: who can know it? From the silence of the Scripture concerning Lot henceforward, learn that drunkenness, as it makes men forgetful, so it makes them to be forgotten.

