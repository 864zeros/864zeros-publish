---
title: "Genesis 28 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "28"
description: "In this chapter: Isaac sends Jacob to Padan-aram. (1–5). Esau marries the daughter of Ishmael. (6–9). Jacob's vision. (10–15). The stone of Beth-el. (16–19). Jacob's vow. (20–22)."
weight: 28
---

# Genesis 28 

## Chapter Outline

- Isaac sends Jacob to Padan-aram. (1–5)
- Esau marries the daughter of Ishmael. (6–9)
- Jacob's vision. (10–15)
- The stone of Beth-el. (16–19)
- Jacob's vow. (20–22)

## Verses 1–5

Jacob had blessings promised both as to this world and that which is to come; yet goes out to a hard service. This corrected him for the fraud on his father. The blessing shall be conferred on him, yet he shall smart for the indirect course taken to obtain it. Jacob is dismissed by his father with a solemn charge. He must not take a wife of the daughters of Canaan: those who profess religion, should not marry with those that care not for religion. Also with a solemn blessing. Isaac had before blessed him unwittingly; now he does it designedly. This blessing is more full than the former; it is a gospel blessing. This promise looks as high as heaven, of which Canaan was a type. That was the better country which Jacob and the other patriarchs had in view.

## Verses 6–9

Good examples impress even the profane and malicious. But Esau thought, by pleasing his parents in one thing, to atone for other wrong doings. Carnal hearts are apt to think themselves as good as they should be, because in some one matter they are not so bad as they have been.

## Verses 10–15

Jacob's conduct hitherto, as recorded, was not that of one who simply feared and trusted in God. But now in trouble, obliged to flee, he looked only to God to make him to dwell in safety, and he could lie down and sleep in the open air with his head upon a stone. Any true believer would be willing to take up with Jacob's pillow, provided he might have Jacob's vision. God's time to visit his people with his comforts, is, when they are most destitute of other comforts, and other comforters. Jacob saw a ladder which reached from earth to heaven, the angels going up and coming down, and God himself at the head of it. This represents, 1. The providence of God, by which there is a constant intercourse kept up between heaven and earth. This let Jacob know that he had both a good guide and a good guard. 2. The mediation of Christ. He is this ladder; the foot on earth in his human nature, the top in heaven in his Divine nature. Christ is the Way; all God's favours come to us, and all our services go to him, by Christ, Joh 1:51. By this way, sinners draw near to the throne of grace with acceptance. By faith we perceive this way, and in prayer we approach by it. In answer to prayer we receive all needful blessings of providence and grace. We have no way of getting to heaven but by Christ. And when the soul, by faith, can see these things, then every place will become pleasant, and every prospect joyful. He will never leave us, until his last promise is accomplished in our everlasting happiness. God now spake comfortably to Jacob. He spake from the head of the ladder. All the glad tidings we receive from heaven come through Jesus Christ. The Messiah should come from Jacob. Christ is the great blessing of the world. All that are blessed, are blessed in him, and none of any family are shut out from blessedness in him, but those that shut out themselves. Jacob had to fear danger from his brother Esau; but God promises to keep him. He had a long journey before him; to an unknown country; but, Behold, I am with thee, and God promises to bring him back again to this land. He seemed to be forsaken of all his friends; but God gives him this assurance, I will not leave thee. Whom God loves, he never leaves.

## Verses 16–19

God manifested himself and his favour, to Jacob, when he was asleep. The Spirit, like the wind, blows when and where it listeth, and God's grace, like the dew, tarrieth not for the sons of men. Jacob sought to improve the visit God had made him. Wherever we are, in the city or in the desert, in the house or in the field, in the shop or in the street, we may keep up our intercourse with Heaven, if it is not our own fault. But the more we see of God, the more cause we see for holy trembling before him.

## Verses 20–22

Jacob made a solemn vow on this occasion. In this observe, 1. Jacob's faith. He trusts that God will be with him, and will keep him; he depends upon it. 2. Jacob's moderation in his desires. He asks not for soft clothing and dainty meat. If God give us much, we are bound to be thankful, and to use it for him; if he gives us but little, we are bound to be content, and cheerfully to enjoy him in it. 3. Jacob's piety, and his regard to God, appear in what he desired, that God would be with him, and keep him. We need desire no more to make us easy and happy. Also his resolution is, to cleave to the Lord, as his God in covenant. When we receive more than common mercy from God, we should abound in gratitude to him. The tenth is a fit proportion to be devoted to God, and employed for him; though it may be more or less, as God prospers us, 1Co 16:2. Let us then remember our Bethels, how we stand engaged by solemn vows to yield ourselves to the Lord, to take him for our God, and to devote all we have and are to his glory!

