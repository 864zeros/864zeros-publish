---
title: "Genesis 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: The sons of Noah, of Japheth, of Ham. (1–7). Nimrod the first monarch. (8–14). The descendants of Canaan, The sons of Shem. (15–32)."
weight: 10
---

# Genesis 10 

## Chapter Outline

- The sons of Noah, of Japheth, of Ham. (1–7)
- Nimrod the first monarch. (8–14)
- The descendants of Canaan, The sons of Shem. (15–32)

## Verses 1–7

This chapter shows concerning the three sons of Noah, that of them was the whole earth overspread. No nation but that of the Jews can be sure from which of these seventy it has come. The lists of names of fathers and sons were preserved of the Jews alone, for the sake of the Messiah. Many learned men, however, have, with some probability, shown which of the nations of the earth descended from each of the sons of Noah To the posterity of Japheth were allotted the isles of the gentiles; probably, the island of Britain among the rest. All places beyond the sea from Judea are called isles, Jer 25:22. That promise, Isa 42:4, The isles shall wait for his law, speaks of the conversion of the gentiles to the faith of Christ.

## Verses 8–14

Nimrod was a great man in his day; he began to be mighty in the earth, Those before him were content to be upon the same level with their neighbours, and though every man bare rule in his own house, yet no man pretended any further. Nimrod was resolved to lord it over his neighbours. The spirit of the giants before the flood, who became mighty men, and men of renown, Ge 6:4, revived in him. Nimrod was a great hunter. Hunting then was the method of preventing the hurtful increase of wild beasts. This required great courage and address, and thus gave an opportunity for Nimrod to command others, and gradually attached a number of men to one leader. From such a beginning, it is likely, that Nimrod began to rule, and to force others to submit. He invaded his neighbours' rights and properties, and persecuted innocent men; endeavouring to make all his own by force and violence. He carried on his oppressions and violence in defiance of God himself. Nimrod was a great ruler. Some way or other, by arts or arms, he got into power, and so founded a monarchy, which was the terror of the mighty, and bid fair to rule all the world. Nimrod was a great builder. Observe in Nimrod the nature of ambition. It is boundless; much would have more, and still cries, Give, give. It is restless; Nimrod, when he had four cities under his command, could not be content till he had four more. It is expensive; Nimrod will rather be at the charge of rearing cities, than not have the honour of ruling them. It is daring, and will stick at nothing. Nimrod's name signifies rebellion; tyrants to men are rebels to God. The days are coming, when conquerors will no longer be spoken of with praise, as in man's partial histories, but be branded with infamy, as in the impartial records of the Bible.

## Verses 15–32

The posterity of Canaan were numerous, rich, and pleasantly seated; yet Canaan was under a Divine curse, and not a curse causeless. Those that are under the curse of God, may, perhaps, thrive and prosper in this world; for we cannot know love or hatred, the blessing or the curse, by what is before us, but by what is within us. The curse of God always works really, and always terribly. Perhaps it is a secret curse, a curse to the soul, and does not work so that others can see it; or a slow curse, and does not work soon; but sinners are reserved by it for a day of wrath Canaan here has a better land than either Shem or Japheth, and yet they have a better lot, for they inherit the blessing. Abram and his seed, God's covenant people, descended from Eber, and from him were called Hebrews. How much better it is to be like Eber, the father of a family of saints and honest men, than the father of a family of hunters after power, worldly wealth, or vanities. Goodness is true greatness.

