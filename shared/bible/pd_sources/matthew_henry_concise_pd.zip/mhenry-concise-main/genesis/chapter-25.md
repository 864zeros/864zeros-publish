---
title: "Genesis 25 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "25"
description: "In this chapter: Abraham's family by Keturah, His death and burial. (1–10). God blesses Isaac, The descendants of Ishmael. (11–18). The birth of Esau and Jacob. (19–26). The different characters of Esau and Jacob. (27, 28). Esau despises and sells his birth-right. (29–34)."
weight: 25
---

# Genesis 25 

## Chapter Outline

- Abraham's family by Keturah, His death and burial. (1–10)
- God blesses Isaac, The descendants of Ishmael. (11–18)
- The birth of Esau and Jacob. (19–26)
- The different characters of Esau and Jacob. (27, 28)
- Esau despises and sells his birth-right. (29–34)

## Verses 1–10

All the days, even of the best and greatest saints, are not remarkable days; some slide on silently; such were these last days of Abraham. Here is an account of Abraham's children by Keturah, and the disposition which he made of his estate. After the birth of these sons, he set his house in order, with prudence and justice. He did this while he yet lived. It is wisdom for men to do what they find to do while they live, as far as they can. Abraham lived 175 years; just one hundred years after he came to Canaan; so long he was a sojourner in a strange country. Whether our stay in this life be long or short, it matters but little, provided we leave behind us a testimony to the faithfulness and goodness of the Lord, and a good example to our families. We are told that his sons Isaac and Ishmael buried him. It seems that Abraham had himself brought them together while he lived. Let us not close the history of the life of Abraham without blessing God for such a testimony of the triumph of faith.

## Verses 11–18

Ishmael had twelve sons, whose families became distinct tribes. They peopled a very large country that lay between Egypt and Assyria, called Arabia. The number and strength of this family were the fruit of the promise, made to Hagar and to Abraham, concerning Ishmael.

## Verses 19–26

Isaac seems not to have been much tried, but to have spent his days in quietness. Jacob and Esau were prayed for; their parents, after being long childless, obtained them by prayer. The fulfilment of God's promise is always sure, yet it is often slow. The faith of believers is tried, their patience exercised, and mercies long waited for are more welcome when they come. Isaac and Rebekah kept in view the promise of all nations being blessed in their posterity, therefore were not only desirous of children, but anxious concerning every thing which seemed to mark their future character. In all our doubts we should inquire of the Lord by prayer. In many of our conflicts with sin and temptation, we may adopt Rebekah's words, “If it be so, why am I thus?” If a child of God, why so careless or carnal? If not a child of God, why so afraid of, or so burdened with sin?

## Verses 27, 28

Esau hunted the beasts of the field with dexterity and success, till he became a conqueror, ruling over his neighbours. Jacob was a plain man, one that liked the true delights of retirement, better than all pretended pleasures. He was a stranger and a pilgrim in his spirit, and a shepherd all his days. Isaac and Rebekah had but these two children, one was the father's darling, and the other the mother's. And though godly parents must feel their affections most drawn over towards a godly child, yet they will not show partiality. Let their affections lead them to do what is just and equal to every child, or evils will arise.

## Verses 29–34

We have here the bargain made between Jacob and Esau about the right, which was Esau's by birth, but Jacob's by promise. It was for a spiritual privilege; and we see Jacob's desire of the birth-right, but he sought to obtain it by crooked courses, not like his character as a plain man. He was right, that he coveted earnestly the best gifts; he was wrong, that he took advantage of his brother's need. The inheritance of their father's worldly goods did not descend to Jacob, and was not meant in this proposal. But it includeth the future possession of the land of Canaan by his children's children, and the covenant made with Abraham as to Christ the promised Seed. Believing Jacob valued these above all things; unbelieving Esau despised them. Yet although we must be of Jacob's judgment in seeking the birth-right, we ought carefully to avoid all guile, in seeking to obtain even the greatest advantages. Jacob's pottage pleased Esau's eye. “Give me some of that red;” for this he was called Edom, or Red. Gratifying the sensual appetite ruins thousands of precious souls. When men's hearts walk after their own eyes, Job 31:7, and when they serve their own bellies, they are sure to be punished. If we use ourselves to deny ourselves, we break the force of most temptations. It cannot be supposed that Esau was dying of hunger in Isaac's house. The words signify, I am going towards death; he seems to mean, I shall never live to inherit Canaan, or any of those future supposed blessings; and what signifies it who has them when I am dead and gone. This would be the language of profaneness, with which the apostle brands him, Heb 12:16; and this contempt of the birth-right is blamed, verse 34. It is the greatest folly to part with our interest in God, and Christ, and heaven, for the riches, honours, and pleasures of this world; it is as bad a bargain as his who sold a birth-right for a dish of pottage. Esau ate and drank, pleased his palate, satisfied his appetite, and then carelessly rose up and went his way, without any serious thought, or any regret, about the bad bargain he had made. Thus Esau despised his birth-right. By his neglect and contempt afterwards, and by justifying himself in what he had done, he put the bargain past recall. People are ruined, not so much by doing what is amiss, as by doing it and not repenting of it.

