---
title: "Genesis 22 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "22"
description: "In this chapter: God commands Abraham to offer up Isaac. (1, 2). Abraham's faith and obedience to the Divine command. (3–10). Another sacrifice is provided instead of Isaac. (11–14). The covenant with Abraham renewed. (15–19). The family of Nahor. (20–24)."
weight: 22
---

# Genesis 22 

## Chapter Outline

- God commands Abraham to offer up Isaac. (1, 2)
- Abraham's faith and obedience to the Divine command. (3–10)
- Another sacrifice is provided instead of Isaac. (11–14)
- The covenant with Abraham renewed. (15–19)
- The family of Nahor. (20–24)

## Verses 1, 2

We never are secure from trials In Hebrew, to tempt, and to try, or to prove, are expressed by the same word. Every trial is indeed a temptation, and tends to show the dispositions of the heart, whether holy or unholy. But God proved Abraham, not to draw him to sin, as Satan tempts. Strong faith is often exercised with strong trials, and put upon hard services. The command to offer up his son, is given in such language as makes the trial more grievous; every word here is a sword. Observe, 1. The person to be offered: Take thy son; not thy bullocks and thy lambs. How willingly would Abraham have parted with them all to redeem Isaac! Thy son; not thy servant. Thine only son; thine only son by Sarah. Take Isaac, that son whom thou lovest. 2. The place: three days' journey off; so that Abraham might have time to consider, and might deliberately obey. 3. The manner: Offer him for a burnt-offering; not only kill his son, his Isaac, but kill him as a sacrifice; kill him with all that solemn pomp and ceremony, with which he used to offer his burnt-offerings.

## Verses 3–10

Never was any gold tried in so hot a fire. Who but Abraham would not have argued with God? Such would have been the thought of a weak heart; but Abraham knew that he had to do with a God, even Jehovah. Faith had taught him not to argue, but to obey. He is sure that what God commands is good; that what he promises cannot be broken. In matters of God, whoever consults with flesh and blood, will never offer up his Isaac to God. The good patriarch rises early, and begins his sad journey. And now he travels three days, and Isaac still is in his sight! Misery is made worse when long continued. The expression, We will come again to you, shows that Abraham expected that Isaac, being raised from the dead, would return with him. It was a very affecting question that Isaac asked him, as they were going together: “My father,” said Isaac; it was a melting word, which, one would think, should strike deeper in the heart of Abraham, than his knife could in the heart of Isaac. Yet he waits for his son's question. Then Abraham, where he meant not, prophesies: “My son, God will provide a lamb for a burnt-offering.” The Holy Spirit, by his mouth, seems to predict the Lamb of God, which he has provided, and which taketh away the sin of the world. Abraham lays the wood in order for his Isaac's funeral pile, and now tells him the amazing news: Isaac, thou art the lamb which God has provided! Abraham, no doubt, comforting him with the same hopes with which he himself by faith was comforted. Yet it is necessary that the sacrifice be bound. The great Sacrifice, which, in the fulness of time, was to be offered up, must be bound, and so must Isaac. This being done, Abraham takes the knife, and stretches out his hand to give the fatal blow. Here is an act of faith and obedience, which deserves to be a spectacle to God, angels, and men. God, by his providence, calls us to part with an Isaac sometimes, and we must do it with cheerful submission to his holy will, 1Sa 3:18.

## Verses 11–14

It was not God's intention that Isaac should actually be sacrificed, yet nobler blood than that of animals, in due time, was to be shed for sin, even the blood of the only begotten Son of God. But in the mean while God would not in any case have human sacrifices used, another sacrifice is provided. Reference must be had to the promised Messiah, the blessed Seed. Christ was sacrificed in our stead, as this ram instead of Isaac, and his death was our discharge. And observe, that the temple, the place of sacrifice, was afterwards built upon this same mount Moriah; and Calvary, where Christ was crucified, was near. A new name was given to that place, for the encouragement of all believers, to the end of the world, cheerfully to trust in God, and obey him. Jehovah-jireh, the Lord will provide; probably alluding to what Abraham had said, God will provide himself a lamb. The Lord will always have his eye upon his people, in their straits and distresses, that he may give them seasonable help.

## Verses 15–19

There are high declarations of God's favour to Abraham in this confirmation of the covenant with him, exceeding any he had yet been blessed with. Those that are willing to part with any thing for God, shall have it made up to them with unspeakable advantage. The promise, verse 18, doubtless points at the Messiah, and the grace of the gospel. Hereby we know the loving-kindness of God our Saviour towards sinful man, in that he hath not withheld his Son, his only Son, from us. Hereby we perceive the love of Christ, in that he gave himself a sacrifice for our sins. Yet he lives, and calls to sinners to come to him, and partake of his blood-bought salvation. He calls to his redeemed people to rejoice in him, and to glorify him. What then shall we render for all his benefits? Let his love constrain us to live not to ourselves, but to Him who died for us, and rose again. Admiring and adoring His grace, let us devote our all to his service, who laid down his life for our salvation. Whatever is dearest to us upon earth is our Isaac. And the only way for us to find comfort in an earthly thing, is to give it by faith into the hands of God. Yet remember that Abraham was not justified by his readiness to obey, but by the infinitely more noble obedience of Jesus Christ; his faith receiving this, relying on this, rejoicing in this, disposed and made him able for such wonderful self-denial and duty. (Ge 22:20-24)

## Verses 20–24

This chapter ends with some account of Nahor's family, who had settled at Haran. This seems to be given for the connexion which it had with the church of God. From thence Isaac and Jacob took wives; and before the account of those events this list is recorded. It shows that though Abraham saw his own family highly honoured with privileges, admitted into covenant, and blessed with the assurance of the promise, yet he did not look with disdain upon his relations, but was glad to hear of the increase and welfare of their families.

