---
title: "Genesis 23 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "23"
description: "In this chapter: The death of Sarah, Abraham applies for a burying-place. (1–13). Sarah's burying-place. (14–20)."
weight: 23
---

# Genesis 23 

## Chapter Outline

- The death of Sarah, Abraham applies for a burying-place. (1–13)
- Sarah's burying-place. (14–20)

## Verses 1–13

The longest life must shortly come to a close. Blessed be God that there is a world where sin, death, vanity, and vexation cannot enter. Blessed be his name, that even death cannot part believers from union with Christ. Those whom we most love, yea, even our own bodies, which we so care for, must soon become loathsome lumps of clays, and be buried out of sight. How loose then should we be to all earthly attachments and adornments! Let us seek rather that our souls be adorned with heavenly graces. Abraham rendered honour and respect to the princes of Heth, although of the ungodly Canaanites. The religion of the Bible enjoins to pay due respect to all in authority, without flattering their persons, or countenancing their crimes if they are unworthy characters. And the noble generosity of these Canaanites shames and condemns the closeness, selfishness, and ill-humour of many that call themselves Israelites. It was not in pride that Abraham refused the gift, because he scorned to be beholden to Ephron; but in justice and in prudence. Abraham was able to pay for the field, and therefore would not take advantage of Ephron's generosity. Honesty, as well as honour, forbids us to take advantage of our neighbour's liberality, and to impose, upon those who give freely.

## Verses 14–20

Prudence, as well as justice, directs us to be fair and open in our dealings; cheating bargains will not bear the light. Abraham, without fraud or delay, pays the money. He pays it at once in full, without keeping any part back; and by weight, current money with the merchant, without deceit. See how anciently money was used for the help of trade, and how honestly it should be paid when it is due. Though all the land of Canaan was Abraham by promise, yet the time of his possessing it not being come, what he had occasion for he bought and paid for. Dominion is not founded in grace. The saints' title to an eternal inheritance does not entitle them to the possessions of this world, nor justify them in doing wrong. Ephron honestly and fairly makes a good title to the land. As that which is bought, must be honestly paid for, so that which is sold, must be honestly delivered and secured. Let us manage our concerns with punctuality and exactness, in order to avoid contention. Abraham buried Sarah in cave. or vault, which was in the purchased field. It would tend to endear the land to his posterity. And it is worth noting, that a burying-place was the only piece of the land which Abraham possessed in Canaan. Those who have least of this earth, find a grave in it. This sepulchre was at the end of the field; whatever our possessions are, there is a burial-place at the end of them. It was a token of his belief and expectation of the resurrection. Abraham is contented to be still a pilgrim while he lives, but secures a place where, when he dies, his flesh may rest in hope. After all, the chief concern is, with whom we shall rise.

