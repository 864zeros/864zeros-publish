---
title: "Genesis 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The first sabbath. (1–3). Particulars about the creation. (4–7). The planting of the garden of Eden. (8–14). Man is placed in it. (15). God's command. (16, 17). The animals named, The making of woman, The Divine institution of marriage. (18–25)."
weight: 2
---

# Genesis 2 

## Chapter Outline

- The first sabbath. (1–3)
- Particulars about the creation. (4–7)
- The planting of the garden of Eden. (8–14)
- Man is placed in it. (15)
- God's command. (16, 17)
- The animals named, The making of woman, The Divine institution of marriage. (18–25)

## Verses 1–3

After six days, God ceased from all works of creation. In miracles, he has overruled nature, but never changed its settled course, or added to it. God did not rest as one weary, but as one well pleased. Notice the beginning of the kingdom of grace, in the sanctification, or keeping holy, of the sabbath day. The solemn observing of one day in seven as a day of holy rest and holy work, to God's honour, is the duty of all to whom God has made known his holy sabbaths. At this time none of the human race were in being but our first parents. For them the sabbath was appointed; and clearly for all succeeding generations also. The Christian sabbath, which we observe, is a seventh day, and in it we celebrate the rest of God the Son, and the finishing the work of our redemption.

## Verses 4–7

Here is a name given to the Creator, “Jehovah.” Where the word “LORD” is printed in capital letters in our English Bibles, in the original it is “Jehovah.” Jehovah is that name of God, which denotes that he alone has his being of himself, and that he gives being to all creatures and things. Further notice is taken of plants and herbs, because they were made and appointed to be food for man. The earth did not bring forth its fruits of itself: this was done by Almighty power. Thus grace in the soul grows not of itself in nature's soil, but is the work of God. Rain also is the gift of God; it came not till the Lord God caused it. Though God works by means, yet when he pleases he can do his own work without them; and though we must not tempt God in the neglect of means, we must trust God, both in the use and in the want of means. Some way or other, God will water the plants of his own planting. Divine grace comes down like the dew, and waters the church without noise. Man was made of the small dust, such as is on the surface of the earth. The soul was not made of the earth, as the body: pity then that it should cleave to the earth, and mind earthly things. To God we must shortly give an account, how we have employed these souls; and if it be found that we have lost them, though it were to gain the world, we are undone for ever! Fools despise their own souls, by caring for their bodies before their souls.

## Verses 8–14

The place fixed upon for Adam to dwell in, was not a palace, but a garden. The better we take up with plain things, and the less we seek things to gratify pride and luxury, the nearer we approach to innocency. Nature is content with a little, and that which is most natural; grace with less; but lust craves every thing, and is content with nothing. No delights can be satisfying to the soul, but those which God himself has provided and appointed for it. Eden signifies delight and pleasure. Wherever it was, it had all desirable conveniences, without any inconvenience, though no other house or garden on earth ever was so. It was adorned with every tree pleasant to the sight, and enriched with every tree that yielded fruit grateful to the taste and good for food. God, as a tender Father, desired not only Adam's profit, but his pleasure; for there is pleasure with innocency, nay there is true pleasure only in innocency. When Providence puts us in a place of plenty and pleasure, we ought to serve God with gladness of heart in the good things he gives us. Eden had two trees peculiar to itself. 1. There was the tree of life in the midst of the garden. Of this man might eat and live. Christ is now to us the Tree of life, Re 2:7; 22:2; and the Bread of life, Joh 6:48, 51. 2. There was the tree of the knowledge of good and evil, so called because there was a positive revelation of the will of God about this tree, so that by it man might know moral good and evil. What is good? It is good not to eat of this tree. What is evil? It is evil to eat of this tree. In these two trees God set before Adam good and evil, the blessing and the curse.

## Verse 15

After God had formed Adam, he put him in the garden. All boasting was thereby shut out. Only he that made us can make us happy; he that is the Former of our bodies, and the Father of our spirits, and none but he, can fully provide for the happiness of both. Even in paradise itself man had to work. None of us were sent into the world to be idle. He that made our souls and bodies, has given us something to work with; and he that gave us this earth for our habitation, has made us something to work upon. The sons and heirs of heaven, while in this world, have something to do about this earth, which must have its share of their time and thoughts; and if they do it with an eye to God, they as truly serve him in it, as when they are upon their knees. Observe that the husbandman's calling is an ancient and honourable calling; it was needful even in paradise. Also, there is true pleasure in the business God calls us to, and employs us in. Adam could not have been happy if he had been idle: it is still God's law, He that will not work has no right to eat, 2Th 3:10.

## Verses 16, 17

Let us never set up our own will against the holy will of God. There was not only liberty allowed to man, in taking the fruits of paradise, but everlasting life made sure to him upon his obedience. There was a trial appointed of his obedience. By transgression he would forfeit his Maker's favour, and deserve his displeasure, with all its awful effects; so that he would become liable to pain, disease, and death. Worse than that, he would lose the holy image of God, and all the comfort of his favour; and feel the torment of sinful passions, and the terror of his Maker's vengeance, which must endure for ever with his never dying soul. The forbidding to eat of the fruit of a particular tree was wisely suited to the state of our first parents. In their state of innocence, and separated from any others, what opportunity or what temptation had they to break any of the ten commandments? The event proves that the whole human race were concerned in the trial and fall of our first parents. To argue against these things is to strive against stubborn facts, as well as Divine revelation; for man is sinful, and shows by his first actions, and his conduct ever afterwards, that he is ready to do evil. He is under the Divine displeasure, exposed to sufferings and death. The Scriptures always speak of man as of this sinful character, and in this miserable state; and these things are true of men in all ages, and of all nations.

## Verses 18–25

Power over the creatures was given to man, and as a proof of this he named them all. It also shows his insight into the works of God. But though he was lord of the creatures, yet nothing in this world was a help meet for man. From God are all our helpers. If we rest in God, he will work all for good. God caused deep sleep to fall on Adam; while he knows no sin, God will take care that he shall feel no pain. God, as her Father, brought the woman to the man, as his second self, and a help meet for him. That wife, who is of God's making by special grace, and of God's bringing by special providence, is likely to prove a help meet for a man. See what need there is, both of prudence and prayer in the choice of this relation, which is so near and so lasting. That had need to be well done, which is to be done for life. Our first parents needed no clothes for covering against cold or heat, for neither could hurt them: they needed none for ornament. Thus easy, thus happy, was man in his state of innocency. How good was God to him! How many favours did he load him with! How easy were the laws given to him! Yet man, being in honour, understood not his own interest, but soon became as the beasts that perish.

