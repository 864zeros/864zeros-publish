---
title: "Genesis 16 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "16"
description: "In this chapter: Sarai gives Hagar to Abram. (1–3). Hagar's misbehaviour to Sarai. (4–6). The Angel commands Hagar to return, The promise to her Birth of Ishmael. (7–16)."
weight: 16
---

# Genesis 16 

## Chapter Outline

- Sarai gives Hagar to Abram. (1–3)
- Hagar's misbehaviour to Sarai. (4–6)
- The Angel commands Hagar to return, The promise to her Birth of Ishmael. (7–16)

## Verses 1–3

Sarai, no longer expecting to have children herself, proposed to Abram to take another wife, whose children she might; her slave, whose children would be her property. This was done without asking counsel of the Lord. Unbelief worked, God's almighty power was forgotten. It was a bad example, and a source of manifold uneasiness. In every relation and situation in life there is some cross for us to bear: much of the exercise of faith consists in patiently submitting, in waiting the Lord's time, and using only those means which he appoints for the removal of the cross. Foul temptations may have very fair pretences, and be coloured with that which is very plausible. Fleshly wisdom puts us out of God's way. This would not be the case, if we would ask counsel of God by his word and by prayer, before we attempt that which is doubtful.

## Verses 4–6

Abram's unhappy marriage to Hagar very soon made a great deal of mischief. We may thank ourselves for the guilt and grief that follow us, when we go out of the way of our duty. See it in this case, Passionate people often quarrel with others, for things of which they themselves must bear the blame. Sarai had given her maid to Abram, yet she cries out, My wrong be upon thee. That is never said wisely, which pride and anger put into our mouths. Those are not always in the right, who are most loud and forward in appealing to God: such rash and bold imprecations commonly speak guilt and a bad cause. Hagar forgot that she herself had first given the provocation, by despising her mistress. Those that suffer for their faults, ought to bear it patiently, 1Pe 2:20.

## Verses 7–16

Hagar was out of her place, and out of the way of her duty, and going further astray, when the Angel found her. It is a great mercy to be stopped in a sinful way, either by conscience or by providence. Whence comest thou? Consider that thou art running from duty, and the privileges thou wast blest with in Abram's tent. It is good to live in a religious family, which those ought to consider who have this advantage. Whither wilt thou go? Thou art running into sin; if Hagar return to Egypt, she will return to idol gods, and into danger in the wilderness through which she must travel. Recollecting who we are, would often teach us our duty. Inquiring whence we came, would show us our sin and folly. Considering whither we shall go, discovers our danger and misery. And those who leave their space and duty, must hasten their return, how mortifying soever it be. The declaration of the Angel, “I will,” shows this Angel was the eternal Word and Son of God. Hagar could not but admire the Lord's mercy, and feel, Have I, who am so unworthy, been favoured with a gracious visit from the Lord? She was brought to a better temper, returned, and by her behaviour softened Sarai, and received more gentle treatment. Would that we were always suitably impressed with this thought, Thou God seest me!

