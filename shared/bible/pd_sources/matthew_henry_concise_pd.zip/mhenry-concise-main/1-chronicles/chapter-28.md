---
title: "1 Chronicles 28 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "28"
description: "In this chapter: David exhorts the people to the fear of the Lord. (1–10). He gives instructions for the temple. (11–21)."
weight: 28
---

# 1 Chronicles 28 

## Chapter Outline

- David exhorts the people to the fear of the Lord. (1–10)
- He gives instructions for the temple. (11–21)

## Verses 1–10

During David's last sickness, many chief priests and Levites were at Jerusalem. Finding himself able, David spoke of his purpose to build a temple for God, and of God's disallowing that purpose. He opened to them God's gracious purposes concerning Solomon. David charged them to cleave stedfastly to God and their duty. We cannot do our work as we should, unless we put on resolution, and fetch in strength from Divine grace. Religion or piety has two distinct parts. The first is knowledge of God, the second is worship of God. David says, Know thou the God of thy father, and serve him with a perfect heart and a willing mind. God is made known by his works and word. Revelation alone shows the whole character of God, in his providence, his holy law, his condemnation of sinners, his blessed gospel, and the ministration of the Spirit to all true believers. The natural man cannot receive this knowledge of God. But thus we learn the value of the Saviour's atonement, and of the sanctification of the Holy Spirit, and are influenced to walk in all his commandments. It brings a sinner to his proper place at the foot of the cross, as a poor, guilty, helpless worm, deserving wrath, yet expecting every thing needful from the free mercy and grace of God our Father, and the Lord Jesus Christ. Having been forgiven much, the pardoned sinner learns to love much.

## Verses 11–21

The temple must be a sacred thing, and a type of Christ; it must be framed by Divine teaching. Christ is the true temple, the church is the gospel temple, and heaven the everlasting temple; all are framed according to the Divine counsels, and the plan laid in the Divine wisdom, ordained before the world, for God's glory and our good. David gave this pattern to Solomon, that he might go by rule. Materials were provided for the most costly utensils of the temple. Directions were given which way to look for help in this great undertaking. Be not dismayed; God will help thee, and thou must look up to him in the first place. We may be sure that God, who owned our fathers, and carried them through the services of their day, will, in like manner, never leave us, while he has any work to do in us, or by us. Good work is likely to go on, when all concerned are hearty in furthering it. Let us hope in God's mercy; if we seek him, he will be found of us.

