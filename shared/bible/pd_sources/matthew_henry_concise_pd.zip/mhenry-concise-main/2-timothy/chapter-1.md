---
title: "2 Timothy 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: Paul expresses great affection for Timothy. (1–5). Exhorts him to improve his spiritual gifts. (6–14). Tells of many who basely deserted him; but speaks with affection of Onesiphorus. (15–18)."
weight: 1
---

# 2 Timothy 1 

## Chapter Outline

- Paul expresses great affection for Timothy. (1–5)
- Exhorts him to improve his spiritual gifts. (6–14)
- Tells of many who basely deserted him; but speaks with affection of Onesiphorus. (15–18)

## Verses 1–5

The promise of eternal life to believers in Christ Jesus, is the leading subject of ministers who are employed according to the will of God. The blessings here named, are the best we can ask for our beloved friends, that they may have peace with God the Father and Christ Jesus our Lord. Whatever good we do, God must have the glory. True believers have in every age the same religion as to substance. Their faith is unfeigned; it will stand the trial, and it dwells in them as a living principle. Thus pious women may take encouragement from the success of Lois and Eunice with Timothy, who proved so excellent and useful a minister. Some of the most worthy and valuable ministers the church of Christ has been favoured with, have had to bless God for early religious impressions made upon their minds by the teaching of their mothers or other female relatives.

## Verses 6–14

God has not given us the spirit of fear, but the spirit of power, of courage and resolution, to meet difficulties and dangers; the spirit of love to him, which will carry us through opposition. And the spirit of a sound mind, quietness of mind. The Holy Spirit is not the author of a timid or cowardly disposition, or of slavish fears. We are likely to bear afflictions well, when we have strength and power from God to enable us to bear them. As is usual with Paul, when he mentions Christ and his redemption, he enlarges upon them; so full was he of that which is all our salvation, and ought to be all our desire. The call of the gospel is a holy call, making holy. Salvation is of free grace. This is said to be given us before the world began, that is, in the purpose of God from all eternity; in Christ Jesus, for all the gifts that come from God to sinful man, come in and through Christ Jesus alone. And as there is so clear a prospect of eternal happiness by faith in Him, who is the Resurrection and the Life, let us give more diligence in making his salvation sure to our souls. Those who cleave to the gospel, need not be ashamed, the cause will bear them out; but those who oppose it, shall be ashamed. The apostle had trusted his life, his soul, and eternal interests, to the Lord Jesus. No one else could deliver and secure his soul through the trials of life and death. There is a day coming, when our souls will be inquired after. Thou hadst a soul committed to thee; how was it employed? in the service of sin, or in the service of Christ? The hope of the lowest real Christian rests on the same foundation as that of the great apostle. He also has learned the value and the danger of his soul; he also has believed in Christ; and the change wrought in his soul, convinces the believer that the Lord Jesus will keep him to his heavenly kingdom. Paul exhorts Timothy to hold fast the Holy Scriptures, the substance of solid gospel truth in them. It is not enough to assent to the sound words, but we must love them. The Christian doctrine is a trust committed to us; it is of unspeakable value in itself, and will be of unspeakable advantage to us. It is committed to us, to be preserved pure and entire, yet we must not think to keep it by our own strength, but by the power of the Holy Spirit dwelling in us; and it will not be gained by those who trust in their own hearts, and lean to their own understandings. (2Ti 1:15-18)

## Verses 15–18

The apostle mentions the constancy of Onesiphorus; he oft refreshed him with his letters, and counsels, and comforts, and was not ashamed of him. A good man will seek to do good. The day of death and judgment is an awful day. And if we would have mercy then, we must seek for it now of the Lord. The best we can ask, for ourselves or our friends, is, that the Lord will grant that we and they may find mercy of the Lord, when called to pass out of time into eternity, and to appear before the judgment seat of Christ.

