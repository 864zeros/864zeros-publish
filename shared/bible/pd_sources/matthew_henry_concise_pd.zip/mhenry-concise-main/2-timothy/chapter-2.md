---
title: "2 Timothy 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: The apostle exhorts Timothy to persevere with diligence, like a soldier, a combatant, and a husbandman. (1–7). Encouraging him by assurances of a happy end of his faithfulness. (8–13). Warnings to shun vain babblings and dangerous errors. (14–21). Charges to flee youthful lusts, and to minister with zeal against error, but with meekness of spirit. (22–26)."
weight: 2
---

# 2 Timothy 2 

## Chapter Outline

- The apostle exhorts Timothy to persevere with diligence, like a soldier, a combatant, and a husbandman. (1–7)
- Encouraging him by assurances of a happy end of his faithfulness. (8–13)
- Warnings to shun vain babblings and dangerous errors. (14–21)
- Charges to flee youthful lusts, and to minister with zeal against error, but with meekness of spirit. (22–26)

## Verses 1–7

As our trials increase, we need to grow stronger in that which is good; our faith stronger, our resolution stronger, our love to God and Christ stronger. This is opposed to our being strong in our own strength. All Christians, but especially ministers, must be faithful to their Captain, and resolute in his cause. The great care of a Christian must be to please Christ. We are to strive to get the mastery of our lusts and corruptions, but we cannot expect the prize unless we observe the laws. We must take care that we do good in a right manner, that our good may not be spoken evil of. Some who are active, spend their zeal about outward forms and doubtful disputations. But those who strive lawfully shall be crowned at last. If we would partake the fruits, we must labour; if we would gain the prize, we must run the race. We must do the will of God, before we receive the promises, for which reason we have need of patience. Together with our prayers for others, that the Lord would give them understanding in all things, we must exhort and stir them up to consider what they hear or read.

## Verses 8–13

Let suffering saints remember, and look to Jesus, the Author and Finisher of their faith, who for the joy that was set before him, endured the cross, despised the shame, and is now set down at the right hand of the throne of God. We must not think it strange if the best men meet with the worst treatment; but this is cheering, that the word of God is not bound. Here we see the real and true cause of the apostle's suffering trouble in, or for, the sake of the gospel. If we are dead to this world, its pleasures, profits, and honours, we shall be for ever with Christ in a better world. He is faithful to his threatenings, and faithful to his promises. This truth makes sure the unbeliever's condemnation, and the believer's salvation.

## Verses 14–21

Those disposed to strive, commonly strive about matters of small moment. But strifes of words destroy the things of God. The apostle mentions some who erred. They did not deny the resurrection, but they corrupted that true doctrine. Yet nothing can be so foolish or erroneous, but it will overturn the temporary faith of some professors. This foundation has two writings on it. One speaks our comfort. None can overthrow the faith of any whom God hath chosen. The other speaks our duty. Those who would have the comfort of the privilege, must make conscience of the duty Christ gave himself for us, that he might redeem us from all iniquity, Tit 2:14. The church of Christ is like a dwelling: some furniture is of great value; some of smaller value, and put to meaner uses. Some professors of religion are like vessels of wood and earth. When the vessels of dishonour are cast out to be destroyed, the others will be filled with all the fulness of God. We must see to it that we are holy vessels. Every one in the church whom God approves, will be devoted to his Master's service, and thus fitted for his use.

## Verses 22–26

The more we follow that which is good, the faster and the further we shall flee from that which is evil. The keeping up the communion of saints, will take us from fellowship with unfruitful works of darkness. See how often the apostle cautions against disputes in religion; which surely shows that religion consists more in believing and practising what God requires, than in subtle disputes. Those are unapt to teach, who are apt to strive, and are fierce and froward. Teaching, not persecution, is the Scripture method of dealing with those in error. The same God who gives the discovery of the truth, by his grace brings us to acknowledge it, otherwise our hearts would continue to rebel against it. There is no “peradventure,” in respect of God's pardoning those who do repent; but we cannot tell that he will give repentance to those who oppose his will. Sinners are taken in a snare, and in the worst snare, because it is the devil's; they are slaves to him. And if any long for deliverance, let them remember they never can escape, except by repentance, which is the gift of God; and we must ask it of him by earnest, persevering prayer.

