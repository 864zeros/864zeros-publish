---
title: "1 Corinthians 9 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "9"
description: "In this chapter: The apostle shows his authority, and asserts his right to be maintained. (1–14). He waved this part of his Christian liberty, for the good of others. (15–23). He did all this, with care and diligence, in view of an unfading crown. (24–27)."
weight: 9
---

# 1 Corinthians 9 

## Chapter Outline

- The apostle shows his authority, and asserts his right to be maintained. (1–14)
- He waved this part of his Christian liberty, for the good of others. (15–23)
- He did all this, with care and diligence, in view of an unfading crown. (24–27)

## Verses 1–14

It is not new for a minister to meet with unkind returns for good-will to a people, and diligent and successful services among them. To the cavils of some, the apostle answers, so as to set forth himself as an example of self-denial, for the good of others. He had a right to marry as well as other apostles, and to claim what was needful for his wife, and his children if he had any, from the churches, without labouring with his own hands to get it. Those who seek to do our souls good, should have food provided for them. But he renounced his right, rather than hinder his success by claiming it. It is the people's duty to maintain their minister. He may wave his right, as Paul did; but those transgress a precept of Christ, who deny or withhold due support.

## Verses 15–23

It is the glory of a minister to deny himself, that he may serve Christ and save souls. But when a minister gives up his right for the sake of the gospel, he does more than his charge and office demands. By preaching the gospel, freely, the apostle showed that he acted from principles of zeal and love, and thus enjoyed much comfort and hope in his soul. And though he looked on the ceremonial law as a yoke taken off by Christ, yet he submitted to it, that he might work upon the Jews, do away their prejudices, prevail with them to hear the gospel, and win them over to Christ. Though he would transgress no laws of Christ, to please any man, yet he would accommodate himself to all men, where he might do it lawfully, to gain some. Doing good was the study and business of his life; and, that he might reach this end, he did not stand on privileges. We must carefully watch against extremes, and against relying on any thing but trust in Christ alone. We must not allow errors or faults, so as to hurt others, or disgrace the gospel.

## Verses 24–27

The apostle compares himself to the racers and combatants in the Isthmian games, well known by the Corinthians. But in the Christian race all may run so as to obtain. There is the greatest encouragement, therefore, to persevere with all our strength, in this course. Those who ran in these games were kept to a spare diet. They used themselves to hardships. They practised the exercises. And those who pursue the interests of their souls, must combat hard with fleshly lusts. The body must not be suffered to rule. The apostle presses this advice on the Corinthians. He sets before himself and them the danger of yielding to fleshly desires, pampering the body, and its lusts and appetites. Holy fear of himself was needed to keep an apostle faithful: how much more is it needful for our preservation! Let us learn from hence humility and caution, and to watch against dangers which surround us while in the body.

