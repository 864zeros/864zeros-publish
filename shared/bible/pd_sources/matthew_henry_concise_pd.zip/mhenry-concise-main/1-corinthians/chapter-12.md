---
title: "1 Corinthians 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: The variety of use of spiritual gifts are shown. (1–11). In the human body every member has its place and use. (12–26). This is applied to the church of Christ. (27–30). And there is something more excellent than spiritual gifts. (31)."
weight: 12
---

# 1 Corinthians 12 

## Chapter Outline

- The variety of use of spiritual gifts are shown. (1–11)
- In the human body every member has its place and use. (12–26)
- This is applied to the church of Christ. (27–30)
- And there is something more excellent than spiritual gifts. (31)

## Verses 1–11

Spiritual gifts were extraordinary powers bestowed in the first ages, to convince unbelievers, and to spread the gospel. Gifts and graces greatly differ. Both were freely given of God. But where grace is given, it is for the salvation of those who have it. Gifts are for the advantage and salvation of others; and there may be great gifts where there is no grace. The extraordinary gifts of the Holy Spirit were chiefly exercised in the public assemblies, where the Corinthians seem to have made displays of them, wanting in the spirit of piety, and of Christian love. While heathens, they had not been influenced by the Spirit of Christ. No man can call Christ Lord, with believing dependence upon him, unless that faith is wrought by the Holy Ghost. No man could believe with his heart, or prove by a miracle, that Jesus was Christ, unless by the Holy Ghost. There are various gifts, and various offices to perform, but all proceed from one God, one Lord, one Spirit; that is, from the Father, Son, and Holy Ghost, the origin of all spiritual blessings. No man has them merely for himself. The more he profits others, the more will they turn to his own account. The gifts mentioned appear to mean exact understanding, and uttering the doctrines of the Christian religion; the knowledge of mysteries, and skill to give advice and counsel. Also the gift of healing the sick, the working of miracles, and to explain Scripture by a peculiar gift of the Spirit, and ability to speak and interpret languages. If we have any knowledge of the truth, or any power to make it known, we must give all the glory of God. The greater the gifts are, the more the possessor is exposed to temptations, and the larger is the measure of grace needed to keep him humble and spiritual; and he will meet with more painful experiences and humbling dispensations. We have little cause to glory in any gifts bestowed on us, or to despise those who have them not. (1Co 12:12-26)

## Verses 12–26

Christ and his church form one body, as Head and members. Christians become members of this body by baptism. The outward rite is of Divine institution; it is a sign of the new birth, and is called therefore the washing of regeneration, Tit 3:5. But it is by the Spirit, only by the renewing of the Holy Ghost, that we are made members of Christ's body. And by communion with Christ at the Lord's supper, we are strengthened, not by drinking the wine, but by drinking into one Spirit. Each member has its form, place, and use. The meanest makes a part of the body. There must be a distinction of members in the body. So Christ's members have different powers and different places. We should do the duties of our own place, and not murmur, or quarrel with others. All the members of the body are useful and necessary to each other. Nor is there a member of the body of Christ, but may and ought to be useful to fellow-members. As in the natural body of man, the members should be closely united by the strongest bonds of love; the good of the whole should be the object of all. All Christians are dependent one upon another; each is to expect and receive help from the rest. Let us then have more of the spirit of union in our religion.

## Verses 27–31

Contempt, hatred, envy, and strife, are very unnatural in Christians. It is like the members of the same body being without concern for one another, or quarrelling with each other. The proud, contentious spirit that prevailed, as to spiritual gifts, was thus condemned. The offices and gifts, or favours, dispensed by the Holy Spirit, are noticed. Chief ministers; persons enabled to interpret Scripture; those who laboured in word and doctrine; those who had power to heal diseases; such as helped the sick and weak; such as disposed of the money given in charity by the church, and managed the affairs of the church; and such as could speak divers languages. What holds the last and lowest rank in this list, is the power to speak languages; how vain, if a man does so merely to amuse or to exalt himself! See the distribution of these gifts, not to every one alike, verses 29, 30. This were to make the church all one, as if the body were all ear, or all eye. The Spirit distributes to every one as he will. We must be content though we are lower and less than others. We must not despise others, if we have greater gifts. How blessed the Christian church, if all the members did their duty! Instead of coveting the highest stations, or the most splendid gifts, let us leave the appointment of his instruments to God, and those in whom he works by his providence. Remember, those will not be approved hereafter who seek the chief places, but those who are most faithful to the trust placed in them, and most diligent in their Master's work.

