---
title: "1 Corinthians 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: The true character of gospel ministers. (1–6). Cautions against despising the apostle. (7–13). He claims their regard as their spiritual father in Christ, and shows his concern for them. (14–21)."
weight: 4
---

# 1 Corinthians 4 

## Chapter Outline

- The true character of gospel ministers. (1–6)
- Cautions against despising the apostle. (7–13)
- He claims their regard as their spiritual father in Christ, and shows his concern for them. (14–21)

## Verses 1–6

Apostles were no more than servants of Christ, but they were not to be undervalued. They had a great trust, and for that reason, had an honourable office. Paul had a just concern for his own reputation, but he knew that he who chiefly aimed to please men, would not prove himself a faithful servant of Christ. It is a comfort that men are not to be our final judges. And it is not judging well of ourselves, or justifying ourselves, that will prove us safe and happy. Our own judgment is not to be depended upon as to our faithfulness, any more than our own works for our justification. There is a day coming, that will bring men's secret sins into open day, and discover the secrets of their hearts. Then every slandered believer will be justified, and every faithful servant approved and rewarded. The word of God is the best rule by which to judge as to men. Pride commonly is at the bottom of quarrels. Self-conceit contributes to produce undue esteem of our teachers, as well as of ourselves. We shall not be puffed up for one against another, if we remember that all are instruments, employed by God, and endowed by him with various talents.

## Verses 7–13

We have no reason to be proud; all we have, or are, or do, that is good, is owing to the free and rich grace of God. A sinner snatched from destruction by sovereign grace alone, must be very absurd and inconsistent, if proud of the free gifts of God. St. Paul sets forth his own circumstances, verse 9 Allusion is made to the cruel spectacles in the Roman games; where men were forced to cut one another to pieces, to divert the people; and where the victor did not escape with his life, though he should destroy his adversary, but was only kept for another combat, and must be killed at last. The thought that many eyes are upon believers, when struggling with difficulties or temptations, should encourage constancy and patience. “We are weak, but ye are strong.” All Christians are not alike exposed. Some suffer greater hardships than others. The apostle enters into particulars of their sufferings. And how glorious the charity and devotion that carried them through all these hardships! They suffered in their persons and characters as the worst and vilest of men; as the very dirt of the world, that was to be swept away: nay, as the offscouring of all things, the dross of all things. And every one who would be faithful in Christ Jesus, must be prepared for poverty and contempt. Whatever the disciples of Christ suffer from men, they must follow the example, and fulfil the will and precepts of their Lord. They must be content, with him and for him, to be despised and abused. It is much better to be rejected, despised, and ill used, as St. Paul was, than to have the good opinion and favour of the world. Though cast off by the world as vile, yet we may be precious to God, gathered up with his own hand, and placed upon his throne.

## Verses 14–21

In reproving for sin, we should distinguish between sinners and their sins. Reproofs that kindly and affectionately warn, are likely to reform. Though the apostle spoke with authority as a parent, he would rather beseech them in love. And as ministers are to set an example, others must follow them, as far as they follow Christ in faith and practice. Christians may mistake and differ in their views, but Christ and Christian truth are the same yesterday, to-day, and for ever. Whenever the gospel is effectual, it comes not in word only, but also in power, by the Holy Spirit, quickening dead sinners, delivering persons from the slavery of sin and Satan, renewing them both inwardly and outwardly, and comforting, strengthening, and establishing the saints, which cannot be done by the persuasive language of men, but by the power of God. And it is a happy temper, to have the spirit of love and meekness bear the rule, yet to maintain just authority.

