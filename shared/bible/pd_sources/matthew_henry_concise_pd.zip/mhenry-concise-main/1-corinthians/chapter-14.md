---
title: "1 Corinthians 14 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "14"
description: "In this chapter: Prophecy preferred to the gift of tongues. (1–5). The unprofitableness of speaking in unknown languages. (6–14). Exhortations to worship that can be understood. (15–25). Disorders from vain display of gifts; (26–33). and from women speaking in the church. (34–40)."
weight: 14
---

# 1 Corinthians 14 

## Chapter Outline

- Prophecy preferred to the gift of tongues. (1–5)
- The unprofitableness of speaking in unknown languages. (6–14)
- Exhortations to worship that can be understood. (15–25)
- Disorders from vain display of gifts; (26–33)
- and from women speaking in the church. (34–40)

## Verses 1–5

Prophesying, that is, explaining Scripture, is compared with speaking with tongues. This drew attention, more than the plain interpretation of Scripture; it gratified pride more, but promoted the purposes of Christian charity less; it would not equally do good to the souls of men. What cannot be understood, never can edify. No advantage can be reaped from the most excellent discourses, if delivered in language such as the hearers cannot speak or understand. Every ability or possession is valuable in proportion to its usefulness. Even fervent, spiritual affection must be governed by the exercise of the understanding, else men will disgrace the truths they profess to promote.

## Verses 6–14

Even an apostle could not edify, unless he spoke so as to be understood by his hearers. To speak words that have no meaning to those who hear them, is but speaking into the air. That cannot answer the end of speaking, which has no meaning; in this case, speaker and hearers are barbarians to each other. All religious services should be so performed in Christian assemblies, that all may join in, and profit by them. Language plain and easy to be understood, is the most proper for public worship, and other religious exercises. Every true follower of Christ will rather desire to do good to others, than to get a name for learning or fine speaking.

## Verses 15–25

There can be no assent to prayers that are not understood. A truly Christian minister will seek much more to do spiritual good to men's souls, than to get the greatest applause to himself. This is proving himself the servant of Christ. Children are apt to be struck with novelty; but do not act like them. Christians should be like children, void of guile and malice; yet they should not be unskilful as to the word of righteousness, but only as to the arts of mischief. It is a proof that a people are forsaken of God, when he gives them up to the rule of those who teach them to worship in another language. They can never be benefitted by such teaching. Yet thus the preachers did who delivered their instructions in an unknown tongue. Would it not make Christianity ridiculous to a heathen, to hear the ministers pray or preach in a language which neither he nor the assembly understood? But if those who minister, plainly interpret Scripture, or preach the great truths and rules of the gospel, a heathen or unlearned person might become a convert to Christianity. His conscience might be touched, the secrets of his heart might be revealed to him, and so he might be brought to confess his guilt, and to own that God was present in the assembly. Scripture truth, plainly and duly taught, has a wonderful power to awaken the conscience and touch the heart.

## Verses 26–33

Religious exercises in public assemblies should have this view; Let all be done to edifying. As to the speaking in an unknown tongue, if another were present who could interpret, two miraculous gifts might be exercised at once, and thereby the church be edified, and the faith of the hearers confirmed at the same time. As to prophesying, two or three only should speak at one meeting, and this one after the other, not all at once. The man who is inspired by the Spirit of God will observe order and decency in delivering his revelations. God never teaches men to neglect their duties, or to act in any way unbecoming their age or station.

## Verses 34–40

When the apostle exhorts Christian women to seek information on religious subjects from their husbands at home, it shows that believing families ought to assemble for promoting spiritual knowledge. The Spirit of Christ can never contradict itself; and if their revelations are against those of the apostle, they do not come from the same Spirit. The way to keep peace, truth, and order in the church, is to seek that which is good for it, to bear with that which is not hurtful to its welfare, and to keep up good behaviour, order, and decency.

