---
title: "2 Chronicles 32 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "32"
description: "In this chapter: The invasion of Sennacherib, His defeat. (1–23). Hezekiah's sickness, His prosperous reign, and death. (24–33)."
weight: 32
---

# 2 Chronicles 32 

## Chapter Outline

- The invasion of Sennacherib, His defeat. (1–23)
- Hezekiah's sickness, His prosperous reign, and death. (24–33)

## Verses 1–23

Those who trust God with their safety, must use proper means, else they tempt him. God will provide, but so must we also. Hezekiah gathered his people together, and spake comfortably to them. A believing confidence in God, will raise us above the prevailing fear of man. Let the good subjects and soldiers of Jesus Christ, rest upon his word, and boldly say, Since God is for us, who can be against us? By the favour of God, enemies are lost, and friends gained.

## Verses 24–33

God left Hezekiah to himself, that, by this trial and his weakness in it, what was in his heart might be known; that he was not so perfect in grace as he thought he was. It is good for us to know ourselves, and our own weakness and sinfulness, that we may not be conceited, or self-confident, but may always live in dependence upon Divine grace. We know not the corruption of our own hearts, nor what we shall do if God leaves us to ourselves. His sin was, that his heart was lifted up. What need have great men, and good men, and useful men, to study their own infirmities and follies, and their obligations to free grace, that they may never think highly of themselves; but beg earnestly of God, that he will always keep them humble! Hezekiah made a bad return to God for his favours, by making even those favours the food and fuel of his pride. Let us shun the occasions of sin: let us avoid the company, the amusements, the books, yea, the very sights that may administer to sin. Let us commit ourselves continually to God's care and protection; and beg of him never to leave us nor forsake us. Blessed be God, death will soon end the believer's conflict; then pride and every sin will be abolished. He will no more be tempted to withhold the praise which belongs to the God of his salvation.

