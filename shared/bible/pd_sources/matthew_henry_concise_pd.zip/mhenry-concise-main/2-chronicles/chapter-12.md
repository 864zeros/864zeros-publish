---
title: "2 Chronicles 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: Rehoboam, forsaking the Lord, is punished. (1-16)."
weight: 12
---

# 2 Chronicles 12 

## Chapter Outline

- Rehoboam, forsaking the Lord, is punished. (1-16)

## Verses 1-16

When Rehoboam was so strong that he supposed he had nothing to fear from Jeroboam, he cast off his outward profession of godliness. It is very common, but very lamentable, that men, who in distress or danger, or near death, seem much engaged in seeking and serving God, throw aside all their religion when they have received a merciful deliverance. God quickly brought troubles upon Judah, to awaken the people to repentance, before their hearts were hardened. Thus it becomes us, when we are under the rebukes of Providence, to justify God, and to judge ourselves. If we have humbled hearts under humbling providences, the affliction has done its work; it shall be removed, or the property of it be altered. The more God's service is compared with other services, the more reasonable and easy it will appear. Are the laws of temperance thought hard? The effects of intemperance will be found much harder. The service of God is perfect liberty; the service of our lusts is complete slavery. Rehoboam was never rightly fixed in his religion. He never quite cast off God; yet he engaged not his heart to seek the Lord. See what his fault was; he did not serve the Lord, because he did not seek the Lord. He did not pray, as Solomon, for wisdom and grace; he did not consult the word of God, did not seek to that as his oracle, nor follow its directions. He made nothing of his religion, because he did not set his heart to it, nor ever came up to a steady resolution in it. He did evil, because he never was determined for good.


