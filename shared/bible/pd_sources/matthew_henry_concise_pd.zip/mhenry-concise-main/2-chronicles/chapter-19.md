---
title: "2 Chronicles 19 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "19"
description: "In this chapter: Jehoshaphat visits his kingdom. (1-11)."
weight: 19
---

# 2 Chronicles 19 

## Chapter Outline

- Jehoshaphat visits his kingdom. (1-11)

## Verses 1-11

Whenever we return in peace to our houses, we ought to acknowledge God's providence in preserving our going out and coming in. And if we have been kept through more than common dangers, we are, in a special manner, bound to be thankful. Distinguishing mercies lay us under strong obligations. The prophet tells Jehoshaphat he had done very ill in joining Ahab. He took the reproof well. See the effect the reproof had upon him. He strictly searched his own kingdom. By what the prophet said, Jehoshaphat perceived that his former attempts for reformation were well-pleasing to God; therefore he did what was then left undone. It is good when commendations quicken us to our duty. There are diversities of gifts and operations, but all from the same Spirit, and for the public good; and as every one has received the gift, so let him minister the same. Blessed be God for magistrates and ministers, scribes and statesmen, men of books, and men of business. Observe the charge the king gave. They must do all in the fear of the Lord, with a perfect, upright heart. And they must make it their constant care to prevent sin, as an offence to God, and what would bring wrath on the people.


