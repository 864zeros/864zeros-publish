---
title: "2 Chronicles 30 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "30"
description: "In this chapter: Hezekiah's passover. (1–12). The passover celebrated. (13–20). The feast of unleavened bread. (21–27)."
weight: 30
---

# 2 Chronicles 30 

## Chapter Outline

- Hezekiah's passover. (1–12)
- The passover celebrated. (13–20)
- The feast of unleavened bread. (21–27)

## Verses 1–12

Hezekiah made Israel as welcome to the passover, as any of his own subjects. Let us yield ourselves unto the Lord. Say not, you will do what you please, but resolve to do what he pleases. We perceive in the carnal mind a stiffness, an obstinacy, an unaptness to compel with God; we have it from our fathers: this must be overcome. Those who, through grace, have turned to God themselves, should do all they can to bring others to him. Numbers will be scorners, but some will be humbled and benefited; perhaps where least expected. The rich mercy of God is the great argument by which to enforce repentance; the vilest who submit and yield themselves to the Lord, seek his grace, and give themselves to his service, shall certainly be saved. Oh that messengers were sent forth to carry these glad tidings to every city and every village, through every land!

## Verses 13–20

The great thing needful in attendance upon God in solemn ordinances, is, that we make heart-work of it; all is nothing without this. Where this sincerity and fixedness of heart are, there may yet be many things short of the purification of the sanctuary. These defects need pardoning, healing grace; for omissions in duty are sins, as well as omissions of duty. If God should deal with us in strict justice, even as to the very best of our doings, we should be undone. The way to obtain pardon, is to seek it of God by prayer; it must be gotten by petition through the blood of Christ. Yet every defect is sin, and needs forgiveness; and should be matter to humble, but not to discourage us, though nothing can make up for the want of a heart prepared to seek the Lord.

## Verses 21–27

Many prayers were put up to God with the peace-offerings. In these Israel looked to God as the God of their fathers, a God in covenant with them. There was also abundance of good preaching. The Levites read and explained the Scriptures. Faith cometh by hearing, and true religion preaching has abounded. They sang psalms every day: praising God should be much of our work in religious assemblies. Having kept the seven days of the feast in this religious manner, they had so much comfort in it, that they kept other seven days also. This they did with gladness. Holy duties should be done with holy gladness. And when sinners humble themselves before the Lord, they may expect gladness in his ordinances. Those who taste this happiness will not soon grow weary of it, but will be glad to prolong their enjoyment.

