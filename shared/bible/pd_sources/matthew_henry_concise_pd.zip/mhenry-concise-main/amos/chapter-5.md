---
title: "Amos 5 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "5"
description: "In this chapter: Israel is called to seek the Lord. (1–6). Earnest exhortations to repentance. (7–17). Threatenings respecting idolatries. (18–27)."
weight: 5
---

# Amos 5 

## Chapter Outline

- Israel is called to seek the Lord. (1–6)
- Earnest exhortations to repentance. (7–17)
- Threatenings respecting idolatries. (18–27)

## Verses 1–6

The convincing, awakening word must be heard and heeded, as well as words of comfort and peace; for whether we hear or forbear, the word of God shall take effect. The Lord still proclaims mercy to men, but they often expect deliverance from such self-invented forms as make their condemnation sure. While they refuse to come to Christ and to seek mercy in and by him, that they may live, the fire of Divine wrath breaks forth upon them. Men may make an idol of the world, but will find it cannot protect.

## Verses 7–17

The same almighty power can, for repenting sinners, easily turn affliction and sorrow into prosperity and joy, and as easily turn the prosperity of daring sinners into utter darkness. Evil times will not bear plain dealing; that is, evil men will not. And these men were evil men indeed, when wise and good men thought it in vain even to speak to them. Those who will seek and love that which is good, may help to save the land from ruin. It behoves us to plead God's spiritual promises, to beseech him to create in us a clean heart, and to renew a right spirit within us. The Lord is ever ready to be gracious to the souls that seek him; and then piety and every duty will be attended to. But as for sinful Israel, God's judgments had often passed by them, now they shall pass through them.

## Verses 18–27

Woe unto those that desire the day of the Lord's judgments, that wish for times of war and confusion; as some who long for changes, hoping to rise upon the ruins of their country! but this should be so great a desolation, that nobody could gain by it. The day of the Lord will be a dark, dismal, gloomy day to all impenitent sinners. When God makes a day dark, all the world cannot make it light. Those who are not reformed by the judgments of God, will be pursued by them; if they escape one, another stands ready to seize them. A pretence of piety is double iniquity, and so it will be found. The people of Israel copied the crimes of their forefathers. The law of worshipping the Lord our God, is, Him only we must serve. Professors thrive so little, because they have little or no communion with God in their duties. They were led captive by Satan into idolatry, therefore God caused them to go into captivity among idolaters.

