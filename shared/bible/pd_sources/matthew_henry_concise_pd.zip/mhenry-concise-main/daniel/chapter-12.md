---
title: "Daniel 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: The conclusion of the vision of the Scriptures of truth. (1-4). The times of the continuance of these events. (5-13)."
weight: 12
---

# Daniel 12 

## Chapter Outline

- The conclusion of the vision of the Scriptures of truth. (1-4)
- The times of the continuance of these events. (5-13)

## Verses 1-4

Michael signifies, "Who is like God," and his name, with the title of "the great Prince," points out the Divine Saviour. Christ stood for the children of our people in their stead as a sacrifice, bore the curse for them, to bear it from them. He stands for them in pleading for them at the throne of grace. And after the destruction of antichrist, the Lord Jesus shall stand at the latter day upon the earth; and He shall appear for the complete redemption of all his people. When God works deliverance from persecution for them, it is as life from the dead. When his gospel is preached, many who sleep in the dust, both Jews and Gentiles, shall be awakened by it out of their heathenism of Judaism. And in the end the multitude that sleep in the dust shall awake; many shall arise to life, and many to shame. There is glory reserved for all the saints in the future state, for all that are wise, wise for their souls and eternity. Those who turn many to righteousness, who turn sinners from the errors of their ways, and help to save their souls from death, James 5:20, will share in the glory of those they have helped to heaven, which will add to their own glory.

## Verses 5-13

One of the angels asking how long it should be to the end of these wonders, a solemn reply is made, that it would be for a time, times, and a half, the period mentioned 25, and in the Revelation. It signifies 1260 prophetic days or years, beginning from the time when the power of the holy people should be scattered. The imposture of Mohammed, and the papal usurpation, began about the same time; and these were a twofold attack upon the church of God. But all will end well at last. All opposing rule, principality, and power, shall be put down, and holiness and love will triumph, and be in honour, to eternity. The end, this end, shall come. What an amazing prophecy is this, of so many varied events, and extending through so many successive ages, even to the general resurrection! Daniel must comfort himself with the pleasing prospect of his own happiness in death, in judgment, and to eternity. It is good for us all to think much of going away from this world. That must be our way; but it is our comfort that we shall not go till God calls us to another world, and till he has done with us in this world; till he says, Go thou thy way, thou hast done thy work, therefore now, go thy way, and leave it to others to take thy place. It was a comfort to Daniel, and is a comfort to all the saints, that whatever their lot is in the days of their lives, they shall have a happy lot in the end of the days. And it ought to be the great care and concern of every one of us to secure this. Then we may well be content with our present lot, and welcome the will of God. Believers are happy at all times; they rest in God by faith now, and a rest is reserved for them in heaven at last.


