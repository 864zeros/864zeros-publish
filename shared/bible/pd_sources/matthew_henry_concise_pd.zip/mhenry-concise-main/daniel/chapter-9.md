---
title: "Daniel 9 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "9"
description: "In this chapter: Daniel considers the time of the captivity. (1-3). His confession of sin, and prayer. (4-19). The revelation concerning the coming of the Messiah. (20-27)."
weight: 9
---

# Daniel 9 

## Chapter Outline

- Daniel considers the time of the captivity. (1-3)
- His confession of sin, and prayer. (4-19)
- The revelation concerning the coming of the Messiah. (20-27)

## Verses 1-3

Daniel learned from the books of the prophets, especially from Jeremiah, that the desolation of Jerusalem would continue seventy years, which were drawing to a close. God's promises are to encourage our prayers, not to make them needless; and when we see the performance of them approaching, we should more earnestly plead them with God.

## Verses 4-19

In every prayer we must make confession, not only of the sins we have been guilty of, but of our faith in God, and dependence upon him, our sorrow for sin, and our resolutions against it. It must be our confession, the language of our convictions. Here is Daniel's humble, serious, devout address to God; in which he gives glory to him as a God to be feared, and as a God to be trusted. We should, in prayer, look both at God's greatness and his goodness, his majesty and mercy. Here is a penitent confession of sin, the cause of the troubles the people for so many years groaned under. All who would find mercy must thus confess their sins. Here is a self-abasing acknowledgment of the righteousness of God; and it is evermore the way of true penitents thus to justify God. Afflictions are sent to bring men to turn from their sins, and to understand God's truth. Here is a believing appeal to the mercy of God. It is a comfort that God has been always ready to pardon sin. It is encouraging to recollect that mercies belong to God, as it is convincing and humbling to recollect that righteousness belongs to him. There are abundant mercies in God, not only forgiveness, but forgivenesses. Here are pleaded the reproach God's people was under, and the ruins God's sanctuary was in. Sin is a reproach to any people, especially to God's people. The desolations of the sanctuary are grief to all the saints. Here is an earnest request to God to restore the poor captive Jews to their former enjoyments. O Lord, hearken and do. Not hearken and speak only, but hearken and do; do that for us which none else can do; and defer not. Here are several pleas and arguments to enforce the petitions. Do it for the Lord Christ's sake; Christ is the Lord of all. And for his sake God causes his face to shine upon sinners when they repent, and turn to him. In all our prayers this must be our plea, we must make mention of his righteousness, even of his only. The humble, fervent, believing earnestness of this prayer should ever be followed by us.

## Verses 20-27

An answer was immediately sent to Daniel's prayer, and it is a very memorable one. We cannot now expect that God should send answers to our prayers by angels, but if we pray with fervency for that which God has promised, we may by faith take the promise as an immediate answer to the prayer; for He is faithful that has promised. Daniel had a far greater and more glorious redemption discovered to him, which God would work out for his church in the latter days. Those who would be acquainted with Christ and his grace, must be much in prayer. The evening offering was a type of the great sacrifice Christ was to offer in the evening of the world: in virtue of that sacrifice Daniel's prayer was accepted; and for the sake of that, this glorious discovery of redeeming love was made to him. We have, in verses 24-27, one of the most remarkable prophecies of Christ, of his coming and his salvation. It shows that the Jews are guilty of most obstinate unbelief, in expecting another Messiah, so long after the time expressly fixed for his coming. The seventy weeks mean a day for a year, or 490 years. About the end of this period a sacrifice would be offered, making full atonement for sin, and bringing in everlasting righteousness for the complete justification of every believer. Then the Jews, in the crucifixion of Jesus, would commit that crime by which the measure of their guilt would be filled up, and troubles would come upon their nation. All blessings bestowed on sinful man come through Christ's atoning sacrifice, who suffered once for sins, the just for the unjust, that he might bring us to God. Here is our way of access to the throne of grace, and of our entrance to heaven. This seals the sum of prophecy, and confirms the covenant with many; and while we rejoice in the blessings of salvation, we should remember what they cost the Redeemer. How can those escape who neglect so great salvation!


