---
title: "Daniel 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: Daniel's vision of the ram and the he-goat. (1-14). The interpretation of it. (15-27)."
weight: 8
---

# Daniel 8 

## Chapter Outline

- Daniel's vision of the ram and the he-goat. (1-14)
- The interpretation of it. (15-27)

## Verses 1-14

God gives Daniel a foresight of the destruction of other kingdoms, which in their day were as powerful as that of Babylon. Could we foresee the changes that shall be when we are gone, we should be less affected with changes in our own day. The ram with two horns was the second empire, that of Media and Persia. He saw this ram overcome by a he-goat. This was Alexander the Great. Alexander, when about thirty-three years of age, and in his full strength, died, and showed the vanity of worldly pomp and power, and that they cannot make a man happy. While men dispute, as in the case of Alexander, respecting the death of some prosperous warrior, it is plain that the great First Cause of all had no more of his plan for him to execute, and therefore cut him off. Instead of that one great horn, there came up four notable ones, Alexander's four chief captains. A little horn became a great persecutor of the church and people of God. It seems that the Mohammedan delusion is here pointed out. It prospered, and at one time nearly destroyed the holy religion God's right hand had planted. It is just with God to deprive those of the privileges of his house who despise and profane them; and to make those know the worth of ordinances by the want of them, who would not know it by the enjoyment of them. Daniel heard the time of this calamity limited and determined; but not the time when it should come. If we would know the mind of God, we must apply to Christ, in whom are hid all the treasures of wisdom and knowledge; not hid from us, but hid for us. There is much difficulty as to the precise time here stated, but the end of it cannot be very distant. God will, for his own glory, see to the cleansing of the church in due time. Christ died to cleanse his church; and he will so cleanse it as to present it blameless to himself.

## Verses 15-27

The eternal Son of God stood before the prophet in the appearance of a man, and directed the angel Gabriel to explain the vision. Daniel's fainting and astonishment at the prospect of evils he saw coming on his people and the church, confirm the opinion that long-continued calamities were foretold. The vision being ended, a charge was given to Daniel to keep it private for the present. He kept it to himself, and went on to do the duty of his place. As long as we live in this world we must have something to do in it; and even those whom God has most honoured, must not think themselves above their business. Nor must the pleasure of communion with God take us from the duties of our callings, but we must in them abide with God. All who are intrusted with public business must discharge their trust uprightly; and, amidst all doubts and discouragements, they may, if true believers, look forward to a happy issue. Thus should we endeavour to compose our minds for attending to the duties to which each is appointed, in the church and in the world.


