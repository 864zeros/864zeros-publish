---
title: "Daniel 11 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "11"
description: "In this chapter: The vision of the Scriptures of truth. (1-45)."
weight: 11
---

# Daniel 11 

## Chapter Outline

- The vision of the Scriptures of truth. (1-45)

## Verses 1-30

The angel shows Daniel the succession of the Persian and Grecian empires. The kings of Egypt and Syria are noticed: Judea was between their dominions, and affected by their contests. From 5-30, is generally considered to relate to the events which came to pass during the continuance of these governments; and from 21, to relate to Antiochus Epiphanes, who was a cruel and violent persecutor of the Jews. See what decaying, perishing things worldly pomp and possessions are, and the power by which they are gotten. God, in his providence, sets up one, and pulls down another, as he pleases. This world is full of wars and fightings, which come from men's lusts. All changes and revolutions of states and kingdoms, and every event, are plainly and perfectly foreseen by God. No word of God shall fall to the ground; but what he has designed, what he has declared, shall infallibly come to pass. While the potsherds of the earth strive with each other, they prevail and are prevailed against, deceive and are deceived; but those who know God will trust in him, and he will enable them to stand their ground, bear their cross, and maintain their conflict.

## Verses 31-45

The remainder of this prophecy is very difficult, and commentators differ much respecting it. From Antiochus the account seems to pass to antichrist. Reference seems to be made to the Roman empire, the fourth monarchy, in its pagan, early Christian, and papal states. The end of the Lord's anger against his people approaches, as well as the end of his patience towards his enemies. If we would escape the ruin of the infidel, the idolater, the superstitious and cruel persecutor, as well as that of the profane, let us make the oracles of God our standard of truth and of duty, the foundation of our hope, and the light of our paths through this dark world, to the glorious inheritance above.


