---
title: "Daniel 1 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "1"
description: "In this chapter: The captivity of Daniel and his companions. (1-7). Their refusal to eat the king's meat. (8-16). Their improvement in wisdom. (17-21)."
weight: 1
---

# Daniel 1 

## Chapter Outline

- The captivity of Daniel and his companions. (1-7)
- Their refusal to eat the king's meat. (8-16)
- Their improvement in wisdom. (17-21)

## Verses 1-7

Nebuchadnezzar, king of Babylon, in the first year of his reign, took Jerusalem, and carried whom and what he pleased away. From this first captivity, most think the seventy years are to be dated. It is the interest of princes to employ wise men; and it is their wisdom to find out and train up such. Nebuchadnezzar ordered that these chosen youths should be taught. All their Hebrew names had something of God in them; but to make them forget the God of their fathers, the Guide of their youth, the heathen gave them names that savoured of idolatry. It is painful to reflect how often public education tends to corrupt the principles and morals.

## Verses 8-16

The interest we think we make for ourselves, we must acknowledge to be God's gift. Daniel was still firm to his religion. Whatever they called him, he still held fast the spirit of an Israelite. These youths scrupled concerning the meat, lest it should be sinful. When God's people are in Babylon they need take special care that they partake not of her sins. It is much to the praise of young people, not to covet or seek the delights of sense. Those who would excel in wisdom and piety, must learn betimes to keep the body under. Daniel avoided defiling himself with sin; and we should more fear that than any outward trouble. It is easier to keep temptation at a distance, than to resist it when near. And we cannot better improve our interest in any with whom we have found favour, than to use it to keep us from sin. People will not believe the benefit of avoiding excess, and of a spare diet, nor how much they contribute to the health of the body, unless they try. Conscientious temperance will always do more, even for the comfort of this life, than sinful indulgence.

## Verses 17-21

Daniel and his fellows kept to their religion; and God rewarded them with eminence in learning. Pious young persons should endeavour to do better than their fellows in useful things; not for the praise of man, but for the honour of the gospel, and that they may be qualified for usefulness. And it is well for a country, and for the honour of a prince, when he is able to judge who are best fitted to serve him, and prefers them on that account. Let young men steadily attend to this chapter; and let all remember that God will honour those who honour him, but those who despise him shall be lightly esteemed.


