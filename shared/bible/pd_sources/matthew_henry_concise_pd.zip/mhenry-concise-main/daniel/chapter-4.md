---
title: "Daniel 4 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "4"
description: "In this chapter: Nebuchadnezzar acknowledges the power of Jehovah. (1-18). Daniel interprets his dream. (19-27). The fulfilment of it. (28-37)."
weight: 4
---

# Daniel 4 

## Chapter Outline

- Nebuchadnezzar acknowledges the power of Jehovah. (1-18)
- Daniel interprets his dream. (19-27)
- The fulfilment of it. (28-37)

## Verses 1-18

The beginning and end of this chapter lead us to hope, that Nebuchadnezzar was a monument of the power of Divine grace, and of the riches of Divine mercy. After he was recovered from his madness, he told to distant places, and wrote down for future ages, how God had justly humbled and graciously restored him. When a sinner comes to himself, he will promote the welfare of others, by making known the wondrous mercy of God. Nebuchadnezzar, before he related the Divine judgments upon him for his pride, told the warnings he had in a dream or vision. The meaning was explained to him. The person signified, was to be put down from honour, and to be deprived of the use of his reason seven years. This is surely the sorest of all temporal judgments. Whatever outward affliction God is pleased to lay upon us, we have cause to bear it patiently, and to be thankful that he continues the use of our reason, and the peace of our consciences. Yet if the Lord should see fit by such means to keep a sinner from multiplying crimes, or a believer from dishonouring his name, even the dreadful prevention would be far preferable to the evil conduct. God has determined it, as a righteous Judge, and the angels in heaven applaud. Not that the great God needs the counsel or concurrence of the angels, but it denotes the solemnity of this sentence. The demand is by the word of the holy ones, God's suffering people: when the oppressed cry to God, he will hear. Let us diligently seek blessings which can never be taken from us, and especially beware of pride and forgetfulness of God.

## Verses 19-27

Daniel was struck with amazement and terror at so heavy a judgment coming upon so great a prince, and gives advice with tenderness and respect. It is necessary, in repentance, that we not only cease to do evil, but learn to do good. Though it might not wholly prevent the judgment, yet the trouble may be longer before it comes, or shorter when it does come. And everlasting misery will be escaped by all who repent and turn to God.

## Verses 28-37

Pride and self-conceit are sins that beset great men. They are apt to take that glory to themselves which is due to God only. While the proud word was in the king's mouth, the powerful word came from God. His understanding and his memory were gone, and all the powers of the rational soul were broken. How careful we ought to be, not to do any thing which may provoke God to put us out of our senses! God resists the proud. Nebuchadnezzar would be more than a man, but God justly makes him less than a man. We may learn to believe concerning God, that the most high God lives for ever, and that his kingdom is like himself, everlasting, and universal. His power cannot be resisted. When men are brought to honour God, by confession of sin and acknowledging his sovereignty, then, and not till then, they may expect that God will honour them; not only restore them to the dignity they lost by the sin of the first Adam, but add excellent majesty to them, from the righteousness and grace of the Second Adam. Afflictions shall last no longer than till they have done the work for which they were sent. There can be no reasonable doubt that Nebuchadnezzar was a true penitent, and an accepted believer. It is thought that he did not live more than a year after his restoration. Thus the Lord knows how to abase those that walk in pride, but gives grace and consolation to the humble, broken-hearted sinner who calls upon Him.


