---
title: "Daniel 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: Daniel's vision near the river Hiddekel. (1-9). He is to expect a discovery of future events. (10-21)."
weight: 10
---

# Daniel 10 

## Chapter Outline

- Daniel's vision near the river Hiddekel. (1-9)
- He is to expect a discovery of future events. (10-21)

## Verses 1-9 

This chapter relates the beginning of Daniel's last vision, which is continued to the end of the book. The time would be long before all would be accomplished; and much of it is not yet fulfilled. Christ appeared to Daniel in a glorious form, and it should engage us to think highly and honourably of him. Let us admire his condescension for us and our salvation. There remained no strength in Daniel. The greatest and best of men cannot bear the full discoveries of the Divine glory; for no man can see it, and live; but glorified saints see Christ as he is, and can bear the sight. How dreadful soever Christ may appear to those under convictions of sin, there is enough in his word to quiet their spirits.

## Verses 10-21

Whenever we enter into communion with God, it becomes us to have a due sense of the infinite distance between us and the holy God. How shall we, that are dust and ashes, speak to the Lord of glory? Nothing is more likely, nothing more effectual to revive the drooping spirits of the saints, than to be assured of God's love to them. From the very first day we begin to look toward God in a way of duty, he is ready to meet us in the way of mercy. Thus ready is God to hear prayer. When the angel had told the prophet of the things to come, he was to return, and oppose the decrees of the Persian kings against the Jews. The angels are employed as God's ministering servants, Heb. 1:14. Though much was done against the Jews by the kings of Persia, God permitting it, much more mischief would have been done if God had not prevented it. He would now more fully show what were God's purposes, of which the prophecies form an outline; and we are concerned to study what is written in these Scriptures of truth, for they belong to our everlasting peace. While Satan and his angels, and evil counsellors, excite princes to mischief against the church, we may rejoice that Christ our Prince, and all his mighty angels, act against our enemies; but we ought not to expect many to favour us in this evil world. Yet the whole counsel of God shall be established; and let each one pray, Lord Jesus, be our righteousness now, and thou wilt be our everlasting confidence, through life, in death, at the day of judgment, and for evermore.


