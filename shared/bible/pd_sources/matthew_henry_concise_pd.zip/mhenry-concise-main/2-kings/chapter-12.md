---
title: "2 Kings 12 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "12"
description: "In this chapter: Jehoash orders the repair of the temple. (1–16). He is slain by his servants. (17–21)."
weight: 12
---

# 2 Kings 12 

## Chapter Outline

- Jehoash orders the repair of the temple. (1–16)
- He is slain by his servants. (17–21)

## Verses 1–16

It is a great mercy to young people, especially to all young men of rank, like Jehoash, to have those about them who will instruct them to do what is right in the sight of the Lord; and they do wisely and well for themselves, when willing to be counselled and ruled. The temple was out of repair; Jehoash orders the repair of the temple. The king was zealous. God requires those who have power, to use it for the support of religion, the redress of grievances, and repairing of decays. The king employed the priests to manage, as most likely to be hearty in the work. But nothing was done effectually till the twenty-third year of his reign. Another method was therefore taken. When public distributions are made faithfully, public contributions will be made cheerfully. While they were getting all they could for the repair of the temple, they did not break in upon the stated maintenance of the priests. Let not the servants of the temple be starved, under colour of repairing the breaches of it. Those that were intrusted did the business carefully and faithfully. They did not lay it out in ornaments for the temple, till the other work was completed; hence we may learn, in all our expenses, to prefer that which is most needful, and, in dealing for the public, to deal as we would for ourselves.

## Verses 17–21

Let us review the character of Jehoash, and consider what we may learn from it. When we see what a sad conclusion there was to so promising a beginning, it ought to make us seek into our spiritual declinings. If we know any thing of Christ as the foundation of our faith and hope, let us desire to know nothing but Christ. May the work of the blessed Spirit on our souls be manifest; may we see, feel, and be earnest, in seeking after Jesus in all his fulness, suitableness, and grace, that our souls may be brought over from dead works to serve the living and true God.

