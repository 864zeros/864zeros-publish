---
title: "2 Kings 20 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "20"
description: "In this chapter: Hezekiah's sickness, His recovery in answer to prayer. (1–11). Hezekiah shows his treasures to the ambassadors from Babylon, His death. (12–21)."
weight: 20
---

# 2 Kings 20 

## Chapter Outline

- Hezekiah's sickness, His recovery in answer to prayer. (1–11)
- Hezekiah shows his treasures to the ambassadors from Babylon, His death. (12–21)

## Verses 1–11

Hezekiah was sick unto death, in the same year in which the king of Assyria besieged Jerusalem. A warning to prepare for death was brought to Hezekiah by Isaiah. Prayer is one of the best preparations for death, because by it we fetch in strength and grace from God, to enable us to finish well. He wept sorely: some gather from hence that he was unwilling to die; it is in the nature of man to dread the separation of soul and body. There was also something peculiar in Hezekiah's case; he was now in the midst of his usefulness. Let Hezekiah's prayer, see Isa 38. interpret his tears; in that is nothing which is like his having been under that fear of death, which has bondage or torment. Hezekiah's piety made his sick-bed easy. “O Lord, remember now;” he does not speak as if God needed to be put in mind of any thing by us; nor, as if the reward might be demanded as due; it is Christ's righteousness only that is the purchase of mercy and grace. Hezekiah does not pray, Lord, spare me; but, Lord, remember me; whether I live or die, let me be thine. God always hears the prayers of the broken in heart, and will give health, length of days, and temporal deliverances, as much and as long as is truly good for them. Means were to be used for Hezekiah's recovery; yet, considering to what a height the disease was come, and how suddenly it was checked, the cure was miraculous. It is our duty, when sick, to use such means as are proper to help nature, else we do not trust God, but tempt him. For the confirmation of his faith, the shadow of the sun was carried back, and the light was continued longer than usual, in a miraculous manner. This work of wonder shows the power of God in heaven as well as on earth, the great notice he takes of prayer, and the great favour he bears to his chosen.

## Verses 12–21

The king of Babylon was at this time independent of the king of Assyria, though shortly after subdued by him. Hezekiah showed his treasures and armour, and other proofs of his wealth and power. This was the effect of pride and ostentation, and departing from simple reliance on God. He also seems to have missed the opportunity of speaking to the Chaldeans, about Him who had wrought the miracles which excited their attention, and of pointing out to them the absurdity and evil of idolatry. What is more common than to show our friends our houses and possessions? But if we do this in the pride of ours hearts, to gain applause from men, not giving praise to God, it becomes sin in us, as it did in Hezekiah. We may expect vexation from every object with which we are unduly pleased. Isaiah, who had often been Hezekiah's comforter, is now is reprover. The blessed Spirit is both, Joh 16:7, 8. Ministers must be both, as there is occasion. Hezekiah allowed the justice of the sentence, and God's goodness in the respite. Yet the prospect respecting his family and nation must have given him many painful feelings. Hezekiah was indeed humbled for the pride of his heart. And blessed are the dead who die in the Lord; for they rest from their labours, and their works do follow them.

