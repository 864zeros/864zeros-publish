---
title: "2 Kings 13 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "13"
description: "In this chapter: Reign of Jehoahaz. (1–9). Jehoash, king of Israel, Elisha dying. (10–19). Elisha's death, The victories of Jehoash. (20–25)."
weight: 13
---

# 2 Kings 13 

## Chapter Outline

- Reign of Jehoahaz. (1–9)
- Jehoash, king of Israel, Elisha dying. (10–19)
- Elisha's death, The victories of Jehoash. (20–25)

## Verses 1–9

It was the ancient honour of Israel that they were a praying people. Jehoahaz, their king, in his distress, besought the Lord; applied himself for help, but not to the calves; what help could they give him? He sought the Lord. See how swift God is to show mercy; how ready to hear prayer; how willing to find a reason to be gracious; else he would not look so far back as the ancient covenant Israel had so often broken, and forfeited. Let this invite and engage us for ever to him; and encourage even those who have forsaken him, to return and repent; for there is forgiveness with him, that he may be feared. And if the Lord answer the mere cry of distress for temporal relief, much more will he regard the prayer of faith for spiritual blessings.

## Verses 10–19

Jehoash, the king, came to Elisha, to receive his dying counsel and blessing. It may turn much to our spiritual advantage, to attend the sick-beds and death-beds of good men, that we may be encouraged in religion by the living comforts they have from it in a dying hour. Elisha assured the king of his success; yet he must look up to God for direction and strength; must reckon his own hands not enough, but go on, in dependence upon Divine aid. The trembling hands of the dying prophet, as they signified the power of God, gave this arrow more force than the hands of the king in his full strength. By contemning the sign, the king lost the thing signified, to the grief of the dying prophet. It is a trouble to good men, to see those to whom they wish well, forsake their own mercies, and to see them lose advantages against spiritual enemies.

## Verses 20–25

God has many ways to chastise a provoking people. Trouble comes sometimes from that point whence we least feared it. The mention of this invasion on the death of Elisha, shows that the removal of God's faithful prophets is a presage of coming judgments. His dead body was a means of giving life to another dead body. This miracle was a confirmation of his prophecies. And it may have reference to Christ, by whose death and burial, the grave is made a safe and happy passage to life to all believers. Jehoash was successful against the Syrians, just as often as he had struck the ground with the arrows, then a stop was put to his victories. Many have repented, when too late, of distrusts and the straitness of their desires.

