---
title: "2 Kings 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: Elijah divides Jordan. (1–8). Elijah is taken up into heaven. (9–12). Elisha is manifested to be Elijah's successor. (13–18). Elisha heals the waters of Jericho, Those that mocked Elisha destroyed. (19–25)."
weight: 2
---

# 2 Kings 2 

## Chapter Outline

- Elijah divides Jordan. (1–8)
- Elijah is taken up into heaven. (9–12)
- Elisha is manifested to be Elijah's successor. (13–18)
- Elisha heals the waters of Jericho, Those that mocked Elisha destroyed. (19–25)

## Verses 1–8

The Lord had let Elijah know that his time was at hand. He therefore went to the different schools of the prophets to give them his last exhortations and blessing. The removal of Elijah was a type and figure of the ascension of Christ, and the opening of the kingdom of heaven to all believers. Elisha had long followed Elijah, and he would not leave him now when he hoped for the parting blessing. Let not those who follow Christ come short by tiring at last. The waters of Jordan, of old, yielded to the ark; now, to the prophet's mantle, as a token of God's presence. When God will take up his faithful ones to heaven, death is the Jordan which they must pass through, and they find a way through it. The death of Christ has divided those waters, that the ransomed of the Lord may pass over. O death, where is thy sting, thy hurt, thy terror!

## Verses 9–12

That fulness, from whence prophets and apostles had all their supply, still exists as of old, and we are told to ask large supplies from it. Diligent attendance upon Elijah, particularly in his last hours, would be proper means for Elisha to obtain much of his spirit. The comforts of departing saints, and their experiences, help both to gild our comforts and to strengthen our resolutions. Elijah is carried to heaven in a fiery chariot. Many questions might be asked about this, which could not be answered. Let it suffice that we are told, what his Lord, when he came, found him doing. He was engaged in serious discourse, encouraging and directing Elisha about the kingdom of God among men. We mistake, if we think preparation for heaven is carried on only by contemplation and acts of devotion. The chariot and horses appeared like fire, something very glorious, not for burning, but brightness. By the manner in which Elijah and Enoch were taken from this world, God gave a glimpse of the eternal life brought to light by the gospel, of the glory reserved for the bodies of the saints, and of the opening of the kingdom of heaven to all believers. It was also a figure of Christ's ascension. Though Elijah was gone triumphantly to heaven, yet this world could ill spare him. Surely their hearts are hard, who feel not, when God, by taking away faithful, useful men, calls for weeping and mourning. Elijah was to Israel, by his counsels, reproofs, and prayers, better than the strongest force of chariot and horse, and kept off the judgments of God. Christ bequeathed to his disciples his precious gospel, like Elijah's mantle; the token of the Divine power being exerted to overturn the empire of Satan, and to set up the kingdom of God in the world. The same gospel remains with us, though the miraculous powers are withdrawn, and it has Divine strength for the conversion and salvation of sinners.

## Verses 13–18

Elijah left his mantle to Elisha; as a token of the descent of the Spirit upon him; it was more than if he had left him thousands of gold and silver. Elisha took it up, not as a sacred relic to be worshipped, but as a significant garment to be worn. Now that Elijah was taken to heaven, Elisha inquired, 1. After God; when our creature-comforts are removed, we have a God to go to, who lives for ever. 2. After the God that Elijah served, and honoured, and pleaded for. The Lord God of the holy prophets is the same yesterday, to-day, and for ever; but what will it avail us to have the mantles of those that are gone, their places, their books, if we have not their spirit, their God? See Elisha's dividing the river; God's people need not fear at last passing through the Jordan of death as on dry ground. The sons of the prophets made a needless search for Elijah. Wise men may yield to that, for the sake of peace, and the good opinion of others, which yet their judgment is against, as needless and fruitless. Traversing hills and valleys will never bring us to Elijah, but following the example of his holy faith and zeal will, in due time.

## Verses 19–25

Observe the miracle of healing the waters. Prophets should make every place to which they come better for them, endeavouring to sweeten bitter spirits, and to make barren souls fruitful, by the word of God, which is like the salt cast into the water by Elisha. It was an apt emblem of the effect produced by the grace of God on the sinful heart of man. Whole families, towns, and cities, sometimes have a new appearance through the preaching of the gospel; wickedness and evil have been changed into fruitfulness in the works of righteousness, which are, through Christ, to the praise and glory of God. Here is a curse on the youths of Bethel, enough to destroy them; it was not a curse causeless, for it was Elisha's character, as God's prophet, that they abused. They bade him “go up,” reflecting on the taking up of Elijah into heaven. The prophet acted by Divine impulse. If the Holy Spirit had not directed Elisha's solemn curse, the providence of God would not have followed it with judgment. The Lord must be glorified as a righteous God who hates sin, and will reckon for it. Let young persons be afraid of speaking wicked words, for God notices what they say. Let them not mock at any for defects in mind or body; especially it is at their peril, if they scoff at any for well doing. Let parents that would have comfort in their children, train them up well, and do their utmost betimes to drive out the foolishness that is bound up in their hearts. And what will be the anguish of those parents, at the day of judgment, who witness the everlasting condemnation of their offspring, occasioned by their own bad example, carelessness, or wicked teaching!

