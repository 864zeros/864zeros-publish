---
title: "2 Kings 8 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "8"
description: "In this chapter: A famine in Israel, The Shunammite obtains her land. (1–6). Elisha consulted by Hazael, Death of Benhadad. (7–15). Jehoram's wicked reign in Judah. (16–24). Ahaziah's wicked reign in Judah. (25–29)."
weight: 8
---

# 2 Kings 8 

## Chapter Outline

- A famine in Israel, The Shunammite obtains her land. (1–6)
- Elisha consulted by Hazael, Death of Benhadad. (7–15)
- Jehoram's wicked reign in Judah. (16–24)
- Ahaziah's wicked reign in Judah. (25–29)

## Verses 1–6

The kindness of the good Shunammite to Elisha, was rewarded by the care taken of her in famine. It is well to foresee an evil, and wisdom, when we foresee it, to hide ourselves if we lawfully may do so. When the famine was over, she returned out of the land of the Philistines; that was no proper place for an Israelite, any longer than there was necessity for it. Time was when she dwelt so securely among her own people, that she had no occasion to be spoken for to the king; but there is much uncertainty in this life, so that things or persons may fail us which we most depend upon, and those befriend us which we think we shall never need. Sometimes events, small in themselves, prove of consequence, as here; for they made the king ready to believe Gehazi's narrative, when thus confirmed. It made him ready to grant her request, and to support a life which was given once and again by miracle.

## Verses 7–15

Among other changes of men's minds by affliction, it often gives other thoughts of God's ministers, and teaches to value the counsels and prayers of those whom they have hated and despised. It was not in Hazael's countenance that Elisha read what he would do, but God revealed it to him, and it fetched tears from his eyes: the more foresight men have, the more grief they are liable to. It is possible for a man, under the convictions and restraints of natural conscience, to express great abhorrence of a sin, yet afterwards to be reconciled to it. Those that are little and low in the world, cannot imagine how strong the temptations of power and prosperity are, which, if ever they arrive at, they will find how deceitful their hearts are, how much worse than they suspected. The devil ruins men, by saying they shall certainly recover and do well, so rocking them asleep in security. Hazael's false account was an injury to the king, who lost the benefit of the prophet's warning to prepare for death, and an injury to Elisha, who would be counted a false prophet. It is not certain that Hazael murdered his master, or if he caused his death it may have been without any design. But he was a dissembler, and afterwards proved a persecutor to Israel.

## Verses 16–24

A general idea is given of Jehoram's badness. His father, no doubt, had him taught the true knowledge of the Lord, but did ill to marry him to the daughter of Ahab; no good could come of union with an idolatrous family.

## Verses 25–29

Names do not make natures, but it was bad for Jehoshaphat's family to borrow names from Ahab's. Ahaziah's relation to Ahab's family was the occasion of his wickedness and of his fall. When men choose wives for themselves, let them remember they are choosing mothers for their children. Providence so ordered it, that Ahaziah might be cut off with the house of Ahab, when the measure of their iniquity was full. Those who partake with sinners in their sin, must expect to partake with them in their plagues. May all the changes, troubles, and wickedness of the world, make us more earnest to obtain an interest in the salvation of Christ.

