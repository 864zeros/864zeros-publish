---
title: "2 Kings 22 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "22"
description: "In this chapter: Josiah's good reign, His care for repairing the temple, The book of the law found. (1–10). Josiah consults Huldah the prophetess. (11–20)."
weight: 22
---

# 2 Kings 22 

## Chapter Outline

- Josiah's good reign, His care for repairing the temple, The book of the law found. (1–10)
- Josiah consults Huldah the prophetess. (11–20)

## Verses 1–10

The different event of Josiah's early succession from that of Manasseh, must be ascribed to the distinguishing grace of God; yet probably the persons that trained him up were instruments in producing this difference. His character was most excellent. Had the people joined in the reformation as heartily as he persevered in it, blessed effects would have followed. But they were wicked, and had become fools in idolatry. We do not obtain full knowledge of the state of Judah from the historical records, unless we refer to the writings of the prophets who lived at the time. In repairing the temple, the book of the law was found, and brought to the king. It seems, this book of the law was lost and missing; carelessly mislaid and neglected, as some throw their Bibles into corners, or maliciously concealed by some of the idolaters. God's care of the Bible plainly shows his interest in it. Whether this was the only copy in being or not, the things contained in it were new, both to the king and to the high priest. No summaries, extracts, or collections out of the Bible, can convey and preserve the knowledge of God and his will, like the Bible itself. It was no marvel that the people were so corrupt, when the book of the law was so scarce; they that corrupted them, no doubt, used arts to get that book out of their hands. The abundance of Bibles we possess aggravates our national sins; for what greater contempt of God can we show, than to refuse to read his word when put into our hands, or, reading it, not to believe and obey it? By the holy law is the knowledge of sin, and by the blessed gospel is the knowledge of salvation. When the former is understood in its strictness and excellence, the sinner begins to inquire, What must I do to be saved? And the ministers of the gospel point out to him Jesus Christ, as the end of the law for righteousness to every one that believeth.

## Verses 11–20

The book of the law is read before the king. Those best honour their Bibles, who study them; daily feed on that bread, and walk by that light. Convictions of sin and wrath should put us upon this inquiry, What shall we do to be saved? Also, what we may expect, and must provide for. Those who are truly apprehensive of the weight of God's wrath, cannot but be very anxious how they may be saved. Huldah let Josiah know what judgments God had in store for Judah and Jerusalem. The generality of the people were hardened, and their hearts unhumbled, but Josiah's heart was tender. This is tenderness of heart, and thus he humbled himself before the Lord. Those who most fear God's wrath, are least likely to feel it. Though Josiah was mortally wounded in battle, yet he died in peace with God, and went to glory. Whatever such persons suffer or witness, they are gathered to the grave in peace, and shall enter into the rest which remaineth for the people of God.

