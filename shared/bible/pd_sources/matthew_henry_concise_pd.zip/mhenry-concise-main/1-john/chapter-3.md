---
title: "1 John 3 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "3"
description: "In this chapter: The apostle admires the love of God in making believers his children. (1, 2). The purifying influence of the hope of seeing Christ, and the danger of pretending to this, and living in sin. (3–10). Love to the brethren is the character of real Christians. (11–15). That love described by its actings. (16–21). The advantage of faith, love, and obedience. (22–24)."
weight: 3
---

# 1 John 3 

## Chapter Outline

- The apostle admires the love of God in making believers his children. (1, 2)
- The purifying influence of the hope of seeing Christ, and the danger of pretending to this, and living in sin. (3–10)
- Love to the brethren is the character of real Christians. (11–15)
- That love described by its actings. (16–21)
- The advantage of faith, love, and obedience. (22–24)

## Verses 1, 2

Little does the world know of the happiness of the real followers of Christ. Little does the world think that these poor, humble, despised ones, are favourites of God, and will dwell in heaven. Let the followers of Christ be content with hard fare here, since they are in a land of strangers, where their Lord was so badly treated before them. The sons of God must walk by faith, and live by hope. They may well wait in faith, hope, and earnest desire, for the revelation of the Lord Jesus. The sons of God will be known, and be made manifest by likeness to their Head. They shall be transformed into the same image, by their view of him.

## Verses 3–10

The sons of God know that their Lord is of purer eyes than to allow any thing unholy and impure to dwell with him. It is the hope of hypocrites, not of the sons of God, that makes allowance for gratifying impure desires and lusts. May we be followers of him as his dear children, thus show our sense of his unspeakable mercy, and express that obedient, grateful, humble mind which becomes us. Sin is the rejecting the Divine law. In him, that is, in Christ, was no sin. All the sinless weaknesses that were consequences of the fall, he took; that is, all those infirmities of mind or body which subject man to suffering, and expose him to temptation. But our moral infirmities, our proneness to sin, he had not. He that abides in Christ, continues not in the practice of sin. Renouncing sin is the great proof of spiritual union with, continuance in, and saving knowledge of the Lord Christ. Beware of self-deceit. He that doeth righteousness is righteous, and to be a follower of Christ, shows an interest by faith in his obedience and sufferings. But a man cannot act like the devil, and at the same time be a disciple of Christ Jesus. Let us not serve or indulge what the Son of God came to destroy. To be born of God is to be inwardly renewed by the power of the Spirit of God. Renewing grace is an abiding principle. Religion is not an art, a matter of dexterity and skill, but a new nature. And the regenerate person cannot sin as he did before he was born of God, and as others do who are not born again. There is that light in his mind, which shows him the evil and malignity of sin. There is that bias upon his heart, which disposes him to loathe and hate sin. There is the spiritual principle that opposes sinful acts. And there is repentance for sin, if committed. It goes against him to sin with forethought. The children of God and the children of the devil have their distinct characters. The seed of the serpent are known by neglect of religion, and by their hating real Christians. He only is righteous before God, as a justified believer, who is taught and disposed to righteousness by the Holy Spirit. In this the children of God are manifest, and the children of the devil. May all professors of the gospel lay these truths to heart, and try themselves by them.

## Verses 11–15

We should love the Lord Jesus, value his love, and therefore love all our brethren in Christ. This love is the special fruit of our faith, and a certain sign of our being born again. But none who rightly know the heart of man, can wonder at the contempt and enmity of ungodly people against the children of God. We know that we are passed from death to life: we may know it by the evidences of our faith in Christ, of which love to our brethren is one. It is not zeal for a party in the common religion, or affection for those who are of the same name and sentiments with ourselves. The life of grace in the heart of a regenerate person, is the beginning and first principle of a life of glory, whereof they must be destitute who hate their brother in their hearts.

## Verses 16–21

Here is the condescension, the miracle, the mystery of Divine love, that God would redeem the church with his own blood. Surely we should love those whom God has loved, and so loved. The Holy Spirit, grieved at selfishness, will leave the selfish heart without comfort, and full of darkness and terror. By what can it be known that a man has a true sense of the love of Christ for perishing sinners, or that the love of God has been planted in his heart by the Holy Spirit, if the love of the world and its good overcomes the feelings of compassion to a perishing brother? Every instance of this selfishness must weaken the evidences of a man's conversion; when habitual and allowed, it must decide against him. If conscience condemn us in known sin, or the neglect of known duty, God does so too. Let conscience therefore be well-informed, be heard, and diligently attended to.

## Verses 22–24

When believers had confidence towards God, through the Spirit of adoption, and by faith in the great High Priest, they might ask what they would of their reconciled Father. They would receive it, if good for them. And as good-will to men was proclaimed from heaven, so good-will to men, particularly to the brethren, must be in the hearts of those who go to God and heaven. He who thus follows Christ, dwells in Him as his ark, refuge, and rest, and in the Father through him. This union between Christ and the souls of believers, is by the Spirit he has given them. A man may believe that God is gracious before he knows it; yet when faith has laid hold on the promises, it sets reason to work. This Spirit of God works a change; in all true Christians it changes from the power of Satan to the power of God. Consider, believer, how it changes thy heart. Dost not thou long for peace with God? Wouldst thou not forego all the world for it? No profit, pleasure, or preferment shall hinder thee from following Christ. This salvation is built upon Divine testimony, even the Spirit of God.

