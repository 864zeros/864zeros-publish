---
title: "1 Kings 2 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "2"
description: "In this chapter: David's dying charge to Solomon. (1–4). David's charge as to Joab and others. (5–11). Solomon reigns, Adonijah aspiring to the throne is put to death. (12–25). Abiathar banished, Joab put to death. (26–34). Shimei is put to death. (35–46)."
weight: 2
---

# 1 Kings 2 

## Chapter Outline

- David's dying charge to Solomon. (1–4)
- David's charge as to Joab and others. (5–11)
- Solomon reigns, Adonijah aspiring to the throne is put to death. (12–25)
- Abiathar banished, Joab put to death. (26–34)
- Shimei is put to death. (35–46)

## Verses 1–4

David's charge to Solomon is, to keep the charge of the Lord. The authority of a dying father is much, but nothing to that of a living God. God promised David that the Messiah should come from his descendants, and that promise was absolute; but the promise, that there should not fail of them a man on the throne of Israel, was conditional; if he walks before God in sincerity, with zeal and resolution: in order hereunto, he must take heed to his way. (1Ki 2:5-11)

## Verses 5–11

These dying counsels concerning Joab and Shimei, did not come from personal anger, but for the security of Solomon's throne, which was the murders he had committed, but would readily repeat them to carry any purpose; though long reprieved, he shall be reckoned with at last. Time does not wear out the guilt of any sin, particularly of murder. Concerning Shimei, Hold him not guiltless; do not think him any true friend to thee, or thy government, or fit to be trusted; he has no less malice now than he had then. David's dying sentiments are recorded, as delivered under the influence of the Holy Ghost, 2Sa 23:1–7. The Lord discovered to him the offices and the salvation of that glorious personage, the Messiah, whose coming he then foretold, and from whom he derived all his comforts and expectations. That passage gives a decided proof that David died under the influence of the Holy Ghost, in the exercise of faith and hope.

## Verses 12–25

Solomon received Bathsheba with all the respect that was owing to a mother; but let none be asked for that which they ought not to grant. It ill becomes a good man to prefer a bad request, or to appear in a bad cause. According to eastern customs it was plain that Adonijah sought to be king, by his asking for Abishag as his wife, and Solomon could not be safe while he lived. Ambitious, turbulent spirits commonly prepare death for themselves. Many a head has been lost by catching at a crown.

## Verses 26–34

Solomon's words to Abiathar, and his silence, imply that some recent conspiracies had been entered into. Those that show kindness to God's people shall have it remembered to their advantage. For this reason Solomon spares Abiathar's life, but dismisses him from his offices. In case of such sins as the blood of beasts would atone for, the altar was a refuge, but not in Joab's case. Solomon looks upward to God as the Author of peace, and forward to eternity as the perfection of it. The Lord of peace himself gives us that peace which is everlasting.

## Verses 35–46

The old malignity remains in the unconverted heart, and a watchful eye should be kept on those who, like Shimei, have manifested their enmity, but have given no evidence of repentance. No engagements or dangers will restrain worldly men; they go on, though they forfeit their lives and souls. Let us remember, God will not accommodate his judgment to us. His eye is over us; and let us strive to walk as in his presence. Let our every act, word, and thought, be governed by this great truth, that the hour is quickly coming when the smallest circumstances of our lives shall be brought to light, and our eternal state be fixed by a righteous and unerring God. Thus Solomon's throne was established in peace, as the type of the Redeemer's kingdom of peace and righteousness. And it is a comfort, in reference to the enmity of the church's enemies, that, how much soever they rage, it is a vain thing they imagine. Christ's throne is established, and they cannot shake it.

