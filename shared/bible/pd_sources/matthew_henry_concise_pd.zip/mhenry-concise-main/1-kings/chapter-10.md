---
title: "1 Kings 10 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "10"
description: "In this chapter: The queen of Sheba's visit to Solomon. (1–13). Solomon's wealth. (14–29)."
weight: 10
---

# 1 Kings 10 

## Chapter Outline

- The queen of Sheba's visit to Solomon. (1–13)
- Solomon's wealth. (14–29)

## Verses 1–13

The queen of Sheba came to Solomon to hear his wisdom, thereby to improve her own. Our Saviour mentions her inquiries after God, by Solomon, as showing the stupidity of those who inquire not after God, by our Lord Jesus Christ. By waiting and prayer, by diligently searching the Scriptures, by consulting wise and experienced Christians, and by practising what we have learned, we shall be delivered from difficulties. Solomon's wisdom made more impression upon the queen of Sheba than all his prosperity and grandeur. There is a spiritual excellence in heavenly things, and in consistent Christians, to which no reports can do justice. Here the truth exceeded; and all who, through grace, are brought to commune with God, will say the one half was not told them of the pleasures and the advantages of wisdom's ways. Glorified saints, much more, will say of heaven, that the thousandth part was not told them, 1Co 2:9. She pronounced them happy that constantly attended Solomon. With much more reason may we say of Christ's servants, Blessed are they that dwell in his house; they will be still praising him. She made a noble present to Solomon. What we present to Christ, he needs not, but will have us do so to express our gratitude. The believer who has been with Jesus, will return to his station, discharge his duties with readiness, and from better motives; looking forward to the day when, being absent from the body, he shall be present with the Lord.

## Verses 14–29

Solomon increased his wealth. Silver was nothing accounted of. Such is the nature of worldly wealth, plenty of it makes it the less valuable; much more should the enjoyment of spiritual riches lessen our esteem of all earthly possessions. If gold in abundance makes silver to be despised, shall not wisdom, and grace, and the foretastes of heaven, which are far better than gold, make gold to be lightly esteemed? See in Solomon's greatness the performance of God's promise, and let it encourage us to seek first the righteousness of God's kingdom. This was he, who, having tasted all earthly enjoyments, wrote a book, to show the vanity of all worldly things, the vexation of spirit that attends them, and the folly of setting our hearts upon them: and to recommend serious godliness, as that which will do unspeakably more to make us happy, that all the wealth and power he was master of; and, through the grace of God, it is within our reach.

