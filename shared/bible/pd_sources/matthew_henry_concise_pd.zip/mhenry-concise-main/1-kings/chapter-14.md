---
title: "1 Kings 14 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "14"
description: "In this chapter: Abijah being sick, his mother consults Ahijah. (1–6). The destruction of Jeroboam's house. (7–20). Rehoboam's wicked reign. (21–31)."
weight: 14
---

# 1 Kings 14 

## Chapter Outline

- Abijah being sick, his mother consults Ahijah. (1–6)
- The destruction of Jeroboam's house. (7–20)
- Rehoboam's wicked reign. (21–31)

## Verses 1–6

“At that time,” when Jeroboam did evil, his child sickened. When sickness comes into our families, we should inquire whether there may not be some particular sin harboured in our houses, which the affliction is sent to convince us of, and reclaim us from. It had been more pious if he had desired to know wherefore God contended with him; had begged the prophet's prayers, and cast away his idols from him; but most people would rather be told their fortune, than their faults or their duty. He sent to Ahijah, because he had told him he should be king. Those who by sin disqualify themselves for comfort, yet expect that their ministers, because they are good men, should speak peace and comfort to them, greatly wrong themselves and their ministers. He sent his wife in disguise, that the prophet might only answer her question concerning her son. Thus some people would limit their ministers to smooth things, and care not for having the whole counsel of God declared to them, lest it should prophesy no good concerning them, but evil. But she shall know, at the first word, what she has to trust to. Tidings of a portion with hypocrites will be heavy tidings. God will judge men according to what they are, not by what they seem to be.

## Verses 7–20

Whether we keep an account of God's mercies to us or not, he does; and he will set them in order before us, if we are ungrateful, to our greater confusion. Ahijah foretells the speedy death of the child then sick, in mercy to him. He only in the house of Jeroboam had affection for the true worship of God, and disliked the worship of the calves. To show the power and sovereignty of his grace, God saves some out of the worst families, in whom there is some good thing towards the Lord God of Israel. The righteous are removed from the evil to come in this world, to the good to come in a better world. It is often a bad sign for a family, when the best in it are buried out of it. Yet their death never can be a loss to themselves. It was a present affliction to the family and kingdom, by which both ought to have been instructed. God also tells the judgments which should come upon the people of Israel, for conforming to the worship Jeroboam established. After they left the house of David, the government never continued long in one family, but one undermined and destroyed another. Families and kingdoms are ruined by sin. If great men do wickedly, they draw many others, both into the guilt and punishment. The condemnation of those will be severest, who must answer, not only for their own sins, but for sins others have been drawn into, and kept in, by them.

## Verses 21–31

Here is no good said of Rehoboam, and much said to the disadvantage of his subjects. The abounding of the worst crimes, of the worst of the heathen, in Jerusalem, the city the Lord had chosen for his temple and his worship, shows that nothing can mend the hearts of fallen men but the sanctifying grace of the Holy Spirit. On this alone may we depend; for this let us daily pray, in behalf of ourselves and all around us. The splendour of their temple, the pomp of their priesthood, and all the advantages with which their religion was attended, could not prevail to keep them close to it; nothing less than the pouring out the Spirit will keep God's Israel in their allegiance to him. Sin exposes, makes poor, and weakens any people. Shishak, king of Egypt, came and took away the treasures. Sin makes the gold become dim, changes the most fine gold, and turns it into brass.

