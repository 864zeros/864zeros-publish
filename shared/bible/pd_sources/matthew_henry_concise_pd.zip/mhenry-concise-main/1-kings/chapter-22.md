---
title: "1 Kings 22 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "22"
description: "In this chapter: Jehoshaphat makes a league with Ahab. (1–14). Micaiah predicts the death of Ahab. (15–28). Death of Ahab. (29–40). Jehoshaphat's good reign over Judah. (41–50). Ahaziah's evil reign over Israel. (51–53)."
weight: 22
---

# 1 Kings 22 

## Chapter Outline

- Jehoshaphat makes a league with Ahab. (1–14)
- Micaiah predicts the death of Ahab. (15–28)
- Death of Ahab. (29–40)
- Jehoshaphat's good reign over Judah. (41–50)
- Ahaziah's evil reign over Israel. (51–53)

## Verses 1–14

The same easiness of temper, which betrays some godly persons into friendship with the declared enemies of religion, renders it very dangerous to them. They will be drawn to wink at and countenance such conduct and conversation as they ought to protest against with abhorrence. Whithersoever a good man goes, he ought to take his religion with him, and not be ashamed to own it when he is with those who have no regard for it. Jehoshaphat had not left behind him, at Jerusalem, his affection and reverence for the word of the Lord, but avowed it, and endeavoured to bring it into Ahab's court. And Ahab's prophets, to please Jehoshaphat, made use of the name of Jehovah: to please Ahab, they said, Go up. But the false prophets cannot so mimic the true, but that he who has spiritual senses exercised, can discern the fallacy. One faithful prophet of the Lord was worth them all. Wordly men have in all ages been alike absurd in their views of religion. They would have the preacher fit his doctrine to the fashion of the times, and the taste of the hearers, and yet to add, Thus saith the Lord, to words that men would put into their mouths. They are ready to cry out against a man as rude and foolish, who scruples thus to try to secure his own interests, and to deceive others.

## Verses 15–28

The greatest kindness we can do to one that is going in a dangerous way, is, to tell him of his danger. To leave the hardened criminal without excuse, and to give a useful lesson to others, Micaiah related his vision. This matter is represented after the manner of men: we are not to imagine that God is ever put upon new counsels; or that he needs to consult with angels, or any creature, about the methods he should take; or that he is the author of sin, or the cause of any man's telling or believing a lie. Micaiah returned not the blow of Zedekiah, yet, since he boasted of the Spirit, as those commonly do that know least of the Holy Spirit's operations, the true prophet left him to be convinced of his error by the event. Those that will not have their mistakes set right in time, by the word of God, will be undeceived, when it is too late, by the judgments of God. We should be ashamed of what we call trials, were we to consider what the servants of God have endured. Yet it will be well, if freedom from trouble prove not more hurtful to us; we are more easily allured and bribed into unfaithfulness and conformity to the world, than driven to them.

## Verses 29–40

Ahab basely intended to betray Johoshaphat to danger, that he might secure himself. See what they get that join with wicked men. How can it be expected that he should be true to his friend, who has been false to his God! He had said in compliment to Ahab, I am as thou art, and now he was indeed taken for him. Those that associate with evil-doers, are in danger of sharing in their plagues. By Jehoshaphat's deliverance, God let him know, that though he was displeased with him, yet he had not deserted him. God is a friend that will not fail us when other friends do. Let no man think to hide himself from God's judgment. God directed the arrow to hit Ahab; those cannot escape with life, whom God has doomed to death. Ahab lived long enough to see part of Micaiah's prophecy accomplished. He had time to feel himself die; with what horror must he have thought upon the wickedness he had committed!

## Verses 41–50

Jehoshaphat's reign appears to have been one of the best, both as to piety and prosperity. He pleased God, and God blessed him.

## Verses 51–53

Ahaziah's reign was very short, not two years; some sinners God makes quick work with. A very bad character is given of him; he listened not to instruction, took no warning, but followed the example of his wicked father, and the counsel of his more wicked mother, Jezebel, who was still living. Miserable are the children who not only derive a sinful nature from their parents, but are taught by them to increase it; and most unhappy parents are they, that help to damn their children's souls. Hardened sinners rush forward, unawed and unmoved, in the ways from which others before them have been driven into everlasting misery.

