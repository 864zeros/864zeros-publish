---
title: "1 Kings 13 | Read the Matthew Henry Concise Bible Commentary Online"
linkTitle: "13"
description: "In this chapter: Jeroboam's sin reproved. (1–10). The prophet deceived. (11–22). The disobedient prophet is slain, Jeroboam's obstinacy. (23–34)."
weight: 13
---

# 1 Kings 13 

## Chapter Outline

- Jeroboam's sin reproved. (1–10)
- The prophet deceived. (11–22)
- The disobedient prophet is slain, Jeroboam's obstinacy. (23–34)

## Verses 1–10

In threatening the altar, the prophet threatens the founder and worshippers. Idolatrous worship will not continue, but the word of the Lord will endure for ever. The prediction plainly declared that the family of David would continue, and support true religion, when the ten tribes would not be able to resist them. If God, in justice, harden the hearts of sinners, so that the hand they have stretched out in sin they cannot pull in again by repentance, that is a spiritual judgment, represented by this, and much more dreadful. Jeroboam looked for help, not from his calves, but from God only, from his power, and his favour. The time may come when those that hate the preaching, would be glad of the prayers of faithful ministers. Jeroboam does not desire the prophet to pray that his sin might be pardoned, and his heart changed, but only that his hand might be restored. He seemed affected for the present with both the judgment and the mercy, but the impression wore off. God forbade his messenger to eat or drink in Bethel, to show his detestation of their idolatry and apostacy from God, and to teach us not to have fellowship with the works of darkness. Those have not learned self-denial, who cannot forbear one forbidden meal.

## Verses 11–22

The old prophet's conduct proves that he was not really a godly man. When the change took place under Jeroboam, he preferred his ease and interest to his religion. He took a very bad method to bring the good prophet back. It was all a lie. Believers are most in danger of being drawn from their duty by plausible pretences of holiness. We may wonder that the wicked prophet went unpunished, while the holy man of God was suddenly and severely punished. What shall we make of this? The judgments of God are beyond our power to fathom; and there is a judgment to come. Nothing can excuse any act of wilful disobedience. This shows what they must expect who hearken to the great deceiver. They that yield to him as a tempter, will be terrified by him as a tormentor. Those whom he now fawns upon, he will afterwards fly upon; and whom he draws into sin, he will try to drive to despair.

## Verses 23–34

God is displeased at the sins of his own people; and no man shall be protected in disobedience, by his office, his nearness to God, or any services he has done for him. God warns all whom he employs, strictly to observe their orders. We cannot judge of men by their sufferings, nor of sins by present punishments; with some, the flesh is destroyed, that the spirit may be saved; with others, the flesh is pampered, that the soul may ripen for hell. Jeroboam returned not from his evil way. He promised himself that the calves would secure the crown to his family, but they lost it, and sunk his family. Those betray themselves who think to support themselves by any sin whatever. Let us dread prospering in sinful ways; pray to be kept from every delusion and temptation, and to be enabled to walk with self-denying perseverance in the way of God's commands.

